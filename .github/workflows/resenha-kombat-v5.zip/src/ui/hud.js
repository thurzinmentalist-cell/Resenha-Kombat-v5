// HUD estilo arcade clássico + cutscenes de ultimate/transformação/fusão + letreiros
(function () {
  const RC = window.RC, T = RC.Text, S = RC.Sprites, W = RC.W, H = RC.H;
  const BTN = { lp: 'SOCO FRACO', hp: 'SOCO FORTE', lk: 'CHUTE FRACO', hk: 'CHUTE FORTE' };
  function bar(c, x, y, w, h, r, trail, flip, col) {
    c.fillStyle = '#000'; c.fillRect(x - 2, y - 2, w + 4, h + 4); c.fillStyle = '#2b2b36'; c.fillRect(x, y, w, h);
    const tw = Math.round(w * RC.clamp(trail, 0, 1)), fw = Math.round(w * RC.clamp(r, 0, 1));
    c.fillStyle = '#ffd24a'; c.fillRect(flip ? x + w - tw : x, y, tw, h);
    c.fillStyle = col; c.fillRect(flip ? x + w - fw : x, y, fw, h);
    c.fillStyle = 'rgba(255,255,255,.35)'; c.fillRect(flip ? x + w - fw : x, y, fw, 2);
    c.fillStyle = 'rgba(0,0,0,.25)'; c.fillRect(flip ? x + w - fw : x, y + h - 3, fw, 3);
  }
  const hpCol = r => r > 0.5 ? '#3ddc5a' : r > 0.25 ? '#f0c020' : '#e0283c';
  const cmdText = (cmd, face) => cmd.map(k => k === 'F' ? (face > 0 ? '→' : '←') : k === 'B' ? (face > 0 ? '←' : '→') : k === 'U' ? '↑' : k === 'D' ? '↓' : BTN[k] || k.toUpperCase()).join(' ');
  RC.HUD = {
    cmdText,
    draw(c, G) {
      const teams = G.teams;
      for (let i = 0; i < 2; i++) {
        const t = teams[i], f = t.cur, flip = i === 1, bx = flip ? 272 : 36, bw = 172, by = 14;
        if (!f) continue;
        const r = f.hp / f.maxhp; t.trail = t.trail == null ? r : (t.trail > r ? Math.max(r, t.trail - 0.006) : r);
        bar(c, bx, by, bw, 12, r, t.trail, flip, hpCol(r));
        S.portrait(c, f.baseId, flip ? 448 : 8, 6, 24, 24, {}); c.strokeStyle = '#000'; c.lineWidth = 2; c.strokeRect(flip ? 448 : 8, 6, 24, 24); c.strokeStyle = f.color; c.lineWidth = 1; c.strokeRect(flip ? 449 : 9, 7, 22, 22);
        T.draw(c, f.name + (f.form ? ' *' : ''), flip ? bx + bw : bx, by + 16, { a: flip ? 'r' : 'l', c: '#fff', ol: '#000' });
        // forma / fusão
        if (f.form) { const fd = RC.DATA.transformations[f.baseId]; bar(c, bx, 36, bw, 3, f.formT / (fd.dur * 60), f.formT / (fd.dur * 60), flip, fd.aura); }
        if (t.fusion) { bar(c, bx, 36, bw, 3, t.fusion.F.fuseT / 1800, t.fusion.F.fuseT / 1800, flip, '#fff'); }
        // reservas
        if (t.fighters.length > 1) t.fighters.forEach((rf, k) => {
          const rx = flip ? bx + bw - 16 - k * 18 : bx + k * 18, ry = 44, act = rf === t.fighters[t.active];
          S.portrait(c, rf.baseId, rx, ry, 16, 16, {}); c.strokeStyle = act ? '#fff' : '#000'; c.lineWidth = 1; c.strokeRect(rx - 0.5, ry - 0.5, 17, 17);
          if (!rf.alive) { c.fillStyle = 'rgba(0,0,0,.65)'; c.fillRect(rx, ry, 16, 16); T.draw(c, 'X', rx + 8, ry + 5, { a: 'c', c: '#d8142f' }); }
          else { c.fillStyle = '#000'; c.fillRect(rx, ry + 17, 16, 3); c.fillStyle = hpCol(rf.hp / rf.maxhp); c.fillRect(rx, ry + 17, Math.round(16 * rf.hp / rf.maxhp), 3); }
        });
        // pips de rounds
        for (let k = 0; k < 2; k++) { const px = flip ? 252 + k * 10 : 228 - k * 10; c.fillStyle = '#000'; c.fillRect(px - 1, 36, 8, 8); c.fillStyle = t.wins > k ? '#ffd24a' : '#3a3a48'; c.fillRect(px, 37, 6, 6); }
        // super
        const sx = flip ? W - 12 - 162 : 12;
        for (let s = 0; s < 3; s++) {
          const x = sx + (flip ? (2 - s) : s) * 56, fill = RC.clamp((t.meter - s * 100) / 100, 0, 1);
          c.fillStyle = '#000'; c.fillRect(x - 1, 250, 52, 10); c.fillStyle = '#23232e'; c.fillRect(x, 251, 50, 8);
          c.fillStyle = t.meter >= 300 && (RC.frame >> 3) % 2 ? '#fff' : ['#3aa0ff', '#7a5cff', '#ff4fd8'][s]; const fw = Math.round(50 * fill); c.fillStyle = t.meter >= 300 && (RC.frame >> 3) % 2 ? '#fff' : ['#3aa0ff', '#7a5cff', '#ff4fd8'][s]; c.fillRect(flip ? x + 50 - fw : x, 251, fw, 8);
        }
        T.draw(c, t.meter >= 300 ? 'SUPER MAX' : 'SUPER', flip ? W - 12 : 12, 241, { a: flip ? 'r' : 'l', c: t.meter >= 300 ? '#ffe14a' : '#9aa', ol: '#000' });
        c.fillStyle = '#000'; c.fillRect(sx - 1, 262, 164, 5); c.fillStyle = '#2b1a2b'; c.fillRect(sx, 263, 162, 3); c.fillStyle = t.fat >= 100 ? ((RC.frame >> 2) % 2 ? '#ff2a4a' : '#8a0014') : '#a01040'; const ff = Math.round(162 * t.fat / 100); c.fillRect(flip ? sx + 162 - ff : sx, 263, ff, 3);
        if (t.fat >= 100) T.draw(c, 'RESENHATALITY LIBERADA', flip ? W - 12 : 12, 268 - 12 + 12 - 24 + 1, { a: flip ? 'r' : 'l', c: '#ff2a4a', ol: '#000' });
        if (t.combo && t.combo.t > 0 && t.combo.n >= 2) { t.combo.t--; T.draw(c, t.combo.n + ' HITS!', flip ? W - 16 : 16, 86, { a: flip ? 'r' : 'l', s: 2, c: '#ffe14a', ol: '#000' }); }
      }
      // timer
      c.fillStyle = '#000'; c.fillRect(219, 8, 42, 26); c.fillStyle = '#1a1a26'; c.fillRect(221, 10, 38, 22);
      T.draw(c, G.training ? 'TREINO' : String(Math.max(0, Math.ceil(G.timer / 60))).padStart(2, '0'), 240, G.training ? 17 : 13, { a: 'c', s: G.training ? 1 : 2, c: G.timer < 600 && !G.training ? '#ff5a5a' : '#ffffff', sh: '#000' });
      if (G.timeStop) { const ts = G.timeStop, x = 240, y = 62; c.fillStyle = '#000'; c.beginPath(); c.arc(x, y, 14, 0, 6.283); c.fill(); c.strokeStyle = '#b36bff'; c.lineWidth = 2; c.beginPath(); c.arc(x, y, 12, 0, 6.283); c.stroke(); const a = -1.57 + (1 - ts.t / ts.max) * 6.283; c.strokeStyle = '#fff'; c.beginPath(); c.moveTo(x, y); c.lineTo(x + Math.cos(a) * 10, y + Math.sin(a) * 10); c.stroke(); T.draw(c, Math.ceil(ts.t / 60) + 'S', x, y + 18, { a: 'c', c: '#b36bff', ol: '#000' }); }
      // faixas
      if (G.banner && G.banner.t > 0) { const b = G.banner, a = Math.min(1, b.t / 14), k = Math.min(1, (b.dur - b.t) / 6); c.globalAlpha = a; T.draw(c, b.text, 240, 70 - (1 - k) * 8, { a: 'c', s: 2, c: b.col, ol: '#000', sh: '#000' }); c.globalAlpha = 1; b.t--; }
      if (G.big) RC.HUD.big(c, G.big);
      if (G.title) { const t = G.title; c.globalAlpha = RC.clamp(Math.min(t.t, t.dur - t.t) / 10, 0, 1); T.draw(c, t.text, 240, 100, { a: 'c', s: t.s || 4, c: t.col || '#fff', ol: '#000', sh: t.sh || '#000' }); if (t.sub) T.draw(c, t.sub, 240, 100 + (t.s || 4) * 10, { a: 'c', s: 2, c: '#ffd24a', ol: '#000' }); c.globalAlpha = 1; }
      if (G.phase === 'finish') {
        const w = G.winner, blink = (RC.frame >> 3) % 2;
        T.draw(c, 'FINISH HIM!', 240, 70, { a: 'c', s: 4, c: blink ? '#ff2a4a' : '#ffd24a', ol: '#000', sh: '#600' });
        const ctrl = w.human ? '' : '';
        T.draw(c, 'RESENHATALITY: ' + cmdText(w.cur.def.cmd, w.cur.face), 240, 118, { a: 'c', s: 2, c: '#fff', ol: '#000' });
        c.fillStyle = '#000'; c.fillRect(120, 140, 240, 6); c.fillStyle = '#ff2a4a'; c.fillRect(121, 141, Math.round(238 * (1 - G.pt / G.finishMax)), 4);
      }
      if (G.acid > 0) { c.fillStyle = 'rgba(120,255,60,.10)'; c.fillRect(0, 0, W, H); }
      if (G.flashT > 0) { c.globalAlpha = RC.clamp(G.flashT / G.flashMax, 0, 1) * G.flashA; c.fillStyle = G.flashC; c.fillRect(0, 0, W, H); c.globalAlpha = 1; G.flashT--; }
    },
    big(c, b) { // letreiro grande com sangue
      const a = RC.clamp(b.t / 12, 0, 1), s = b.s || 4, w = T.w(b.text, s), x = 240, y = 112;
      c.globalAlpha = Math.min(1, a); const sh = b.t > 100 ? RC.rnd(-1, 1) : 0;
      T.draw(c, b.text, x + sh, y, { a: 'c', s, c: b.col, ol: '#000', sh: '#400' });
      for (let i = 0; i < 16; i++) { const px = x - w / 2 + (i * 53) % w, len = 4 + ((i * 29) % 18) + Math.min(24, (b.age || 0) * 0.15); c.fillStyle = b.col; c.fillRect(Math.round(px), y + s * 7, 2, len); c.fillRect(Math.round(px) - 1, y + s * 7 + len, 4, 3); }
      c.globalAlpha = 1; b.age = (b.age || 0) + 1;
    },
    // cutscene de ultimate/transformação/fusão
    cut(c, G, drawCaster) {
      const k = G.cut; if (!k) return; const t = k.t, d = k.dur, a = Math.min(1, t / 8) * Math.min(1, (d - t) / 8), f = k.f, left = f.team.idx === 0;
      c.globalAlpha = 0.78 * a; c.fillStyle = '#05040c'; c.fillRect(0, 0, W, H); c.globalAlpha = 1;
      // raios de velocidade
      c.save(); c.globalAlpha = 0.4 * a; c.translate(240, 120); c.fillStyle = k.col;
      for (let i = 0; i < 26; i++) { const an = i / 26 * 6.283 + t * 0.01, r0 = 60 + ((i * 37 + t * 14) % 120), r1 = r0 + 90 + (i % 5) * 30; c.beginPath(); c.moveTo(Math.cos(an - 0.02) * r0, Math.sin(an - 0.02) * r0); c.lineTo(Math.cos(an) * r1, Math.sin(an) * r1); c.lineTo(Math.cos(an + 0.02) * r0, Math.sin(an + 0.02) * r0); c.fill(); }
      c.restore();
      if (drawCaster) drawCaster();
      // retrato grande
      const slide = Math.min(1, t / 14), px = left ? -130 + slide * 150 : W + 130 - slide * 150 - 110;
      c.save(); c.globalAlpha = a; S.portrait(c, f.baseId, px, 40, 110, 130, { k: 4.2, flip: !left }); c.strokeStyle = k.col; c.lineWidth = 2; c.strokeRect(px, 40, 110, 130); c.restore();
      // faixa com o nome do golpe
      const bandY = 178; c.globalAlpha = a; c.fillStyle = '#000'; c.fillRect(0, bandY, W, 40); c.fillStyle = k.col; c.fillRect(0, bandY, W, 2); c.fillRect(0, bandY + 38, W, 2);
      const tx = left ? RC.lerp(-300, 28, Math.min(1, t / 12)) : RC.lerp(W + 300, W - 28, Math.min(1, t / 12));
      T.draw(c, k.title, tx, bandY + 8, { a: left ? 'l' : 'r', s: k.title.length > 18 ? 2 : 3, c: '#fff', ol: k.col, sh: '#000' });
      T.draw(c, k.sub || f.name, tx, bandY + 30, { a: left ? 'l' : 'r', c: k.col }); c.globalAlpha = 1;
      if (t > d - 6) { c.globalAlpha = (t - (d - 6)) / 6; c.fillStyle = '#fff'; c.fillRect(0, 0, W, H); c.globalAlpha = 1; }
      if (k.kind === 'transform' && t % 3 === 0) T.go(c, RC.rnd(40, 420), RC.rnd(30, 200), 2, k.col);
    }
  };
})();
