// Telas: splash, menus, opções, controles, seleção de personagem, cenário, VS (diálogos)
(function () {
  const RC = window.RC, T = RC.Text, S = RC.Sprites, A = RC.Audio, I = RC.Input, W = RC.W, H = RC.H;
  const IDS = ['guilherme', 'arthur', 'alexandre', 'kaique', 'toddy', 'matheus', 'luan', 'rafael', 'joel', 'vitin'];
  const Game = RC.Game = { mode: '1v1', vsCpu: true, picks: [[], []], stage: 0, diff: 2 };
  try { const d = parseInt(localStorage.getItem('rc_diff')); if (d >= 1 && d <= 5) Game.diff = d; } catch (e) { }
  const inR = (p, r) => p.x >= r.x && p.x <= r.x + r.w && p.y >= r.y && p.y <= r.y + r.h;
  let tick = 0;

  // ---------- helpers de desenho ----------
  const mkc = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };
  let VIG = null;
  function vignette(c) { if (!VIG) { VIG = mkc(W, H); const x = VIG.getContext('2d'); const g = x.createRadialGradient(240, 130, 70, 240, 135, 310); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,.78)'); x.fillStyle = g; x.fillRect(0, 0, W, H); } c.drawImage(VIG, 0, 0); }
  const EMB = ['#ffb04a', '#ff6a3a', '#fff0b0'];
  function embers(c, t, n = 30) { for (let i = 0; i < n; i++) { const x = (i * 83 + t * (0.25 + (i % 3) * 0.15) + Math.sin(t * 0.02 + i) * 8) % W, y = H - ((t * (0.5 + (i % 4) * 0.25) + i * 41) % (H + 20)); c.globalAlpha = 0.35 + 0.5 * (((i * 7 + (t >> 1)) % 20) / 20); c.fillStyle = EMB[i % 3]; c.fillRect(Math.round(x), Math.round(y), 1 + (i % 2), 1 + (i % 2)); } c.globalAlpha = 1; }
  // fundo animado: cenário (pré-renderizado) escurecido, raios giratórios, vinheta e brasas
  function bg(c, t, col = '#d8142f', dim = 0.72, stage) {
    const si = stage != null ? stage : Math.floor(t / 900 + (Game._bgOff || 0)) % RC.Stages.list.length; RC.Stages.draw(c, si, t, Math.sin(t * 0.007) * 30);
    c.fillStyle = 'rgba(8,5,18,' + dim + ')'; c.fillRect(0, 0, W, H);
    c.save(); c.globalAlpha = 0.07; c.fillStyle = col; c.translate(240, 120);
    for (let i = 0; i < 14; i++) { const a = i / 14 * 6.283 + t * 0.003; c.beginPath(); c.moveTo(0, 0); c.lineTo(Math.cos(a - 0.07) * 400, Math.sin(a - 0.07) * 400); c.lineTo(Math.cos(a + 0.07) * 400, Math.sin(a + 0.07) * 400); c.fill(); }
    c.restore(); vignette(c); embers(c, t);
  }
  // logo 3D pré-renderizado (extrusão + degradê + brilho) com varredura de luz
  const LC = {}; let SHC = null;
  function logoCanvas(s) {
    if (LC[s]) return LC[s]; const lh = s * 7, w = T.w('RESENHA', s) + 28, h = lh * 2 + s * 3 + 18, cv = mkc(w, h), x = cv.getContext('2d'); x.imageSmoothingEnabled = false;
    [['RESENHA', ['#ffb7a0', '#ff3b3b', '#a8001a'], '#3a0410'], ['COMBAT', ['#fff6b0', '#ffd21a', '#d88200'], '#4a2c00']].forEach((L, i) => {
      const y = 6 + i * (lh + s * 2 + 2), cx = w / 2;
      for (let k = s; k >= 1; k--) T.draw(x, L[0], cx, y + k, { a: 'c', s, c: L[2], ol: '#000' });
      T.draw(x, L[0], cx, y, { a: 'c', s, c: '#000', ol: '#000' });
      const tc = mkc(w, h), tx = tc.getContext('2d'); tx.imageSmoothingEnabled = false; T.draw(tx, L[0], cx, y, { a: 'c', s, c: '#fff' });
      tx.globalCompositeOperation = 'source-in'; const g = tx.createLinearGradient(0, y, 0, y + lh); g.addColorStop(0, L[1][0]); g.addColorStop(0.5, L[1][1]); g.addColorStop(1, L[1][2]); tx.fillStyle = g; tx.fillRect(0, 0, w, h);
      tx.globalCompositeOperation = 'source-atop'; tx.fillStyle = 'rgba(255,255,255,.38)'; tx.fillRect(0, y, w, Math.max(2, Math.floor(lh * 0.16))); x.drawImage(tc, 0, 0);
    });
    return LC[s] = { cv, w, h };
  }
  function logo(c, y, t, s = 5) {
    const L = logoCanvas(s), bob = Math.round(Math.sin(t * 0.05) * 1.5), x = Math.round(240 - L.w / 2);
    c.globalAlpha = 0.22 + 0.08 * Math.sin(t * 0.06); c.fillStyle = '#ff5a2a'; c.fillRect(x + 10, y + L.h * 0.25 + bob, L.w - 20, L.h * 0.5); c.globalAlpha = 1;
    if (!SHC || SHC.width < L.w || SHC.height < L.h) SHC = mkc(Math.max(L.w, SHC ? SHC.width : 0), Math.max(L.h, SHC ? SHC.height : 0));
    const sx = SHC.getContext('2d'); sx.globalCompositeOperation = 'source-over'; sx.clearRect(0, 0, SHC.width, SHC.height); sx.drawImage(L.cv, 0, 0);
    const k = (t * 2.4) % (L.w + 220) - 90; sx.globalCompositeOperation = 'source-atop'; sx.fillStyle = 'rgba(255,255,255,.6)'; sx.beginPath(); sx.moveTo(k, 0); sx.lineTo(k + 20, 0); sx.lineTo(k + 20 - L.h * 0.5, L.h); sx.lineTo(k - L.h * 0.5, L.h); sx.fill();
    c.drawImage(SHC, 0, 0, L.w, L.h, x, y + bob, L.w, L.h);
  }
  const chamf = (c, x, y, w, h, col) => { c.fillStyle = col; c.fillRect(x + 2, y, w - 4, h); c.fillRect(x, y + 2, w, h - 4); c.fillRect(x + 1, y + 1, w - 2, h - 2); };
  function button(c, r, label, sel, sub) {
    const f = RC.frame, x = r.x, y = r.y, w = r.w, h = r.h;
    c.fillStyle = 'rgba(0,0,0,.45)'; c.fillRect(x + 2, y + 3, w, h);
    if (sel) { c.globalAlpha = 0.22 + 0.1 * Math.sin(f * 0.15); chamf(c, x - 3, y - 3, w + 6, h + 6, '#ff7a3a'); c.globalAlpha = 1; }
    chamf(c, x - 1, y - 1, w + 2, h + 2, sel ? '#ffffff' : '#07070e'); chamf(c, x, y, w, h, sel ? '#a0101f' : '#12131f');
    c.fillStyle = sel ? '#e03a30' : '#262a44'; c.fillRect(x + 2, y + 1, w - 4, Math.ceil(h * 0.48)); c.fillStyle = sel ? '#ff8a5a' : '#3a4066'; c.fillRect(x + 2, y + 1, w - 4, 1);
    c.fillStyle = sel ? '#ffe14a' : '#5a6cff'; c.fillRect(x + 3, y + 3, 2, h - 6); c.fillStyle = 'rgba(0,0,0,.35)'; c.fillRect(x + 2, y + h - 2, w - 4, 1);
    if (sel) { const k = (f * 2.5) % (w + 50) - 25; c.save(); c.beginPath(); c.rect(x + 2, y + 1, w - 4, h - 2); c.clip(); c.fillStyle = 'rgba(255,255,255,.22)'; c.beginPath(); c.moveTo(x + k, y); c.lineTo(x + k + 12, y); c.lineTo(x + k + 12 - h * 0.6, y + h); c.lineTo(x + k - h * 0.6, y + h); c.fill(); c.restore(); const a = Math.sin(f * 0.2) * 2; T.draw(c, '>', x - 9 + a, y + (h - 7) / 2, { c: '#ffe14a', ol: '#000' }); T.draw(c, '<', x + w + 4 - a, y + (h - 7) / 2, { c: '#ffe14a', ol: '#000' }); }
    T.draw(c, label, x + w / 2, y + (sub ? 5 : (h - 7) / 2 + 1), { a: 'c', c: '#fff', s: h > 26 ? 2 : 1, sh: '#000' });
    if (sub) T.draw(c, sub, x + w / 2, y + h - 12, { a: 'c', c: sel ? '#ffd0d0' : '#8890a8' });
  }
  // menu vertical genérico
  function mk(items, y0 = 112, w = 190, h = 26, gap = 6) { return { items, sel: 0, rects: items.map((_, i) => ({ x: (W - w) / 2, y: y0 + i * (h + gap), w, h })) }; }
  function mUpdate(m) {
    const n = I.nav, p = I.ptr, k = m.items.length; let pick = -1;
    if (n.up) { m.sel = (m.sel + k - 1) % k; A.play('select'); } if (n.down) { m.sel = (m.sel + 1) % k; A.play('select'); }
    m.rects.forEach((r, i) => { if (inR(p, r)) { if (p.moved && m.sel !== i) { m.sel = i; A.play('select'); } if (p.clicked) { m.sel = i; pick = i; } } });
    if (n.ok) pick = m.sel; if (pick >= 0) A.play('confirm'); return pick;
  }
  function mDraw(c, m) { m.rects.forEach((r, i) => button(c, r, m.items[i].label || m.items[i], m.sel === i, m.items[i].sub)); }
  function roster(c, y, t) { IDS.forEach((id, i) => S.portrait(c, id, 8 + i * 47, y, 44, 40, { t })); }
  const fake = (id, an, t, x, y, face) => ({ id, baseId: id, x, y, face, clock: t, anim: an, ext: an === 'lp' || an === 'hk' || an === 'hp' ? Math.sin(t * 0.25) * 0.5 + 0.5 : 0, state: 'idle', form: null, flash: 0, walkDir: 1, vis: null, guard: null, fusionId: null, frozen: false, gun: false, auraCol: null });
  const title = (c, txt, y, col = '#d8142f') => { T.draw(c, txt, 240, y, { a: 'c', s: 3, c: '#fff', ol: col, sh: '#000' }); };

  const Sc = RC.Screens = {};
  // ---------- splash ----------
  Sc.splash = {
    enter() { this.t = 0; A.music('menu'); I.showTouch(false); },
    update() { this.t++; if (this.t > 20 && (I.anyKey || I.ptr.clicked || Object.values(I.p[0].pressed).some(Boolean))) { A.play('confirm'); RC.App.goto('menu'); } },
    draw(c) {
      const t = this.t; RC.Stages.draw(c, 0, t, Math.sin(t * 0.008) * 24);
      const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, 'rgba(10,4,24,.55)'); g.addColorStop(0.45, 'rgba(10,4,24,.12)'); g.addColorStop(1, 'rgba(10,4,24,.62)'); c.fillStyle = g; c.fillRect(0, 0, W, H);
      c.save(); c.globalAlpha = 0.09; c.fillStyle = '#ffd27a'; c.translate(240, 70); for (let i = 0; i < 16; i++) { const a = i / 16 * 6.283 + t * 0.004; c.beginPath(); c.moveTo(0, 0); c.lineTo(Math.cos(a - 0.06) * 420, Math.sin(a - 0.06) * 420); c.lineTo(Math.cos(a + 0.06) * 420, Math.sin(a + 0.06) * 420); c.fill(); } c.restore();
      IDS.forEach((id, i) => { const k = (t + i * 47) % 300, an = k < 36 ? (i % 2 ? 'hk' : 'lp') : (k > 230 && k < 270 ? 'win' : 'idle'); S.drawFighter(c, fake(id, an, t + i * 13, 32 + i * 46.5, 246 + (i % 2) * 6, i < 5 ? 1 : -1)); });
      vignette(c); embers(c, t, 36);
      logo(c, 16, t, 7);
      c.fillStyle = 'rgba(0,0,0,.6)'; c.fillRect(0, 150, W, 16); c.fillStyle = '#d8142f'; c.fillRect(0, 150, W, 1); c.fillRect(0, 165, W, 1);
      T.draw(c, 'O  JOGO  DE  LUTA  DA  ZOEIRA  ENTRE  AMIGOS', 240, 154, { a: 'c', c: '#ffe14a', sh: '#000' });
      const pulse = 0.5 + 0.5 * Math.sin(t * 0.1), bw = 250, bx = 240 - bw / 2;
      if ((t >> 5) % 8 !== 7) { c.globalAlpha = 0.3 + 0.2 * pulse; chamf(c, bx - 4, 176, bw + 8, 22, '#ff7a3a'); c.globalAlpha = 1; chamf(c, bx - 1, 177, bw + 2, 20, '#fff'); chamf(c, bx, 178, bw, 18, '#a0101f'); c.fillStyle = '#e03a30'; c.fillRect(bx + 2, 179, bw - 4, 8); T.draw(c, 'TOQUE OU APERTE QUALQUER TECLA', 240, 183, { a: 'c', c: '#fff', sh: '#000' }); }
      T.draw(c, 'V2  -  SPRITES PROVISORIOS EM PIXEL ART PROCEDURAL', 240, 262, { a: 'c', c: '#8890a8', sh: '#000' });
    }
  };
  // ---------- menu principal ----------
  Sc.menu = {
    enter() { this.t = 0; Game.campaign = null; Game.mode = '1v1'; this.m = mk(['VERSUS', 'ARCADE', 'TORNEIO', 'TREINO', 'PERSONAGENS', 'COMO JOGAR', 'OPCOES'].map(l => ({ label: l })), 70, 176, 22, 4); A.music('menu'); I.showTouch(false); if (RC.Campaign) RC.Campaign.active = false; },
    update() {
      this.t++; const p = mUpdate(this.m); if (p < 0) return; Game.campaign = null;
      if (p === 0) RC.App.goto('versus');
      else if (p === 1) { Game.campaign = 'arcade'; Game.mode = '1v1'; Game.vsCpu = true; Game.picks = [[], []]; RC.App.goto('select'); }
      else if (p === 2) { Game.campaign = 'tourney'; Game.mode = '1v1'; Game.vsCpu = true; Game.picks = [[], []]; RC.App.goto('select'); }
      else if (p === 3) RC.App.goto('trainmenu'); else if (p === 4) RC.App.goto('chars'); else if (p === 5) RC.App.goto('howto'); else RC.App.goto('options');
    },
    draw(c) {
      bg(c, this.t); logo(c, 4, this.t, 3); mDraw(c, this.m);
      const id = IDS[Math.floor(this.t / 260) % IDS.length], d = RC.DATA.characters[id], k = this.t % 260, an = k < 40 ? 'lp' : k < 80 ? 'hk' : k > 200 ? 'win' : 'idle';
      c.save(); c.translate(400, 252); c.scale(2, 2); S.drawFighter(c, fake(id, an, this.t, 0, 0, -1)); c.restore(); T.draw(c, d.name, 400, 124, { a: 'c', s: 2, c: d.color, ol: '#000' });
      const m = IDS[(Math.floor(this.t / 260) + 3) % IDS.length]; c.save(); c.translate(80, 252); c.scale(2, 2); S.drawFighter(c, fake(m, 'idle', this.t, 0, 0, 1)); c.restore(); T.draw(c, RC.DATA.characters[m].name, 80, 124, { a: 'c', s: 2, c: RC.DATA.characters[m].color, ol: '#000' });
    }
  };
  Sc.versus = {
    enter() { this.t = 0; this.m = mk([{ label: '1 VS 1', sub: 'UM LUTADOR CADA' }, { label: '2 VS 2', sub: 'DOIS LUTADORES, O PROXIMO ENTRA' }, { label: '3 VS 3', sub: 'TRES LUTADORES, TROCA AUTOMATICA' }, { label: 'VOLTAR' }], 70, 230, 34, 6); },
    update() { this.t++; const p = mUpdate(this.m); if (I.nav.back) { A.play('back'); RC.App.goto('menu'); return; } if (p >= 0 && p < 3) { Game.mode = ['1v1', '2v2', '3v3'][p]; RC.App.goto('opp'); } else if (p === 3) RC.App.goto('menu'); },
    draw(c) { bg(c, this.t); T.draw(c, 'VERSUS', 240, 24, { a: 'c', s: 4, c: '#fff', ol: '#d8142f' }); mDraw(c, this.m); }
  };
  Sc.opp = {
    enter() { this.t = 0; this.m = mk([{ label: 'JOGADOR VS CPU', sub: 'DIFICULDADE: ' + RC.AI.names[Game.diff - 1] }, { label: 'JOGADOR VS JOGADOR', sub: 'LOCAL: TECLADO OU GAMEPAD' }, { label: 'VOLTAR' }], 80, 230, 36, 8); },
    update() { this.t++; const p = mUpdate(this.m); if (I.nav.back) { RC.App.goto('versus'); return; } if (p === 0 || p === 1) { Game.vsCpu = p === 0; Game.picks = [[], []]; RC.App.goto('select'); } else if (p === 2) RC.App.goto('versus'); },
    draw(c) { bg(c, this.t); T.draw(c, Game.mode.toUpperCase().replace('V', ' VS '), 240, 24, { a: 'c', s: 4, c: '#fff', ol: '#d8142f' }); mDraw(c, this.m); T.draw(c, 'A DIFICULDADE MUDA EM OPCOES', 240, 230, { a: 'c', c: '#6a7088' }); }
  };
  // ---------- opções ----------
  Sc.options = {
    enter() { this.t = 0; this.m = mk(['VOLUME GERAL', 'MUSICA', 'EFEITOS', 'DIFICULDADE CPU', 'CONTROLES DE TECLADO', 'BOTOES DE TOQUE (LAYOUT)', 'VOLTAR'].map(l => ({ label: l })), 46, 260, 22, 5); I.showTouch(false); },
    val(i) { return i === 0 ? A.vol.master : i === 1 ? A.vol.music : i === 2 ? A.vol.sfx : (Game.diff - 1) / 4; },
    change(i, d) {
      if (i < 3) { const k = ['master', 'music', 'sfx'][i]; A.vol[k] = RC.clamp(Math.round((A.vol[k] + d * 0.1) * 10) / 10, 0, 1); A.save(); A.play('select'); }
      else if (i === 3) { Game.diff = RC.clamp(Game.diff + d, 1, 5); try { localStorage.setItem('rc_diff', Game.diff); } catch (e) { } A.play('select'); }
    },
    update() {
      this.t++; const m = this.m, n = I.nav, p = I.ptr, k = m.items.length;
      if (n.up) { m.sel = (m.sel + k - 1) % k; A.play('select'); } if (n.down) { m.sel = (m.sel + 1) % k; A.play('select'); }
      if (n.left) this.change(m.sel, -1); if (n.right) this.change(m.sel, 1);
      m.rects.forEach((r, i) => { if (inR(p, r)) { if (p.moved) m.sel = i; if (p.clicked) { m.sel = i; if (i < 4) this.change(i, p.x < r.x + r.w / 2 ? -1 : 1); else this.act(i); } } });
      if (n.ok) this.act(m.sel); if (n.back) { A.play('back'); RC.App.goto('menu'); }
    },
    act(i) { if (i === 4) { A.play('confirm'); RC.App.goto('controls'); } else if (i === 5) { A.play('confirm'); RC.App.goto('touchedit'); } else if (i === 6) { A.play('back'); RC.App.goto('menu'); } },
    draw(c) {
      bg(c, this.t); T.draw(c, 'OPCOES', 240, 18, { a: 'c', s: 3, c: '#fff', ol: '#d8142f' });
      this.m.rects.forEach((r, i) => {
        button(c, r, '', this.m.sel === i); const lab = this.m.items[i].label; T.draw(c, lab, r.x + 8, r.y + 9, { c: '#fff', sh: '#000' });
        if (i < 4) { const v = this.val(i), bx = r.x + 130, bw = 100; c.fillStyle = '#000'; c.fillRect(bx, r.y + 8, bw, 8); c.fillStyle = '#ffd24a'; c.fillRect(bx + 1, r.y + 9, Math.round((bw - 2) * v), 6); T.draw(c, i === 3 ? RC.AI.names[Game.diff - 1] : Math.round(v * 100) + '%', r.x + r.w - 6, r.y + 9, { a: 'r', c: '#fff' }); }
      });
      T.draw(c, 'ESQUERDA/DIREITA OU TOQUE NOS LADOS PARA AJUSTAR', 240, 250, { a: 'c', c: '#6a7088' });
    }
  };
  Sc.controls = {
    enter() { this.t = 0; this.col = 0; this.row = 0; this.wait = false; },
    rect(col, row) { return { x: 20 + col * 224, y: 30 + row * 14, w: 216, h: 13 }; },
    update() {
      this.t++; const n = I.nav, p = I.ptr, N = I.ACTS.length; if (this.wait) return;
      if (n.up) this.row = (this.row + N + 1) % (N + 1); if (n.down) this.row = (this.row + 1) % (N + 1); if (n.left || n.right) this.col = 1 - this.col;
      let pick = n.ok;
      for (let c2 = 0; c2 < 2; c2++) for (let r = 0; r < N; r++) { const rc = this.rect(c2, r); if (inR(p, rc)) { if (p.moved) { this.col = c2; this.row = r; } if (p.clicked) { this.col = c2; this.row = r; pick = true; } } }
      const bR = { x: 150, y: 30 + N * 14 + 6, w: 180, h: 18 }; if (inR(p, bR)) { if (p.moved) this.row = N; if (p.clicked) { this.row = N; pick = true; } }
      if (n.back) { RC.App.goto('options'); return; }
      if (pick) {
        if (this.row === N) { I.saveMap(); A.play('back'); RC.App.goto('options'); return; }
        this.wait = true; A.play('confirm'); I.capture = code => { this.wait = false; if (code !== 'Escape') { I.map[this.col][I.ACTS[this.row]] = code; I.saveMap(); } };
      }
    },
    draw(c) {
      bg(c, this.t); const N = I.ACTS.length;
      for (let c2 = 0; c2 < 2; c2++) { T.draw(c, c2 ? 'JOGADOR 2' : 'JOGADOR 1', 20 + c2 * 224 + 108, 18, { a: 'c', c: c2 ? '#6ad8ff' : '#ff6a6a' }); for (let r = 0; r < N; r++) { const rc = this.rect(c2, r), sel = this.col === c2 && this.row === r; c.fillStyle = sel ? '#d8142f' : 'rgba(20,20,34,.9)'; c.fillRect(rc.x, rc.y, rc.w, rc.h); T.draw(c, I.LABEL[I.ACTS[r]], rc.x + 4, rc.y + 3, { c: '#fff' }); T.draw(c, this.wait && sel ? '...' : RC.keyName(I.map[c2][I.ACTS[r]]), rc.x + rc.w - 4, rc.y + 3, { a: 'r', c: '#ffe14a' }); } }
      button(c, { x: 150, y: 30 + N * 14 + 6, w: 180, h: 18 }, 'SALVAR E VOLTAR', this.row === N);
      T.draw(c, this.wait ? 'PRESSIONE A NOVA TECLA (ESC CANCELA)' : 'ENTER OU CLIQUE PARA TROCAR A TECLA', 240, 250, { a: 'c', c: '#ffe14a' });
      T.draw(c, 'GAMEPAD: A SOCO F, B SOCO FORTE, X CHUTE F, Y CHUTE FORTE, LB AGARRAO, RB ESPECIAL, RT ULTIMATE', 240, 260, { a: 'c', c: '#6a7088' });
    }
  };
  // ---------- seleção de personagem ----------
  Sc.select = {
    enter() {
      this.t = 0; this.sel = 0; this.pi = 0; this.N = Game.mode === 'training' ? (Game.trainN || 1) : Game.mode === '2v2' ? 2 : Game.mode === '3v3' ? 3 : 1; Game.picks = [[], []]; this.needP2 = (!Game.vsCpu || Game.mode === 'training') && !Game.campaign; I.showTouch(false); A.music('menu');
    },
    cell(i) { const col = i % 5, row = Math.floor(i / 5); return { x: 96 + col * 58, y: 44 + row * 68, w: 54, h: 64 }; },
    pick(id) {
      const pk = Game.picks[this.pi]; if (pk.includes(id) && this.N > 1) { A.play('back'); return; } pk.push(id); A.play('confirm');
      if (pk.length >= this.N) {
        if (this.pi === 0) { if (this.needP2) this.pi = 1; else if (Game.campaign) { RC.Campaign.begin(Game.campaign, Game.picks[0][0]); } else { Game.picks[1] = this.cpuPick(); RC.App.goto('stage'); } } else RC.App.goto('stage');
      }
    },
    cpuPick() { const out = []; while (out.length < this.N) { const id = RC.pick(IDS); if (!out.includes(id)) out.push(id); } return out; },
    update() {
      this.t++; const n = I.nav, p = I.ptr;
      if (n.left) { this.sel = (this.sel + 9) % 10; A.play('select'); } if (n.right) { this.sel = (this.sel + 1) % 10; A.play('select'); }
      if (n.up || n.down) { this.sel = (this.sel + 5) % 10; A.play('select'); }
      let pickIdx = n.ok ? this.sel : -1;
      for (let i = 0; i < 10; i++) { const r = this.cell(i); if (inR(p, r)) { if (p.moved) { if (this.sel !== i) A.play('select'); this.sel = i; } if (p.clicked) { this.sel = i; pickIdx = i; } } }
      const rnd = { x: 190, y: 182, w: 100, h: 14 }; if (inR(p, rnd) && p.clicked) { this.pick(RC.pick(IDS)); return; }
      const back = { x: 6, y: 250, w: 56, h: 16 };
      if (n.back || (inR(p, back) && p.clicked)) { const pk = Game.picks[this.pi]; if (pk.length) { pk.pop(); A.play('back'); } else if (this.pi === 1) { this.pi = 0; Game.picks[0].pop(); } else { A.play('back'); RC.App.goto(Game.campaign ? 'menu' : Game.mode === 'training' ? 'trainmenu' : 'opp'); } return; }
      if (pickIdx >= 0) this.pick(IDS[pickIdx]);
    },
    draw(c) {
      bg(c, this.t); const id = IDS[this.sel], d = RC.DATA.characters[id], col = this.pi ? '#6ad8ff' : '#ff6a6a';
      T.draw(c, Game.mode === 'training' ? (this.pi ? 'ALVO DE TREINO ' : 'SEU TIME ') + (Game.picks[this.pi].length + 1) + '/' + this.N : Game.campaign ? (Game.campaign === 'arcade' ? 'ARCADE: ' : 'TORNEIO: ') + 'ESCOLHA SEU LUTADOR' : 'JOGADOR ' + (this.pi + 1) + ': ESCOLHA ' + (Game.picks[this.pi].length + 1) + '/' + this.N, 240, 14, { a: 'c', s: 2, c: col, ol: '#000' });
      IDS.forEach((cid, i) => { const r = this.cell(i), sel = i === this.sel; S.portrait(c, cid, r.x, r.y, r.w, r.h, { t: this.t }); const taken = Game.picks[this.pi].includes(cid); if (taken) { c.fillStyle = 'rgba(0,0,0,.6)'; c.fillRect(r.x, r.y, r.w, r.h); } c.strokeStyle = sel ? col : '#000'; c.lineWidth = sel ? 3 : 1; c.strokeRect(r.x + 0.5, r.y + 0.5, r.w - 1, r.h - 1); T.draw(c, RC.DATA.characters[cid].name, r.x + r.w / 2, r.y + r.h - 9, { a: 'c', c: '#fff', ol: '#000' }); });
      // slots
      for (let k = 0; k < 2; k++) for (let s = 0; s < this.N; s++) { const x = k ? 480 - 6 - 40 : 6, y = 44 + s * 52, pk = Game.picks[k][s]; c.fillStyle = 'rgba(0,0,0,.5)'; c.fillRect(x, y, 40, 48); if (pk) S.portrait(c, pk, x, y, 40, 48, { t: this.t, flip: !!k }); c.strokeStyle = k ? '#6ad8ff' : '#ff6a6a'; c.lineWidth = 1; c.strokeRect(x + 0.5, y + 0.5, 39, 47); if (!pk) T.draw(c, '?', x + 20, y + 20, { a: 'c', c: '#555a6e', s: 2 }); }
      T.draw(c, 'P1', 26, 34, { a: 'c', c: '#ff6a6a' }); T.draw(c, Game.vsCpu && Game.mode !== 'training' ? 'CPU' : 'P2', 454, 34, { a: 'c', c: '#6ad8ff' });
      button(c, { x: 190, y: 182, w: 100, h: 14 }, 'ALEATORIO', false); button(c, { x: 6, y: 250, w: 56, h: 16 }, 'VOLTAR', false);
      // info + preview animado
      T.draw(c, d.name, 240, 204, { a: 'c', s: 2, c: d.color, ol: '#000' }); T.draw(c, d.bio, 240, 222, { a: 'c', c: '#fff' });
      const anims = ['idle', 'walk', 'lp', 'hk', 'cast', 'win'], an = anims[Math.floor(this.t / 50) % anims.length], f = { id, baseId: id, x: 385, y: 262, face: 1, clock: this.t, anim: an, ext: an === 'lp' || an === 'hk' ? (Math.sin(this.t * 0.2) * 0.5 + 0.5) : 0, state: 'idle', form: null, flash: 0, walkDir: 1 };
      S.drawFighter(c, f); T.draw(c, 'ESCOLHA COM ENTER\nOU TOQUE NO RETRATO', 100, 240, { a: 'c', c: '#6a7088' });
    }
  };
  // ---------- seleção de cenário ----------
  Sc.stage = {
    enter() { this.t = 0; this.sel = Game.stage || 0; },
    update() {
      this.t++; const n = I.nav, p = I.ptr, N = RC.Stages.list.length + 1;
      if (n.left) { this.sel = (this.sel + N - 1) % N; A.play('select'); } if (n.right) { this.sel = (this.sel + 1) % N; A.play('select'); }
      let go = n.ok; const big = { x: 110, y: 40, w: 260, h: 146 };
      if (inR(p, big) && p.clicked) go = true;
      if (p.clicked) { if (inR(p, { x: 10, y: 90, w: 80, h: 50 })) { this.sel = (this.sel + N - 1) % N; A.play('select'); } if (inR(p, { x: 390, y: 90, w: 80, h: 50 })) { this.sel = (this.sel + 1) % N; A.play('select'); } for (let i = 0; i < N; i++) if (inR(p, this.thumb(i))) { if (this.sel === i) go = true; this.sel = i; A.play('select'); } }
      if (n.back || (p.clicked && inR(p, { x: 6, y: 250, w: 56, h: 16 }))) { A.play('back'); RC.App.goto('select'); return; }
      if (go) { A.play('confirm'); Game.stage = this.sel >= RC.Stages.list.length ? RC.ri(0, RC.Stages.list.length - 1) : this.sel; RC.App.goto('vs'); }
    },
    thumb(i) { return { x: 20 + i * 55, y: 206, w: 50, h: 28 }; },
    draw(c) {
      bg(c, this.t); T.draw(c, 'ESCOLHA O CENARIO', 240, 14, { a: 'c', s: 2, c: '#fff', ol: '#d8142f' }); const N = RC.Stages.list.length;
      c.save(); c.beginPath(); c.rect(110, 40, 260, 146); c.clip();
      if (this.sel < N) { c.translate(110, 40); c.scale(260 / 480, 146 / 270); RC.Stages.draw(c, this.sel, this.t, 0); RC.Stages.fore(c, this.sel, this.t); } else { c.fillStyle = '#111'; c.fillRect(110, 40, 260, 146); T.draw(c, '?', 240, 90, { a: 'c', s: 8, c: '#ffe14a' }); }
      c.restore(); c.strokeStyle = '#fff'; c.lineWidth = 2; c.strokeRect(110, 40, 260, 146);
      T.draw(c, this.sel < N ? RC.Stages.list[this.sel].name : 'ALEATORIO', 240, 192, { a: 'c', c: '#ffe14a', ol: '#000' });
      T.draw(c, '<', 50, 100, { a: 'c', s: 5, c: '#fff', ol: '#000' }); T.draw(c, '>', 430, 100, { a: 'c', s: 5, c: '#fff', ol: '#000' });
      for (let i = 0; i <= N; i++) { const r = this.thumb(i); c.save(); c.beginPath(); c.rect(r.x, r.y, r.w, r.h); c.clip(); if (i < N) { c.translate(r.x, r.y); c.scale(r.w / 480, r.h / 270); RC.Stages.draw(c, i, this.t, 0); } else { c.fillStyle = '#222'; c.fillRect(r.x, r.y, r.w, r.h); T.draw(c, '?', r.x + 25, r.y + 8, { a: 'c', s: 2, c: '#ffe14a' }); } c.restore(); c.strokeStyle = i === this.sel ? '#ffe14a' : '#000'; c.lineWidth = i === this.sel ? 2 : 1; c.strokeRect(r.x + 0.5, r.y + 0.5, r.w - 1, r.h - 1); }
      button(c, { x: 6, y: 250, w: 56, h: 16 }, 'VOLTAR', false); T.draw(c, 'ENTER OU TOQUE NO CENARIO PARA LUTAR', 240, 246, { a: 'c', c: '#6a7088' });
    }
  };
  // ---------- tela de VS com diálogos ----------
  Sc.vs = {
    enter() {
      this.t = 0; const a = Game.picks[0][0], b = Game.picks[1][0]; this.a = a; this.b = b; this.lines = Game.mode === 'training' ? [] : RC.Dialogue.get(a, b); this.li = 0; this.ch = 0; this.wait = 0; this.end = 0; A.music('vs'); I.showTouch(false); this.shown = 0;
    },
    update() {
      this.t++; const ok = I.nav.ok || I.ptr.clicked;
      if (this.t < 50) return;
      if (this.li >= this.lines.length) { if (++this.end > 20 || ok) this.start(); return; }
      const L = this.lines[this.li]; if (this.ch < L.text.length) { if (ok) this.ch = L.text.length; else { this.ch += 0.6; if (Math.floor(this.ch) !== this.shown) { this.shown = Math.floor(this.ch); if (this.shown % 2 === 0) A.play('blip'); } } this.wait = 0; }
      else { this.wait++; if (ok || this.wait > 140) { this.li++; this.ch = 0; this.wait = 0; } }
    },
    start() {
      if (Game.campaign && RC.Campaign.active) { RC.App.goto('fight', RC.Campaign.makeMatch()); return; }
      const mk2 = () => new RC.MatchClass({ mode: Game.mode, picks: Game.picks, cpu: [false, Game.vsCpu], diff: Game.diff, stage: Game.stage, onExit: act => { if (act === 'rematch') RC.App.goto('fight', mk2()); else RC.App.goto(act === 'select' ? 'select' : 'menu'); } });
      RC.App.goto('fight', mk2());
    },
    draw(c) {
      bg(c, this.t, '#3a6aff'); const k = Math.min(1, this.t / 24), e = 1 - Math.pow(1 - k, 3);
      for (let s = 0; s < 2; s++) {
        const id = s ? this.b : this.a, d = RC.DATA.characters[id], x = s ? 480 - 160 + (1 - e) * 200 : 10 - (1 - e) * 200;
        S.portrait(c, id, x, 20, 150, 170, { k: 5, flip: !!s, t: this.t }); c.strokeStyle = s ? '#6ad8ff' : '#ff6a6a'; c.lineWidth = 2; c.strokeRect(x, 20, 150, 170);
        T.draw(c, d.name, x + 75, 168, { a: 'c', s: 2, c: '#fff', ol: d.color }); const pk = Game.picks[s];
        if (pk.length > 1) pk.forEach((p2, j) => S.portrait(c, p2, x + 75 - pk.length * 14 + j * 28, 208, 24, 24, {}));
      }
      c.save(); c.translate(240, 100); const sc = 1 + Math.sin(this.t * 0.2) * 0.06; c.scale(sc, sc); T.draw(c, 'VS', 0, -20, { a: 'c', s: 8, c: '#ffe14a', ol: '#000', sh: '#6a1a00' }); c.restore();
      if (this.li < this.lines.length && this.t >= 50) {
        const L = this.lines[this.li], left = L.speaker === this.a, d = RC.DATA.characters[L.speaker], txt = L.text.slice(0, Math.floor(this.ch)), bw = 430, bx = 25, by = 214;
        c.fillStyle = 'rgba(0,0,0,.85)'; c.fillRect(bx, by, bw, 48); c.strokeStyle = d ? d.color : '#fff'; c.lineWidth = 2; c.strokeRect(bx, by, bw, 48);
        T.draw(c, (d ? d.name : L.speaker.toUpperCase()) + (L.draft ? '  (RASCUNHO)' : ''), left ? bx + 8 : bx + bw - 8, by - 9, { a: left ? 'l' : 'r', c: d ? d.color : '#fff', ol: '#000' });
        T.wrap(txt || ' ', bw - 16, L.shout ? 2 : 1).forEach((ln, i) => T.draw(c, ln, bx + 8, by + 8 + i * (L.shout ? 18 : 10), { s: L.shout ? 2 : 1, c: L.shout ? '#ffb0b0' : '#fff' }));
        if (this.ch >= L.text.length && (RC.frame >> 4) % 2) T.draw(c, '↓', bx + bw - 14, by + 36, { c: '#ffe14a' });
      }
      T.draw(c, RC.Stages.list[Game.stage].name, 240, 8, { a: 'c', c: '#8890a8' });
    }
  };
  // ---------- luta ----------
  Sc.fight = {
    enter(m) { this.m = m; I.showTouch(true); },
    update() { this.m.update(); },
    draw(c) { this.m.render(c); }
  };

  RC.UI = { bg, logo, button, mk, mUpdate, mDraw, roster, inR, fake, title, chamf, vignette, embers, IDS, Game };
  // ---------- App ----------
  RC.App = {
    cur: null, name: '',
    goto(name, p) { if (this.name === 'fight' && name !== 'fight') { RC.Match = null; RC.Cam.reset(); RC.FX.clear(); } this.name = name; this.cur = Sc[name]; I.clearHist(); if (this.cur.enter) this.cur.enter(p); },
    update() { tick++; this.cur.update(); },
    render(c) { this.cur.draw(c); }
  };
})();
