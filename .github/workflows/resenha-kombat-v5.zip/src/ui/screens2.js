// Telas extras: menu de treino, Arcade, Torneio, Personagens (poderes/forma/fusões), Como Jogar e editor dos botões de toque
(function () {
  const RC = window.RC, T = RC.Text, S = RC.Sprites, A = RC.Audio, I = RC.Input, W = RC.W, H = RC.H, Sc = RC.Screens, UI = RC.UI;
  const { bg, button, mk, mUpdate, mDraw, inR, fake, title, chamf, IDS, Game } = UI;
  const CH = id => RC.DATA.characters[id], NM = id => CH(id).name;
  const shuffle = a => { for (let i = a.length - 1; i > 0; i--) { const j = RC.ri(0, i); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  const panel = (c, x, y, w, h, col = '#5a6cff') => { c.fillStyle = 'rgba(6,6,16,.82)'; c.fillRect(x, y, w, h); c.strokeStyle = '#000'; c.lineWidth = 1; c.strokeRect(x - 0.5, y - 0.5, w + 1, h + 1); c.strokeStyle = col; c.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1); c.fillStyle = col; c.fillRect(x + 1, y + 1, w - 2, 1); };
  const mmss = ms => { const s = Math.floor(ms / 1000); return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); };
  const backBtn = { x: 6, y: 250, w: 60, h: 16 };
  const confetti = (c, t) => { const cols = ['#ff3b3b', '#ffe14a', '#3ad0ff', '#7aff7a', '#ff5ad8', '#fff']; for (let i = 0; i < 60; i++) { const x = (i * 97 + Math.sin(t * 0.03 + i) * 14) % W, y = (t * (0.8 + (i % 5) * 0.35) + i * 53) % H; c.fillStyle = cols[i % 6]; c.fillRect(Math.round(x), Math.round(y), 3, 2); } };

  // ---------- menu de treino ----------
  Sc.trainmenu = {
    enter() { this.t = 0; this.m = mk([{ label: '1 VS 1', sub: 'UM LUTADOR, HITBOXES VISIVEIS' }, { label: '2 VS 2', sub: 'PRATIQUE TROCA DE LUTADOR E FUSAO' }, { label: '3 VS 3', sub: 'TIME COMPLETO COM TROCA LIVRE' }, { label: 'VOLTAR' }], 64, 240, 34, 6); },
    update() {
      this.t++; const p = mUpdate(this.m); if (I.nav.back) { A.play('back'); RC.App.goto('menu'); return; }
      if (p >= 0 && p < 3) { Game.mode = 'training'; Game.trainN = p + 1; Game.vsCpu = true; Game.campaign = null; Game.picks = [[], []]; RC.App.goto('select'); } else if (p === 3) RC.App.goto('menu');
    },
    draw(c) {
      bg(c, this.t); title(c, 'TREINO', 20); mDraw(c, this.m);
      T.draw(c, 'SEM TIMER, BARRA CHEIA SEMPRE, O ALVO NAO MORRE.', 240, 236, { a: 'c', c: '#9aa4c0' });
      T.draw(c, 'TROCAR LUTADOR: ' + RC.keyName(I.map[0].swap) + '  -  FUSAO: ' + RC.keyName(I.map[0].fusion) + '  -  PAUSE: ESC', 240, 248, { a: 'c', c: '#2fe0c8' });
    }
  };

  // ---------- campanhas: Arcade e Torneio ----------
  const C = RC.Campaign = { active: false, type: null, me: null, ladder: [], idx: 0, continues: 0, fights: 0, t0: 0, rounds: [], round: 0, alive: true, champion: false };
  const ROUND_NAMES = ['QUARTAS DE FINAL', 'SEMIFINAL', 'FINAL'];
  C.begin = (type, me) => {
    C.active = true; C.type = type; C.me = me; C.idx = 0; C.continues = 0; C.fights = 0; C.t0 = Date.now(); C.champion = false; C.alive = true; C.round = 0;
    const others = shuffle(IDS.filter(i => i !== me));
    if (type === 'arcade') { C.ladder = others.slice(0, 6); RC.App.goto('ladder'); }
    else { const slots = shuffle([me].concat(others.slice(0, 7))); C.rounds = [slots]; RC.App.goto('bracket'); }
  };
  C.opp = () => { if (C.type === 'arcade') return C.ladder[C.idx]; const cur = C.rounds[C.round], i = cur.indexOf(C.me); return cur[i ^ 1]; };
  C.diffFor = () => C.type === 'arcade' ? RC.clamp(Math.round(Game.diff - 1 + C.idx * 0.7), 1, 5) : RC.clamp(Game.diff - 1 + C.round, 1, 5);
  C.nextFight = () => { C.fights++; Game.mode = '1v1'; Game.vsCpu = true; Game.picks = [[C.me], [C.opp()]]; Game.stage = RC.ri(0, RC.Stages.list.length - 1); RC.App.goto('vs'); };
  C.makeMatch = () => new RC.MatchClass({ mode: '1v1', picks: [[C.me], [C.opp()]], cpu: [false, true], diff: C.diffFor(), stage: Game.stage, auto: true, onExit: act => C.after(act) });
  C.resolve = won => { // fecha a rodada do torneio e simula as lutas entre CPUs
    const cur = C.rounds[C.round], next = [];
    for (let i = 0; i < cur.length; i += 2) { const a = cur[i], b = cur[i + 1]; if (a === C.me || b === C.me) next.push(won ? C.me : (a === C.me ? b : a)); else next.push(Math.random() < 0.5 ? a : b); }
    C.rounds.push(next); C.round++;
    if (!won) { C.alive = false; while (C.rounds[C.rounds.length - 1].length > 1) { const cu = C.rounds[C.rounds.length - 1], nx = []; for (let i = 0; i < cu.length; i += 2) nx.push(Math.random() < 0.5 ? cu[i] : cu[i + 1]); C.rounds.push(nx); } }
  };
  C.after = act => {
    if (act === 'menu') { C.active = false; RC.App.goto('menu'); return; }
    if (C.type === 'arcade') { if (act === 'win') { C.idx++; RC.App.goto(C.idx >= C.ladder.length ? 'ending' : 'ladder'); } else RC.App.goto('continue'); return; }
    C.resolve(act === 'win'); if (act === 'win' && C.rounds[C.rounds.length - 1].length === 1 && C.round >= 3) { C.champion = true; RC.App.goto('ending'); } else RC.App.goto('bracket');
  };

  Sc.ladder = {
    enter() { this.t = 0; I.showTouch(false); A.music('menu'); },
    update() { this.t++; const p = I.ptr; if (I.nav.back || (p.clicked && inR(p, backBtn))) { C.active = false; A.play('back'); RC.App.goto('menu'); return; } if (I.nav.ok || (p.clicked && inR(p, { x: 150, y: 204, w: 180, h: 26 }))) { A.play('confirm'); C.nextFight(); } },
    draw(c) {
      bg(c, this.t); title(c, 'ARCADE', 12, '#d8142f'); const n = C.ladder.length, me = CH(C.me);
      c.save(); c.translate(70, 196); c.scale(2, 2); S.drawFighter(c, fake(C.me, 'idle', this.t, 0, 0, 1)); c.restore(); T.draw(c, me.name, 70, 204, { a: 'c', c: me.color, ol: '#000' });
      for (let i = 0; i < n; i++) {
        const id = C.ladder[i], x = 130 + (i % 3) * 112, y = 40 + Math.floor(i / 3) * 72, done = i < C.idx, cur = i === C.idx;
        panel(c, x, y, 100, 68, cur ? '#ffe14a' : done ? '#3ddc5a' : '#444a6a'); S.portrait(c, id, x + 2, y + 2, 96, 64, { t: this.t }); if (done) { c.fillStyle = 'rgba(0,0,0,.55)'; c.fillRect(x + 2, y + 2, 96, 64); T.draw(c, 'VENCIDO', x + 50, y + 28, { a: 'c', c: '#3ddc5a', ol: '#000' }); } else if (!cur) { c.fillStyle = 'rgba(0,0,0,.35)'; c.fillRect(x + 2, y + 2, 96, 64); }
        T.draw(c, 'LUTA ' + (i + 1) + ' - ' + NM(id), x + 50, y + 58, { a: 'c', c: '#fff', ol: '#000' }); if (cur && (this.t >> 4) % 2) T.draw(c, 'PROXIMO', x + 50, y + 6, { a: 'c', c: '#ffe14a', ol: '#000' });
      }
      T.draw(c, 'PROXIMA LUTA: ' + NM(C.opp()) + '   DIFICULDADE: ' + RC.AI.names[C.diffFor() - 1], 240, 188, { a: 'c', c: '#ffe14a', ol: '#000' }); button(c, { x: 150, y: 204, w: 180, h: 26 }, 'LUTAR', true); button(c, backBtn, 'SAIR', false); T.draw(c, 'CONTINUES USADOS: ' + C.continues, 474, 254, { a: 'r', c: '#8890a8' });
    }
  };
  Sc.continue = {
    enter() { this.t = 0; this.n = 9; A.play('ko'); },
    update() {
      this.t++; if (this.t % 60 === 0) { this.n--; A.play('select'); }
      if (I.nav.ok || I.ptr.clicked) { A.play('confirm'); C.continues++; C.nextFight(); return; }
      if (this.n < 0 || I.nav.back) { C.active = false; RC.App.goto('menu'); }
    },
    draw(c) {
      bg(c, this.t, '#3a6aff', 0.85); title(c, 'FIM DE JOGO?', 30, '#3a6aff'); const k = 1 + (this.t % 60) / 60 * 0.15;
      c.save(); c.translate(240, 118); c.scale(k * 3, k * 3); T.draw(c, String(Math.max(0, this.n)), 0, -4, { a: 'c', s: 3, c: '#ffe14a', ol: '#000' }); c.restore();
      S.portrait(c, C.me, 190, 160, 100, 70, { t: this.t }); T.draw(c, 'TOQUE OU APERTE UMA TECLA PARA CONTINUAR', 240, 240, { a: 'c', c: '#fff', ol: '#000' });
    }
  };
  Sc.ending = {
    enter() { this.t = 0; A.music('menu'); A.play('bell'); this.ms = Date.now() - C.t0; },
    update() { this.t++; if (this.t > 60 && (I.nav.ok || I.nav.back || I.ptr.clicked)) { C.active = false; RC.App.goto('menu'); } },
    draw(c) {
      const arc = C.type === 'arcade'; bg(c, this.t, '#ffe14a', 0.7, 0); confetti(c, this.t);
      title(c, arc ? 'ARCADE COMPLETO!' : 'CAMPEAO DO TORNEIO!', 16, '#ffb000');
      c.save(); c.translate(240, 190); c.scale(3, 3); S.drawFighter(c, fake(C.me, this.t % 200 < 150 ? 'win' : 'idle', this.t, 0, 0, 1)); c.restore();
      if (!arc) { c.fillStyle = '#ffd24a'; c.fillRect(330, 120, 40, 8); c.fillRect(334, 128, 32, 22); c.fillRect(344, 150, 12, 14); c.fillRect(332, 164, 36, 6); c.fillStyle = '#fff3a0'; c.fillRect(336, 122, 4, 20); c.fillStyle = '#b8860b'; c.fillRect(366, 128, 3, 22); c.fillStyle = '#000'; c.strokeStyle = '#000'; c.strokeRect(333.5, 127.5, 33, 23); }
      T.draw(c, NM(C.me) + ' LEVOU A RESENHA ATE O FIM!', 240, 208, { a: 'c', c: '#fff', ol: '#000' });
      T.draw(c, 'LUTAS: ' + C.fights + '   CONTINUES: ' + C.continues + '   TEMPO: ' + mmss(this.ms), 240, 222, { a: 'c', c: '#ffe14a', ol: '#000' });
      if ((this.t >> 5) % 2) T.draw(c, 'TOQUE OU APERTE UMA TECLA', 240, 246, { a: 'c', c: '#fff', ol: '#000' });
    }
  };
  Sc.bracket = {
    enter() { this.t = 0; I.showTouch(false); A.music('menu'); },
    over() { return !C.alive || C.champion; },
    update() {
      this.t++; const p = I.ptr;
      if (I.nav.back || (p.clicked && inR(p, backBtn))) { C.active = false; A.play('back'); RC.App.goto('menu'); return; }
      if (I.nav.ok || (p.clicked && inR(p, { x: 372, y: 200, w: 100, h: 26 }))) { A.play('confirm'); if (this.over()) { C.active = false; RC.App.goto('menu'); } else C.nextFight(); }
    },
    slot(r, i) { const n = 8 >> r, span = 224 / n; return { x: [14, 112, 210, 308][r], y: 34 + i * span + (span - 24) / 2 }; },
    draw(c) {
      bg(c, this.t); title(c, 'TORNEIO', 8, '#d8142f'); const rd = C.rounds;
      c.fillStyle = '#5a6cff'; for (let r = 0; r < 3; r++) for (let i = 0; i < (8 >> r); i += 2) { const a = this.slot(r, i), b = this.slot(r, i + 1), n = this.slot(r + 1, i >> 1); c.fillRect(a.x + 24, a.y + 12, 8, 1); c.fillRect(b.x + 24, b.y + 12, 8, 1); c.fillRect(a.x + 32, a.y + 12, 1, b.y - a.y); c.fillRect(a.x + 32, (a.y + b.y) / 2 + 12, n.x - a.x - 32, 1); }
      for (let r = 0; r < 4; r++) for (let i = 0; i < (8 >> r); i++) {
        const sp = this.slot(r, i), id = rd[r] && rd[r][i], me = id === C.me; panel(c, sp.x, sp.y, 24, 24, me ? '#ffe14a' : '#444a6a');
        if (id) { S.portrait(c, id, sp.x + 1, sp.y + 1, 22, 22, {}); const lost = rd[r + 1] && rd[r + 1].length && !rd[r + 1].includes(id); if (lost) { c.fillStyle = 'rgba(0,0,0,.6)'; c.fillRect(sp.x + 1, sp.y + 1, 22, 22); } } else T.draw(c, '?', sp.x + 12, sp.y + 9, { a: 'c', c: '#555a6e' });
        if (r === 3) { T.draw(c, 'CAMPEAO', sp.x + 12, sp.y - 10, { a: 'c', c: '#ffe14a', ol: '#000' }); if (id) T.draw(c, NM(id), sp.x + 12, sp.y + 28, { a: 'c', c: '#fff', ol: '#000' }); }
      }
      panel(c, 372, 34, 100, 160, '#ff6a6a'); const over = this.over();
      if (over) { T.draw(c, C.champion ? 'VOCE E O' : 'VOCE FOI', 422, 48, { a: 'c', c: '#fff' }); T.draw(c, C.champion ? 'CAMPEAO!' : 'ELIMINADO', 422, 60, { a: 'c', s: 1, c: C.champion ? '#ffe14a' : '#ff5a5a' }); T.draw(c, 'NA ' + ROUND_NAMES[Math.min(2, C.round - 1)], 422, 76, { a: 'c', c: '#9aa4c0' }); }
      else { T.draw(c, ROUND_NAMES[C.round], 422, 42, { a: 'c', c: '#ffe14a' }); S.portrait(c, C.me, 380, 58, 40, 40, { t: this.t }); S.portrait(c, C.opp(), 424, 58, 40, 40, { t: this.t, flip: true }); T.draw(c, NM(C.me), 422, 102, { a: 'c', c: '#fff' }); T.draw(c, NM(C.opp()), 422, 112, { a: 'c', c: '#ff9a9a' }); T.draw(c, 'VS', 422, 74, { a: 'c', s: 2, c: '#ffe14a', ol: '#000' }); T.draw(c, 'DIF: ' + RC.AI.names[C.diffFor() - 1], 422, 128, { a: 'c', c: '#9aa4c0' }); }
      button(c, { x: 372, y: 200, w: 100, h: 26 }, over ? 'MENU' : 'LUTAR', true); button(c, backBtn, 'SAIR', false);
    }
  };

  // ---------- personagens: ficha, poderes, forma e fusões ----------
  const TABS = ['FICHA', 'PODERES', 'FATALITY', 'FORMA', 'FUSOES', 'SKINS'];
  const bar = (c, x, y, w, v, col, lab) => { T.draw(c, lab, x, y, { c: '#9aa4c0' }); c.fillStyle = '#000'; c.fillRect(x + 62, y - 1, w + 2, 9); c.fillStyle = '#23232e'; c.fillRect(x + 63, y, w, 7); c.fillStyle = col; c.fillRect(x + 63, y, Math.round(w * RC.clamp(v, 0, 1)), 7); c.fillStyle = 'rgba(255,255,255,.3)'; c.fillRect(x + 63, y, Math.round(w * RC.clamp(v, 0, 1)), 2); };
  Sc.chars = {
    enter() { this.t = 0; this.sel = Game._charSel || 0; this.tab = 0; this.sk = 0; I.showTouch(false); A.music('menu'); },
    cell(i) { return { x: 7 + i * 47, y: 18, w: 42, h: 40 }; }, tabR(i) { return { x: 162 + i * 52, y: 52, w: 50, h: 14 }; }, // lista de skins com rolagem: mostra 3 cartões por vez, acompanhando a seleção
    skOff() { const n = RC.Skins.list(IDS[this.sel]).length; return Math.max(0, Math.min(this.sk - 1, n - 3)); },
    skVis(i) { const k = i - this.skOff(); return k >= 0 && k < 3; },
    card(i) { return { x: 170, y: 74 + (i - this.skOff()) * 47, w: 296, h: 45 }; },
    equip(i) { const id = IDS[this.sel]; RC.Skins.set(id, i); A.play('confirm'); },
    update() {
      this.t++; const n = I.nav, p = I.ptr; Game._charSel = this.sel;
      const was = this.sel; if (n.left) { this.sel = (this.sel + 9) % 10; A.play('select'); this.t = 0; } if (n.right) { this.sel = (this.sel + 1) % 10; A.play('select'); this.t = 0; } if (this.sel !== was) this.sk = RC.Skins.get(IDS[this.sel]);
      const nsk = RC.Skins.list(IDS[this.sel]).length, ot = this.tab;
      if (n.up) { if (this.tab === 5 && this.sk > 0) this.sk--; else this.tab = (this.tab + 5) % 6; A.play('select'); } if (n.down) { if (this.tab === 5 && this.sk < nsk - 1) this.sk++; else this.tab = (this.tab + 1) % 6; A.play('select'); }
      if (this.tab === 5 && ot !== 5) this.sk = RC.Skins.get(IDS[this.sel]);
      let test = n.ok; if (this.tab === 5 && n.ok) { this.equip(this.sk); test = false; }
      if (p.clicked) { for (let i = 0; i < 10; i++) if (inR(p, this.cell(i))) { this.sel = i; this.t = 0; A.play('select'); } for (let i = 0; i < 6; i++) if (inR(p, this.tabR(i))) { this.tab = i; A.play('select'); if (i === 5) this.sk = RC.Skins.get(IDS[this.sel]); } if (this.tab === 5) for (let i = 0; i < nsk; i++) if (this.skVis(i) && inR(p, this.card(i))) { this.sk = i; this.equip(i); } if (inR(p, { x: 290, y: 248, w: 184, h: 18 })) test = true; if (inR(p, backBtn)) { A.play('back'); RC.App.goto('menu'); return; } }
      if (n.back) { A.play('back'); RC.App.goto('menu'); return; }
      if (test) { A.play('confirm'); Game.mode = 'training'; Game.trainN = 1; Game.vsCpu = true; Game.campaign = null; Game.picks = [[IDS[this.sel]], [IDS[(this.sel + 1) % 10]]]; Game.stage = 0; RC.App.goto('vs'); }
    },
    entry(c, x, y, w, label, name, desc, col) {
      T.draw(c, label, x, y, { c: '#7a84a8' }); T.draw(c, name, x, y + 9, { c: col || '#fff', ol: '#000' }); let yy = y + 20;
      for (const ln of T.wrap(desc || '', w)) { T.draw(c, ln, x, yy, { c: '#d8dcec' }); yy += 9; } return yy + 4;
    },
    draw(c) {
      const id = IDS[this.sel], d = CH(id), inf = RC.DATA.info[id], tr = RC.DATA.transformations[id], def = RC.Chars[id], fus = RC.DATA.fusions.filter(f => f.a === id || f.b === id); bg(c, this.t, d.color, 0.82);
      T.draw(c, 'PERSONAGENS', 240, 5, { a: 'c', s: 1, c: '#fff', ol: d.color });
      IDS.forEach((cid, i) => { const r = this.cell(i); S.portrait(c, cid, r.x, r.y, r.w, r.h, { t: this.t }); c.strokeStyle = i === this.sel ? '#ffe14a' : '#000'; c.lineWidth = i === this.sel ? 2 : 1; c.strokeRect(r.x + 0.5, r.y + 0.5, r.w - 1, r.h - 1); if (i !== this.sel) { c.fillStyle = 'rgba(0,0,0,.4)'; c.fillRect(r.x, r.y, r.w, r.h); } });
      // preview
      panel(c, 6, 70, 150, 172, d.color); const g = c.createLinearGradient(0, 70, 0, 242); g.addColorStop(0, 'rgba(255,255,255,.05)'); g.addColorStop(1, d.color + '55'); c.fillStyle = g; c.fillRect(7, 71, 148, 170);
      c.fillStyle = 'rgba(0,0,0,.4)'; c.beginPath(); c.ellipse(81, 226, 36, 6, 0, 0, 6.283); c.fill();
      let f; const anims = ['idle', 'walk', 'lp', 'hk', 'cast', 'win'], an = anims[Math.floor(this.t / 55) % anims.length];
      f = fake(id, an, this.t, 0, 0, 1); if (this.tab === 5) f.skinIdx = this.sk;
      if (this.tab === 4 && fus.length) { const fu = fus[Math.floor(this.t / 180) % fus.length]; f.fusionId = fu.id; f.baseId = fu.a; f.id = fu.a; f.auraCol = null; T.draw(c, fu.name, 81, 76, { a: 'c', c: '#fff', ol: '#000' }); }
      else if (this.tab === 3) { f.form = id; f.auraCol = tr.aura; T.draw(c, tr.name.toUpperCase(), 81, 76, { a: 'c', c: tr.aura, ol: '#000' }); }
      c.save(); c.translate(81, 226); c.scale(1.6, 1.6); S.drawFighter(c, f); c.restore();
      T.draw(c, d.name, 81, 232, { a: 'c', c: d.color, ol: '#000' });
      // abas
      TABS.forEach((tb, i) => { const r = this.tabR(i), on = i === this.tab; chamf(c, r.x, r.y, r.w, r.h, on ? '#fff' : '#000'); chamf(c, r.x + 1, r.y + 1, r.w - 2, r.h - 2, on ? '#c01830' : '#1a1c30'); T.draw(c, tb, r.x + r.w / 2, r.y + 4, { a: 'c', c: on ? '#fff' : '#9aa4c0' }); });
      panel(c, 162, 68, 312, 174, '#5a6cff'); const x = 170, w = 296; let y = 74;
      if (this.tab === 0) {
        T.draw(c, d.name, x, y, { s: 2, c: d.color, ol: '#000' }); T.draw(c, d.bio.toUpperCase(), x, y + 17, { c: '#fff' }); if (false) T.wrap(inf.estilo, w).slice(0, 1).forEach((l, k) => T.draw(c, l, x, y + 27 + k * 9, { c: '#9aa4c0' })); y += 42;
        const dm = d.moves.hp.dmg; bar(c, x, y, 120, d.stats.hp / 1150, '#3ddc5a', 'VIDA'); bar(c, x, y + 11, 120, d.stats.walk / 1.9, '#3ad0ff', 'VELOC.'); bar(c, x, y + 22, 120, dm / 95, '#ff6a6a', 'FORCA'); bar(c, x, y + 33, 120, d.stats.jump / 12, '#ffe14a', 'PULO');
        T.draw(c, 'RESENHATALITY', x + 200, y, { c: '#ff6a6a' }); T.draw(c, RC.HUD.cmdText(def.cmd, 1), x + 200, y + 10, { c: '#fff', ol: '#000' });
        T.draw(c, 'TRANSFORMACAO', x + 200, y + 24, { c: '#7a84a8' }); T.wrap(tr.name.toUpperCase(), 96).forEach((l, k) => T.draw(c, l, x + 200, y + 33 + k * 9, { c: tr.aura, ol: '#000' }));
        y += 52; T.draw(c, 'FORMA: ' + (tr.stat === 'pow' ? 'FORCA' : 'VELOCIDADE') + ' x3 POR ' + tr.dur + ' SEGUNDOS', x, y, { c: '#d8dcec' }); T.draw(c, 'ESPECIAL: ' + inf.especial.n.toUpperCase(), x, y + 12, { c: '#d8dcec' }); T.draw(c, 'ULTIMATE: ' + inf.ultimate.n.toUpperCase(), x, y + 22, { c: '#d8dcec' });
        T.draw(c, 'SETAS ESQ/DIR: PERSONAGEM   CIMA/BAIXO: ABA', x, 232, { c: '#555a6e' });
      } else if (this.tab === 1) {
        y = this.entry(c, x, y, w, 'ESPECIAL  [1 BARRA]', inf.especial.n.toUpperCase(), inf.especial.d, d.color);
        if (inf.especial2) y = this.entry(c, x, y, w, 'ESPECIAL 2  [BAIXO + ESPECIAL]', inf.especial2.n.toUpperCase(), inf.especial2.d, d.color);
        y = this.entry(c, x, y, w, 'ULTIMATE  [BARRA CHEIA, COM CUTSCENE]', inf.ultimate.n.toUpperCase(), inf.ultimate.d, '#ffe14a');
        if (inf.aux) this.entry(c, x, y, w, 'AUXILIAR', inf.aux.n.toUpperCase(), inf.aux.d, '#2fe0c8');
      } else if (this.tab === 2) {
        y = this.entry(c, x, y, w, 'RESENHATALITY  [VENCER A LUTA COM A BARRA CHEIA]', inf.fatality.n.toUpperCase(), inf.fatality.d, '#ff5a5a');
        T.draw(c, 'COMANDO (SETAS, ANALOGICO OU D-PAD):', x, y + 6, { c: '#9aa4c0' }); T.draw(c, RC.HUD.cmdText(def.cmd, 1), x, y + 18, { s: 2, c: '#fff', ol: '#d8142f' });
        T.draw(c, 'APARECE FINISH HIM! E VOCE TEM POUCOS SEGUNDOS.', x, y + 44, { c: '#7a84a8' }); T.draw(c, 'SO FUNCIONA EM LUTAS VALENDO, NAO NO TREINO.', x, y + 54, { c: '#7a84a8' });
      } else if (this.tab === 3) {
        T.draw(c, tr.name.toUpperCase(), x, y, { s: 2, c: tr.aura, ol: '#000' }); c.fillStyle = tr.aura; c.fillRect(x + w - 14, y, 12, 12); T.draw(c, (tr.stat === 'pow' ? 'FORCA' : 'VELOCIDADE') + ' x3 POR ' + tr.dur + ' SEG  [TRANSFORMAR: BARRA CHEIA]', x, y + 17, { c: '#d8dcec' }); y += 30;
        for (const pw of inf.forma.poderes) y = this.entry(c, x, y, w, 'PODER NA FORMA', pw.n.toUpperCase(), pw.d, tr.aura);
      } else if (this.tab === 5) {
        const lst = RC.Skins.list(id), eq = RC.Skins.get(id);
        const off = this.skOff();
        if (lst.length > 3) T.draw(c, (off > 0 ? '< ' : '') + 'SKIN ' + (this.sk + 1) + '/' + lst.length + (off + 3 < lst.length ? ' >' : '') + '  (ROLE COM CIMA/BAIXO)', 466, 221, { a: 'r', c: '#ffe14a', ol: '#000' });
        lst.forEach((sk, i) => {
          if (!this.skVis(i)) return;
          const r = this.card(i), cur = i === this.sk; c.fillStyle = cur ? 'rgba(90,108,255,.3)' : 'rgba(255,255,255,.05)'; c.fillRect(r.x - 2, r.y, r.w + 4, r.h);
          if (cur) { c.strokeStyle = '#ffe14a'; c.lineWidth = 1; c.strokeRect(r.x - 1.5, r.y + 0.5, r.w + 3, r.h - 1); }
          S.portrait(c, id, r.x + 2, r.y + 4, 36, 37, { skin: i, t: this.t });
          T.draw(c, sk.name, r.x + 44, r.y + 4, { c: cur ? '#ffe14a' : '#fff', ol: '#000' });
          if (i === eq) T.draw(c, 'EQUIPADO', r.x + r.w - 4, r.y + 4, { a: 'r', c: '#3ddc5a', ol: '#000' });
          T.wrap(sk.desc, r.w - 50).slice(0, 3).forEach((l, k) => T.draw(c, l, r.x + 44, r.y + 15 + k * 9, { c: '#aab2cc' }));
        });
        if (lst.length === 1) T.draw(c, 'ESTE PERSONAGEM AINDA NAO TEM SKINS EXTRAS.', x, 74 + 52, { c: '#7a84a8' });
        T.draw(c, 'CIMA/BAIXO: ESCOLHER   ENTER OU CLIQUE: EQUIPAR', x, 232, { c: '#555a6e' });
      } else {
        if (!fus.length) T.draw(c, 'SEM FUSOES', x, y, { c: '#9aa4c0' });
        fus.forEach((fu, k) => {
          const yy = y + k * 37, other = fu.a === id ? fu.b : fu.a, cur = Math.floor(this.t / 180) % fus.length === k; c.fillStyle = cur ? 'rgba(90,108,255,.25)' : 'rgba(255,255,255,.04)'; c.fillRect(x - 2, yy - 2, w + 4, 35);
          S.portrait(c, fu.a, x, yy, 18, 18, {}); T.draw(c, '+', x + 22, yy + 6, { c: '#fff' }); S.portrait(c, fu.b, x + 30, yy, 18, 18, {}); T.draw(c, '= ' + fu.name, x + 54, yy + 2, { c: '#ffe14a', ol: '#000' });
          T.draw(c, 'ESPECIAL: ' + fu.special.toUpperCase(), x + 54, yy + 12, { c: '#d8dcec' }); T.wrap(fu.visual, w - 54).slice(0, 1).forEach((l, q) => T.draw(c, l, x + 54, yy + 22 + q * 9, { c: '#7a84a8' }));
        });
        T.draw(c, 'FUSAO: DUPLA DO MESMO TIME + BARRA CHEIA (2V2/3V3). VIDA PROPRIA DE 1500.', x, 232, { c: '#555a6e' });
      }
      button(c, backBtn, 'VOLTAR', false); button(c, { x: 290, y: 248, w: 184, h: 18 }, 'TESTAR NO TREINO', false);
    }
  };

  // ---------- como jogar ----------
  const PAGES = () => {
    const m = I.map, k = (i, a) => RC.keyName(m[i][a]);
    return [
      ['OBJETIVO', ['MELHOR DE 3 ROUNDS DE 99 SEGUNDOS. ZERE A VIDA DO OPONENTE, OU TENHA MAIS VIDA QUANDO O TEMPO ACABAR.', '', 'A BARRA DE SUPER (3 SEGMENTOS) ENCHE QUANDO VOCE BATE E QUANDO APANHA.', 'A BARRA DE RESENHATALITY ENCHE BATENDO E LIBERA O FINAL BRUTAL.', '', 'SEGURE PARA TRAS PARA DEFENDER. GOLPES BAIXOS PEDEM DEFESA AGACHADA; ALTOS, DEFESA EM PE.']],
      ['TECLADO', ['JOGADOR 1: MOVER ' + k(0, 'u') + k(0, 'l') + k(0, 'd') + k(0, 'r') + '  SOCO ' + k(0, 'lp') + '/' + k(0, 'hp') + '  CHUTE ' + k(0, 'lk') + '/' + k(0, 'hk'), 'AGARRAO ' + k(0, 'grab') + '  ESPECIAL ' + k(0, 'special') + '  ULTIMATE ' + k(0, 'ultimate') + '  TRANSFORMAR ' + k(0, 'transform'), 'FUSAO ' + k(0, 'fusion') + '  AUX ' + k(0, 'aux') + '  TROCAR LUTADOR ' + k(0, 'swap'), '', 'JOGADOR 2: MOVER ' + k(1, 'u') + k(1, 'l') + k(1, 'd') + k(1, 'r') + '  SOCO ' + k(1, 'lp') + '/' + k(1, 'hp') + '  CHUTE ' + k(1, 'lk') + '/' + k(1, 'hk'), 'AGARRAO ' + k(1, 'grab') + '  ESPECIAL ' + k(1, 'special') + '  ULTIMATE ' + k(1, 'ultimate') + '  TRANSFORMAR ' + k(1, 'transform'), 'FUSAO ' + k(1, 'fusion') + '  AUX ' + k(1, 'aux') + '  TROCAR LUTADOR ' + k(1, 'swap'), '', 'PAUSE: ESC OU P. REMAPEIE TUDO EM OPCOES > CONTROLES DE TECLADO.']],
      ['TOQUE E GAMEPAD', ['TOQUE: ANALOGICO VIRTUAL A ESQUERDA (ARRASTE PARA ANDAR, PULAR E AGACHAR) E BOTOES COLORIDOS A DIREITA.', 'ICONES: PUNHO = SOCO, BOTA = CHUTE (COM EXPLOSAO = FORTE), MAO = AGARRAO, BOLA DE ENERGIA = ESPECIAL, ESTRELA = ULTIMATE, RAIO = TRANSFORMAR, ANEIS = FUSAO, PESSOA = AUXILIAR, SETAS = TROCAR LUTADOR.', 'O ANALOGICO FUNCIONA IGUAL AS SETAS NA RESENHATALITY: FACA O MOVIMENTO E APERTE O SOCO/CHUTE.', 'MUDE POSICAO, TAMANHO, OPACIDADE OU TROQUE POR D-PAD EM OPCOES > BOTOES DE TOQUE.', '', 'GAMEPAD: ANALOGICO/D-PAD MOVE, A/B/X/Y = SF/SH/CF/CH, LB AGARRAO, RB ESPECIAL, RT ULTIMATE, LT AUX, BACK TRANSFORMAR, START FUSAO, CLIQUE DO ANALOGICO = TROCA.']],
      ['PODERES', ['ESPECIAL: GASTA 1 BARRA. BAIXO + ESPECIAL USA O ESPECIAL 2 (TODDY E ALGUMAS FORMAS).', 'ULTIMATE: BARRA CHEIA (3), COM CUTSCENE E DANO ALTO.', 'TRANSFORMACAO: BARRA CHEIA. TRIPLICA FORCA OU VELOCIDADE POR 20 SEGUNDOS E TROCA SEUS PODERES (ESPECIAL E ULTIMATE DIFERENTES).', 'FUSAO (2V2/3V3): BARRA CHEIA E OS DOIS DA DUPLA VIVOS. 9 FUSOES, VIDA PROPRIA, DURA 30 SEGUNDOS.', 'AUXILIAR: HABILIDADE EXTRA DE ALGUNS LUTADORES (EX.: GUILHERME).', 'VEJA TUDO EM PERSONAGENS NO MENU.']],
      ['TIMES E TROCA', ['EM 2V2 E 3V3 CADA LUTADOR TEM VIDA PROPRIA. QUANDO UM CAI, O PROXIMO ENTRA AUTOMATICAMENTE.', 'TROCA MANUAL: APERTE TROCAR LUTADOR (' + k(0, 'swap') + ' / BOTAO TROCA) PARA MANDAR O PROXIMO VIVO ENTRAR. TEM UM PEQUENO TEMPO DE RECARGA.', 'A BARRA DE SUPER E COMPARTILHADA PELO TIME.', 'NO TREINO 2V2/3V3 VOCE PRATICA TROCA E FUSAO SEM PRESSA.']],
      ['RESENHATALITY', ['VENCA A LUTA COM A BARRA DE RESENHATALITY CHEIA. APARECE FINISH HIM!.', 'DIGITE O COMANDO DO SEU LUTADOR (SETAS, ANALOGICO OU D-PAD + SOCO/CHUTE). SE ERRAR, A LUTA TERMINA NORMAL.', '', 'GUILHERME ↓ → ↓ + SOCO FORTE   ARTHUR → → ↓ + SOCO FORTE', 'ALEXANDRE ↓ ↓ ↑ + CHUTE FORTE   KAIQUE ← → ↓ + CHUTE FORTE', 'TODDY → ↓ → + SOCO FORTE   MATHEUS ← ← → + SOCO FORTE', 'LUAN ↓ ↓ ↓ + SOCO FRACO   RAFAEL ↑ ↓ → + CHUTE FORTE', 'JOEL → ← → + SOCO FORTE   VITIN ↓ ← → + CHUTE FORTE']],
      ['MODOS', ['VERSUS: 1V1, 2V2 OU 3V3 CONTRA A CPU OU UM AMIGO NO MESMO APARELHO.', 'ARCADE: 6 LUTAS CONTRA A CPU, FICANDO MAIS DIFICIL. TEM CONTINUE.', 'TORNEIO: CHAVE DE 8 LUTADORES, QUARTAS, SEMI E FINAL.', 'TREINO: 1V1, 2V2 OU 3V3, SEM TIMER, COM HITBOXES E BARRA CHEIA.', 'PERSONAGENS: FICHA, PODERES, RESENHATALITY, FORMA E FUSOES DE CADA UM.']]
    ];
  };
  Sc.howto = {
    enter() { this.t = 0; this.pg = 0; I.showTouch(false); },
    update() {
      this.t++; const n = I.nav, p = I.ptr, N = PAGES().length;
      if (n.left) { this.pg = (this.pg + N - 1) % N; A.play('select'); } if (n.right || n.ok) { this.pg = (this.pg + 1) % N; A.play('select'); }
      if (p.clicked) { if (inR(p, { x: 6, y: 120, w: 40, h: 40 })) { this.pg = (this.pg + N - 1) % N; A.play('select'); } else if (inR(p, { x: 434, y: 120, w: 40, h: 40 })) { this.pg = (this.pg + 1) % N; A.play('select'); } else if (inR(p, backBtn)) { A.play('back'); RC.App.goto('menu'); return; } for (let i = 0; i < N; i++) if (inR(p, { x: 240 - N * 8 + i * 16, y: 232, w: 14, h: 12 })) { this.pg = i; A.play('select'); } }
      if (n.back) { A.play('back'); RC.App.goto('menu'); }
    },
    draw(c) {
      bg(c, this.t); title(c, 'COMO JOGAR', 10); const pages = PAGES(), pg = pages[this.pg]; panel(c, 50, 40, 380, 186, '#5a6cff');
      T.draw(c, pg[0], 240, 48, { a: 'c', s: 2, c: '#ffe14a', ol: '#000' }); let y = 68;
      for (const l of pg[1]) { if (!l) { y += 6; continue; } for (const ln of T.wrap(l, 360)) { T.draw(c, ln, 60, y, { c: '#e6e9f6' }); y += 10; } y += 2; }
      T.draw(c, '<', 26, 134, { a: 'c', s: 4, c: '#fff', ol: '#000' }); T.draw(c, '>', 454, 134, { a: 'c', s: 4, c: '#fff', ol: '#000' });
      pages.forEach((_, i) => { const x = 240 - pages.length * 8 + i * 16; c.fillStyle = '#000'; c.fillRect(x, 234, 12, 8); c.fillStyle = i === this.pg ? '#ffe14a' : '#3a3e5a'; c.fillRect(x + 1, 235, 10, 6); });
      button(c, backBtn, 'VOLTAR', false);
    }
  };

  // ---------- editor dos botões de toque ----------
  Sc.touchedit = {
    enter() { this.t = 0; I.touchEdit(true); I.showTouch(true, true); this.m = mk([1, 2, 3, 4, 5].map(i => ({ label: '' })), 34, 170, 18, 3); },
    leave() { I.touchEdit(false); I.showTouch(false); I.tsave(); RC.App.goto('options'); },
    lab(i) { const C = I.tcfg; return ['CONTROLE: ' + (C.stick ? 'ANALOGICO' : 'D-PAD'), 'TAMANHO: ' + Math.round(C.size * 100) + '%', 'OPACIDADE: ' + Math.round(C.opa * 100) + '%', 'RESETAR LAYOUT', 'SALVAR E VOLTAR'][i]; },
    change(i, d) { const C = I.tcfg; if (i === 0) C.stick = !C.stick; else if (i === 1) C.size = RC.clamp(Math.round((C.size + d * 0.1) * 10) / 10, 0.6, 1.6); else if (i === 2) C.opa = RC.clamp(Math.round((C.opa + d * 0.1) * 10) / 10, 0.3, 1); else if (i === 3) { I.touchReset(); } else { this.leave(); return; } A.play('select'); I.tsave(); I.touchLayout(); },
    update() {
      this.t++; const m = this.m, n = I.nav, p = I.ptr, k = m.items.length;
      if (n.up) { m.sel = (m.sel + k - 1) % k; A.play('select'); } if (n.down) { m.sel = (m.sel + 1) % k; A.play('select'); }
      if (n.left) this.change(m.sel, -1); if (n.right || n.ok) this.change(m.sel, 1);
      m.rects.forEach((r, i) => { if (inR(p, r)) { if (p.moved) m.sel = i; if (p.clicked) { m.sel = i; this.change(i, p.x < r.x + r.w / 2 ? -1 : 1); } } });
      if (n.back) this.leave();
    },
    draw(c) {
      c.fillStyle = 'rgba(8,6,20,.9)'; c.fillRect(0, 0, W, H); bg(c, this.t, '#3a6aff', 0.88); title(c, 'BOTOES DE TOQUE', 8, '#3a6aff');
      this.m.rects.forEach((r, i) => button(c, r, this.lab(i), this.m.sel === i));
      [['ARRASTE OS BOTOES PARA', 152, '#ffe14a'], ['ONDE QUISER. TOQUE NOS', 162, '#9aa4c0'], ['LADOS PARA AJUSTAR.', 172, '#9aa4c0']].forEach(a => T.draw(c, a[0], 240, a[1], { a: 'c', c: a[2], ol: '#000' }));
    }
  };
})();
