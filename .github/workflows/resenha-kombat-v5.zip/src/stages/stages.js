// 7 cenários em pixel art procedural. Camadas estáticas são pré-renderizadas UMA vez (rápido) e só copiadas a cada quadro;
// o que se mexe (fogo, torcida, neon, chuva...) é desenhado por "a(c,t,px)". Para usar arte pronta, troque uma camada por drawImage.
(function () {
  const RC = window.RC, GY = RC.GY, W = 480, H = 270, sh = RC.shade, T = RC.Text;
  const M = 90, X0 = -M, X1 = W + M, W2 = W + 2 * M;
  const R = (c, x, y, w, h, col) => { c.fillStyle = col; c.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h)); };
  const hs = n => { const s = Math.sin(n * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };
  const disc = (c, cx, cy, r, col) => { c.fillStyle = col; cx = Math.round(cx); cy = Math.round(cy); for (let y = -r; y <= r; y++) { const w = Math.floor(Math.sqrt(r * r - y * y + 0.5)); c.fillRect(cx - w, cy + y, 2 * w + 1, 1); } };
  const BAY = [[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]];
  const dither = (c, x, y, w, h, col, d) => { c.fillStyle = col; for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) if (BAY[(y + j) & 3][(x + i) & 3] < d * 16) c.fillRect(x + i, y + j, 1, 1); };
  const band = (c, y0, y1, cols, x0 = X0, x1 = X1) => { const n = cols.length, bh = (y1 - y0) / n; for (let i = 0; i < n; i++) { const ya = Math.round(y0 + i * bh), yb = Math.round(y0 + (i + 1) * bh); R(c, x0, ya, x1 - x0, yb - ya, cols[i]); if (i > 0) { dither(c, x0, ya - 3, x1 - x0, 1, cols[i], 0.25); dither(c, x0, ya - 2, x1 - x0, 1, cols[i], 0.5); dither(c, x0, ya - 1, x1 - x0, 1, cols[i], 0.75); } } };
  const bricks = (c, x, y, w, h, base, mort, bw = 10, bh = 5) => { R(c, x, y, w, h, mort); for (let r = 0, yy = y; yy < y + h; r++, yy += bh) for (let xx = x - (r % 2) * (bw >> 1); xx < x + w; xx += bw) { const a = Math.max(xx, x), b = Math.min(xx + bw - 1, x + w), hh = Math.min(bh - 1, y + h - yy); if (b > a) R(c, a, yy, b - a, hh, sh(base, (hs(xx * 3 + yy) - 0.5) * 0.22)); } };
  const bld = (c, x, y, w, h, base, o = {}) => {
    R(c, x, y, w, h, base); R(c, x, y, 2, h, sh(base, 0.16)); R(c, x + w - 3, y, 3, h, sh(base, -0.25)); R(c, x, y, w, 2, sh(base, 0.28)); R(c, x, y + 2, w, 1, sh(base, -0.12));
    if (o.win) { const cw = o.cw || 9, ch = o.ch || 13, cols = Math.floor((w - 6) / cw), rows = Math.floor((h - 10) / ch); for (let j = 0; j < rows; j++) for (let i = 0; i < cols; i++) { const lit = hs(x * 7 + i * 13 + j * 31) < (o.p == null ? 0.4 : o.p); const wx = x + 4 + i * cw, wy = y + 7 + j * ch; R(c, wx - 1, wy - 1, 7, 9, sh(base, -0.35)); R(c, wx, wy, 5, 7, lit ? o.lit : o.dark); if (lit) R(c, wx, wy, 5, 2, sh(o.lit, 0.4)); else R(c, wx, wy, 2, 3, sh(o.dark, 0.2)); } }
  };
  const glow = (c, x, y, r, col, a = 0.1) => { c.fillStyle = col; for (let i = 4; i >= 1; i--) { c.globalAlpha = a * (5 - i) * 0.6; disc(c, x, y, Math.round(r * i / 4), col); } c.globalAlpha = 1; };
  const pp = (c, x, y, o) => {
    const s = o.s || 1, k = v => Math.max(1, Math.round(v * s)), sk = o.sk || '#d9a066', top = o.top || '#c33', bot = o.bot || '#2a3550', hair = o.hair || '#2a1a10';
    x = Math.round(x); y = Math.round(y + (o.bob || 0));
    R(c, x - k(4), y - k(13), k(4), k(13), bot); R(c, x, y - k(13), k(4), k(13), sh(bot, -0.28)); R(c, x - k(5), y - k(2), k(5), k(2), '#17151a'); R(c, x, y - k(2), k(5), k(2), '#17151a');
    R(c, x - k(5), y - k(26), k(10), k(14), top); R(c, x + k(2), y - k(26), k(3), k(14), sh(top, -0.28)); R(c, x - k(5), y - k(26), k(10), 1, sh(top, 0.3));
    R(c, x - k(7), y - k(25), k(2), k(11), sh(top, -0.1)); R(c, x + k(5), y - k(25), k(2), k(11), sh(top, -0.35)); R(c, x - k(7), y - k(14), k(2), k(2), sk); R(c, x + k(5), y - k(14), k(2), k(2), sk);
    R(c, x - k(3), y - k(33), k(7), k(7), sk); R(c, x + k(2), y - k(33), k(2), k(7), sh(sk, -0.18)); R(c, x - k(4), y - k(35), k(9), k(4), hair); R(c, x - k(4), y - k(33), k(2), k(4), hair);
    if (o.phone) { R(c, x + k(5), y - k(20), k(3), k(5), '#16161c'); R(c, x + k(5), y - k(20), k(3), 1, '#7cf'); }
    if (o.cap) { R(c, x - k(4), y - k(36), k(9), k(3), o.cap); R(c, x + k(2), y - k(34), k(6), 1, sh(o.cap, -0.3)); }
  };
  const SK = ['#f0c8a0', '#d9a066', '#b97a4a', '#8a5a34', '#5e3a22'], HR = ['#14100c', '#2a1a10', '#4a2e18', '#c9a040', '#6a6a70'];
  const TP = ['#d4533b', '#3b82d4', '#59b36b', '#d4a93b', '#9a5ad4', '#d47a9a', '#e8e8e8', '#4a4a5a', '#e07a2c'];
  const crowd = (c, t, n, x0, dx, y, o = {}) => { for (let i = 0; i < n; i++) pp(c, x0 + i * dx + (o.j ? hs(i) * o.j : 0), y + (o.dy ? (i % 3) * o.dy : 0), { s: o.s || 1, top: TP[(i + (o.o || 0)) % 9], bot: ['#2a3550', '#3a3a44', '#5a4a3a', '#1f2a44'][i % 4], sk: SK[(i * 3 + 1) % 5], hair: HR[(i * 7) % 5], bob: Math.sin(t * (o.sp || 0.06) + i * 1.7) * (o.amp == null ? 1 : o.amp) * (hs(i + 5) > 0.5 ? 1 : 0.5), phone: o.phone && i % 3 === 0, cap: o.cap && i % 4 === 1 ? TP[(i + 3) % 9] : null }); };
  const poste = (c, x, y0, y1, col = '#4a4a52') => { R(c, x, y0, 4, y1 - y0, col); R(c, x, y0, 1, y1 - y0, sh(col, 0.25)); R(c, x + 3, y0, 1, y1 - y0, sh(col, -0.3)); R(c, x - 10, y0 + 6, 24, 2, col); R(c, x - 14, y0 + 2, 5, 3, sh(col, -0.2)); };
  const wire = (c, x0, y0, x1, y1, sag, col) => { c.fillStyle = col; const n = Math.abs(x1 - x0); for (let i = 0; i <= n; i++) { const u = i / n; c.fillRect(Math.round(x0 + (x1 - x0) * u), Math.round(y0 + (y1 - y0) * u + Math.sin(u * Math.PI) * sag), 1, 1); } };
  const tex = (c, x, y, w, h, col, n, seed) => { for (let i = 0; i < n; i++) R(c, x + hs(i + seed) * w, y + hs(i * 3 + seed + 7) * h, 1 + (i % 3), 1, col); };

  const ST = [];
  // ====================================================================== 1. CHURRASQUEIRA NA LAJE (pôr do sol)
  ST.push({
    id: 'laje', name: 'CHURRASQUEIRA NA LAJE', tint: '#ffa24a', layers: [
      { f: 0, d(c) { band(c, 0, 190, ['#2a1c52', '#40235e', '#6a2b6c', '#a03a6e', '#d4506a', '#ee6a45', '#f98f3c', '#ffb84e', '#ffd978']); for (let i = 0; i < 40; i++) R(c, hs(i) * W2 - M, hs(i + 50) * 60, 1, 1, '#ffeacc');
          glow(c, 360, 150, 80, '#ffd27a', 0.12); disc(c, 360, 150, 26, '#ffe9a0'); disc(c, 360, 150, 22, '#fff4c4'); dither(c, 334, 136, 52, 14, '#ffd27a', 0.3);
          for (let i = 0; i < 7; i++) { const cx = i * 90 - 40 + hs(i) * 30, cy = 40 + hs(i + 3) * 70; for (let k = 0; k < 4; k++) R(c, cx + k * 12, cy + (k % 2) * 3, 50 - k * 8, 6, k % 2 ? '#c4486a' : '#e8705a'); R(c, cx + 6, cy + 6, 44, 2, '#8a2f62'); } } },
      { f: 0.08, d(c) { for (let i = 0; i < 18; i++) { const bx = i * 34 + X0 + hs(i) * 8, bh = 45 + hs(i + 9) * 70; bld(c, bx, 178 - bh, 30, bh + 14, '#3c2250', { win: 1, lit: '#ffd070', dark: '#2a1840', p: 0.3 }); if (i % 5 === 1) { R(c, bx + 8, 178 - bh - 14, 12, 12, '#2a1840'); R(c, bx + 10, 178 - bh - 2, 2, 4, '#2a1840'); } if (i % 4 === 2) { R(c, bx + 14, 178 - bh - 18, 1, 18, '#2a1840'); R(c, bx + 10, 178 - bh - 14, 9, 1, '#2a1840'); } } } },
      { f: 0.22, d(c) { // morro / casas de tijolo, lajes, caixas d'água, parabólicas
          const cl = ['#7a3a32', '#9a5a3a', '#5a6a8a', '#8a7a5a', '#a04a4a', '#4a7a6a']; for (let i = 0; i < 16; i++) { const bx = i * 36 + X0 + hs(i + 20) * 6, bh = 36 + hs(i + 30) * 44, col = cl[i % 6]; bld(c, bx, 196 - bh, 34, bh, col, { win: 1, lit: '#ffc860', dark: sh(col, -0.5), cw: 11, ch: 15, p: 0.35 }); R(c, bx - 2, 196 - bh - 3, 38, 4, '#a7a29a'); R(c, bx - 2, 196 - bh - 3, 38, 1, '#cfcac0'); for (let k = 0; k < 3; k++) R(c, bx + 3 + k * 12, 196 - bh - 9, 1, 6, '#5a3a2a');
            if (i % 3 === 0) { R(c, bx + 6, 196 - bh - 22, 14, 18, '#2a6fb0'); R(c, bx + 6, 196 - bh - 22, 14, 3, '#5aa0e0'); R(c, bx + 17, 196 - bh - 22, 3, 18, '#1a4a80'); }
            if (i % 4 === 1) { disc(c, bx + 24, 196 - bh - 9, 5, '#d8d8e0'); disc(c, bx + 24, 196 - bh - 9, 3, '#8a8a98'); R(c, bx + 24, 196 - bh - 9, 1, 8, '#555'); } } } },
      { f: 0.5, d(c) { // parapeito de tijolo aparente + laje
          bricks(c, X0, 170, W2, 32, '#a4553a', '#d8c8b0', 12, 6); R(c, X0, 166, W2, 5, '#c8c2b6'); R(c, X0, 166, W2, 1, '#e8e4da'); R(c, X0, 170, W2, 1, '#8a867c'); for (let x = X0; x < X1; x += 60) { R(c, x, 150, 8, 18, '#b7b2a6'); R(c, x, 150, 8, 2, '#d8d4c8'); R(c, x + 6, 150, 2, 18, '#8a867c'); } } },
      { f: 0.5, d(c) { // bandeirinhas
          for (let s = 0; s < 3; s++) { const x0 = X0 + s * 200, ys = 20 + (s % 2) * 6; wire(c, x0, ys, x0 + 200, ys + 4, 14, '#3a2430'); const cols = ['#e53935', '#fdd835', '#43a047', '#1e88e5', '#ec407a', '#ff9800']; for (let i = 1; i < 20; i++) { const x = x0 + i * 10, u = i / 20, y = ys + 4 * u + Math.sin(u * Math.PI) * 14; const col = cols[(i + s) % 6]; for (let k = 0; k < 7; k++) R(c, x - 3 + (k >> 1), y + 1 + k, 7 - (k >> 1) * 2, 1, k < 1 ? sh(col, 0.2) : col); } } } },
      { f: 0, d(c) { // piso da laje: cimento queimado com juntas e manchas
          R(c, X0, 200, W2, 70, '#8f867a'); band(c, 200, 270, ['#9b9185', '#928879', '#8a8071', '#80776a']); for (let y = 206; y < 270; y += 22) R(c, X0, y, W2, 1, '#6e665a'); for (let x = X0; x < X1; x += 48) R(c, x, 200, 1, 70, '#6e665a'); tex(c, X0, 204, W2, 64, '#7a7164', 130, 1); tex(c, X0, 204, W2, 64, '#a89e90', 90, 5); R(c, X0, 198, W2, 3, '#5e564b'); R(c, X0, 201, W2, 1, '#b4aa9c');
          for (let i = 0; i < 4; i++) { c.globalAlpha = 0.18; disc(c, 70 + i * 130, 246 + (i % 2) * 10, 22, '#4a443a'); c.globalAlpha = 1; } } },
      { f: 0.5, d(c) { // churrasqueira de tijolo (esq) e mesa (dir)
          const gx = 18; bricks(c, gx, 138, 80, 62, '#a6482e', '#cfc0a4', 10, 5); R(c, gx - 4, 132, 88, 7, '#4a4a52'); R(c, gx - 4, 132, 88, 2, '#7a7a86'); R(c, gx + 10, 112, 22, 22, '#8a3a26'); R(c, gx + 8, 108, 26, 5, '#4a4a52'); R(c, gx + 6, 160, 68, 6, '#2a1c18'); R(c, gx + 8, 164, 64, 28, '#1a1210');
          for (let i = 0; i < 9; i++) R(c, gx + 10 + i * 7, 146, 2, 14, '#5a5a62'); R(c, gx + 6, 144, 68, 2, '#8a8a94');
          R(c, 372, 168, 84, 7, '#e4e0d6'); R(c, 372, 168, 84, 1, '#fff'); R(c, 378, 175, 4, 26, '#a8a49a'); R(c, 446, 175, 4, 26, '#a8a49a');
          R(c, 380, 150, 30, 18, '#d63a2e'); R(c, 380, 150, 30, 5, '#f4f0e8'); R(c, 380, 150, 1, 18, '#f06a5a'); R(c, 412, 156, 8, 12, '#2a6a3a'); R(c, 413, 152, 6, 5, '#3a8a4a'); R(c, 424, 158, 7, 10, '#6a4a1a'); R(c, 425, 154, 5, 5, '#8a6a2a'); R(c, 436, 160, 14, 8, '#fff'); R(c, 437, 161, 12, 1, '#c8c4b8');
          for (const [cx, col] of [[352, '#f4f4f0'], [462, '#f4f4f0']]) { R(c, cx, 176, 18, 4, col); R(c, cx + (cx < 400 ? 0 : 14), 158, 4, 22, col); R(c, cx + 1, 180, 3, 22, '#d8d8d0'); R(c, cx + 14, 180, 3, 22, '#d8d8d0'); R(c, cx, 176, 18, 1, '#fff'); }
          R(c, 340, 128, 34, 56, '#16161c'); R(c, 342, 130, 30, 52, '#22222c'); disc(c, 357, 150, 11, '#0c0c10'); disc(c, 357, 150, 8, '#303040'); disc(c, 357, 150, 3, '#0c0c10'); disc(c, 357, 128 + 42, 5, '#0c0c10'); } },
      { a(c, t, px) { // fogo, fumaça, lâmpadas, varal
          const gx = 18; for (let i = 0; i < 10; i++) { const h = 6 + hs(i + Math.floor(t / 6)) * 10; R(c, gx + 10 + i * 6, 166 - h, 4, h, i % 2 ? '#ff6a1a' : '#ff9a2a'); R(c, gx + 11 + i * 6, 166 - h * 0.5, 2, h * 0.5, '#ffe08a'); }
          glow(c, gx + 40, 168, 46, '#ff8a2a', 0.1);
          for (let i = 0; i < 10; i++) { const a = (t * 0.6 + i * 17) % 90; c.globalAlpha = 0.3 * (1 - a / 90); disc(c, gx + 20 + Math.sin(a * 0.1 + i) * 8 + a * 0.15, 110 - a, 3 + (a * 0.09) | 0, '#b8b0a8'); c.globalAlpha = 1; }
          for (let i = 0; i < 5; i++) { const a = (t * 1.1 + i * 29) % 44; R(c, gx + 14 + i * 12 + Math.sin(a * 0.3 + i) * 4, 130 - a, 1, 1, '#ffb040'); }
          for (let i = 0; i < 11; i++) { const x = i * 46 - 20, y = 56 + Math.sin(i * 0.9) * 3; R(c, x, y, 46, 1, '#2a1a22'); const on = hs(i + Math.floor(t / 40)) > 0.12; R(c, x + 21, y + 1, 3, 5, on ? '#fff1b0' : '#b89a60'); if (on) { glow(c, x + 22, y + 4, 14, '#ffe9a0', 0.1); } }
          const pulse = Math.abs(Math.sin(t * 0.3)) * 1.5; disc(c, 357, 150, 8 + (pulse | 0), '#3a3a4a'); disc(c, 357, 150, 4, '#0c0c10');
          for (let i = 0; i < 4; i++) { const x = 140 + i * 30 + Math.sin(t * 0.04 + i) * 2; R(c, x, 86, 18, 2, '#aaa'); R(c, x + 2, 88, 14, 20, ['#e8e8e0', '#4a8ad0', '#e8c44a', '#d85a5a'][i]); R(c, x + 2, 88, 14, 3, '#fff'); } } }
    ]
  });
  // ====================================================================== 2. QUADRA DE FUTSAL (noite)
  ST.push({
    id: 'quadra', name: 'QUADRA DE FUTSAL', tint: '#7ab8ff', layers: [
      { f: 0, d(c) { band(c, 0, 170, ['#04060e', '#080c1a', '#0e1428', '#16203c', '#202c50', '#2c3a62']); for (let i = 0; i < 60; i++) R(c, hs(i) * W2 - M, hs(i + 70) * 90, 1, 1, i % 4 ? '#8a9ac8' : '#fff'); disc(c, 70, 38, 12, '#e8ecf8'); disc(c, 74, 36, 11, '#04060e'); disc(c, 70, 38, 12, '#dfe4f2'); disc(c, 75, 35, 10, '#0a1020'); } },
      { f: 0.1, d(c) { for (let i = 0; i < 14; i++) { const bx = i * 42 + X0, bh = 40 + hs(i + 5) * 60; bld(c, bx, 170 - bh, 38, bh + 10, '#161d38', { win: 1, lit: '#ffe28a', dark: '#0e1428', p: 0.35 }); } R(c, 300, 66, 14, 100, '#1a2240'); R(c, 304, 44, 6, 24, '#1a2240'); R(c, 306, 36, 2, 10, '#1a2240'); R(c, 303, 52, 8, 2, '#ffe28a'); } },
      { f: 0.3, d(c) { // muro grafitado + arquibancada de concreto
          bricks(c, X0, 118, W2, 56, '#6a6e7c', '#505462', 16, 8); R(c, X0, 114, W2, 5, '#8a8e9a'); R(c, X0, 114, W2, 1, '#b4b8c4');
          const tag = (x, y, s, txt, col, o) => { T.draw(c, txt, x, y, { s, c: col, ol: o }); };
          tag(40, 128, 3, 'FC', '#ffd23a', '#2a1a0a'); tag(120, 136, 2, 'RESENHA', '#3ad0ff', '#0a2a4a'); tag(250, 124, 3, 'ZONA', '#ff5a8a', '#3a0a1a'); tag(350, 138, 2, 'SEM TETO', '#7aff7a', '#0a3a0a'); tag(430, 126, 3, 'XV', '#ffffff', '#3a0a3a');
          R(c, 190, 150, 34, 4, '#d8142f'); R(c, 192, 154, 30, 3, '#d8142f'); for (let i = 0; i < 6; i++) R(c, 60 + i * 70, 160, 2, 12, hs(i) > 0.5 ? '#3ad0ff' : '#ffd23a'); } },
      { f: 0, d(c) { // refletores
          for (const x of [60, 420]) { poste(c, x - 2, 70, 175, '#2a3350'); R(c, x - 24, 50, 48, 18, '#222c44'); R(c, x - 24, 50, 48, 2, '#4a5880'); for (let i = 0; i < 2; i++) for (let k = 0; k < 6; k++) R(c, x - 21 + k * 7, 53 + i * 7, 5, 5, '#fff8d0'); glow(c, x, 60, 50, '#fff8d0', 0.12); c.globalAlpha = 0.07; c.fillStyle = '#fff8d0'; c.beginPath(); c.moveTo(x - 20, 66); c.lineTo(x + 20, 66); c.lineTo(x + 140, 232); c.lineTo(x - 140, 232); c.fill(); c.globalAlpha = 1; } } },
      { a(c, t) { crowd(c, t, 30, 8 - 0, 17, 196, { s: 1, o: 2, sp: 0.18, amp: 3, cap: 1 }); for (let i = 0; i < 7; i++) { const x = 20 + i * 70, b = Math.sin(t * 0.2 + i) * 3; R(c, x, 150 + b, 14, 20, TP[i % 9]); R(c, x + 6, 130 + b, 2, 22, '#cfcfcf'); } } },
      { f: 0, d(c) { // alambrado
          for (let x = X0; x < X1; x += 5) R(c, x, 140, 1, 62, 'rgba(160,172,196,.5)'); for (let y = 140; y < 202; y += 5) R(c, X0, y, W2, 1, 'rgba(160,172,196,.32)'); R(c, X0, 136, W2, 4, '#9aa4b8'); R(c, X0, 136, W2, 1, '#cfd6e4'); for (let x = X0; x < X1; x += 64) { R(c, x, 128, 5, 78, '#9aa4b8'); R(c, x, 128, 1, 78, '#d0d8e6'); R(c, x + 4, 128, 1, 78, '#5a6478'); } } },
      { f: 0, d(c) { // piso azul de quadra
          band(c, 200, 270, ['#1c5fb8', '#1a58aa', '#16509c', '#12468a']); R(c, X0, 202, W2, 4, '#c8342e'); for (let y = 206; y < 270; y += 17) R(c, X0, y, W2, 1, 'rgba(8,24,60,.35)'); tex(c, X0, 208, W2, 60, '#2a72cc', 120, 3); tex(c, X0, 208, W2, 60, '#0e3a78', 80, 8);
          c.fillStyle = 'rgba(255,255,255,.85)'; for (let a = 0; a < 360; a += 2) { const r = a * Math.PI / 180; c.fillRect(Math.round(240 + Math.cos(r) * 78), Math.round(246 + Math.sin(r) * 14), 2, 1); } R(c, 239, 232, 2, 32, 'rgba(255,255,255,.85)'); R(c, X0, 231, W2, 2, 'rgba(255,255,255,.85)'); disc(c, 240, 246, 2, '#fff');
          R(c, 0, 150, 4, 50, '#f2f2f2'); R(c, 0, 150, 46, 4, '#f2f2f2'); for (let i = 0; i < 7; i++) R(c, 6 + i * 7, 154, 1, 46, 'rgba(255,255,255,.4)'); for (let j = 0; j < 8; j++) R(c, 4, 158 + j * 6, 42, 1, 'rgba(255,255,255,.3)'); } }
    ]
  });
  // ====================================================================== 3. FILA DO PIX NA PADARIA
  ST.push({
    id: 'padaria', name: 'FILA DO PIX NA PADARIA', tint: '#ffd98a', layers: [
      { f: 0, d(c) { R(c, X0, 0, W2, 200, '#f2e4c0'); band(c, 0, 80, ['#f6ead0', '#f2e4c0', '#eedcb2']);
          for (let y = 84; y < 168; y += 10) for (let x = X0; x < X1; x += 14) { R(c, x, y, 13, 9, ((x / 14 + y / 10) & 1) ? '#fbfaf4' : '#f0eee4'); R(c, x, y, 13, 1, '#fff'); R(c, x + 12, y, 1, 9, '#d8d4c4'); }
          R(c, X0, 80, W2, 5, '#2a5aa8'); R(c, X0, 80, W2, 1, '#5a8ad8'); R(c, X0, 84, W2, 1, '#18386a'); for (let x = X0; x < X1; x += 14) { R(c, x + 5, 86, 4, 3, '#2a5aa8'); }
          R(c, X0, 166, W2, 4, '#7a5030'); R(c, X0, 166, W2, 1, '#a07040'); } },
      { f: 0.15, d(c) { // placa e letreiro
          R(c, 120, 34, 240, 40, '#7a1d18'); R(c, 122, 36, 236, 36, '#c8382e'); R(c, 122, 36, 236, 3, '#e8685a'); R(c, 122, 69, 236, 3, '#8a2a22'); T.draw(c, 'PADARIA PAO QUENTE', 240, 46, { a: 'c', s: 2, c: '#ffe9a0', sh: '#5a0f0a' }); T.draw(c, 'CAFE  SALGADOS  PAES', 240, 62, { a: 'c', s: 1, c: '#ffd0c0' });
          R(c, 18, 56, 70, 90, '#fff'); R(c, 18, 56, 70, 14, '#1fb5a0'); R(c, 18, 56, 70, 2, '#5ad8c8'); T.draw(c, 'PIX', 53, 59, { a: 'c', s: 1, c: '#fff' }); for (let i = 0; i < 9; i++) for (let j = 0; j < 9; j++) if (hs(i * 9 + j + 3) > 0.48 || (i < 3 && j < 3) || (i > 5 && j < 3) || (i < 3 && j > 5)) R(c, 24 + i * 6, 74 + j * 6, 5, 5, '#111'); R(c, 24, 70, 18, 18, 'rgba(0,0,0,0)'); T.draw(c, 'PAGUE AQUI', 53, 134, { a: 'c', s: 1, c: '#1a8a7a' });
          R(c, 392, 60, 54, 40, '#1a1a1e'); R(c, 394, 62, 50, 34, '#2a3a50'); R(c, 394, 62, 50, 3, '#4a6a90'); R(c, 400, 74, 38, 3, '#e8e8e8'); R(c, 400, 82, 26, 3, '#aaa'); R(c, 414, 100, 6, 6, '#1a1a1e'); disc(c, 420, 124, 14, '#fbfaf4'); disc(c, 420, 120, 12, '#f4f0e0'); R(c, 419, 114, 2, 10, '#222'); R(c, 419, 124, 8, 2, '#222'); } },
      { f: 0.3, d(c) { // balcão, vitrine, estufa de salgados
          R(c, 120, 150, 280, 52, '#7a4a28'); R(c, 120, 150, 280, 3, '#a87444'); for (let x = 124; x < 396; x += 28) { R(c, x, 156, 24, 40, '#6a3e20'); R(c, x, 156, 24, 2, '#8a5a34'); R(c, x + 21, 156, 3, 40, '#4a2a14'); }
          R(c, 124, 100, 160, 52, '#cfe8ee'); R(c, 126, 102, 156, 48, '#e6f6fa'); R(c, 124, 100, 160, 2, '#fff'); R(c, 124, 98, 160, 3, '#4a4a52'); for (let s = 0; s < 3; s++) R(c, 126, 112 + s * 14, 156, 2, '#9ab4bc');
          for (let i = 0; i < 12; i++) { const x = 130 + i * 13; R(c, x, 106, 10, 6, '#d89a4a'); R(c, x + 1, 106, 8, 2, '#f0c070'); R(c, x + 6, 106, 3, 6, '#b8742f'); } for (let i = 0; i < 8; i++) { const x = 132 + i * 18; R(c, x, 120, 12, 9, '#e0a040'); R(c, x + 1, 119, 10, 2, '#f8d070'); R(c, x + 8, 122, 3, 7, '#b87a28'); } for (let i = 0; i < 6; i++) { const x = 130 + i * 24; disc(c, x + 8, 142, 6, '#c8a070'); R(c, x + 2, 138, 12, 2, '#f6e0b0'); disc(c, x + 8, 138, 2, '#c8202a'); }
          R(c, 296, 108, 40, 42, '#e4e4de'); R(c, 296, 108, 40, 3, '#fff'); R(c, 300, 116, 32, 26, '#2a2a30'); R(c, 302, 118, 28, 22, '#3a4a5a'); R(c, 302, 140, 28, 1, '#5a6a7a'); for (let i = 0; i < 5; i++) R(c, 306 + i * 5, 124 + (i % 2) * 4, 3, 12, ['#d83a2a', '#e8c040', '#3a8ad8'][i % 3]);
          R(c, 346, 130, 44, 20, '#d8d8d2'); R(c, 346, 130, 44, 3, '#fff'); R(c, 352, 134, 16, 10, '#1a1a20'); R(c, 354, 136, 12, 4, '#3ad8a0'); R(c, 372, 134, 14, 12, '#2a2a30'); } },
      { f: 0, d(c) { // piso xadrez
          for (let y = 0; y < 4; y++) for (let x = -2; x < 24; x++) R(c, x * 24 + (y % 2) * 12, 200 + y * 18, 24, 18, (x + y) & 1 ? '#e4d4ae' : '#8e7c58'); for (let y = 0; y < 4; y++) { R(c, X0, 200 + y * 18, W2, 1, '#6a5a3a'); } band(c, 200, 272, ['rgba(255,255,255,0)']); R(c, X0, 198, W2, 3, '#5a4a30'); R(c, X0, 200, W2, 1, '#a89870'); c.fillStyle = 'rgba(0,0,0,.12)'; c.fillRect(X0, 254, W2, 18); } },
      { a(c, t) { for (let i = 0; i < 4; i++) { const x = 60 + i * 110, y = 22 + (i % 2) * 2; R(c, x, 0, 1, y, '#2a2a30'); R(c, x - 6, y, 13, 6, '#3a3a40'); R(c, x - 4, y + 6, 9, 3, '#fff0b0'); glow(c, x, y + 10, 26, '#fff0b0', 0.07); }
          crowd(c, t, 7, 420, 26, 238, { s: 1.15, o: 1, phone: 1, sp: 0.05 }); crowd(c, t, 6, 36, 26, 240, { s: 1.15, o: 4, sp: 0.05 }); } }
    ]
  });
  // ====================================================================== 4. LAN HOUSE ANOS 2000
  ST.push({
    id: 'lan', name: 'LAN HOUSE RAIZ ANOS 2000', tint: '#6fe3ff', layers: [
      { f: 0, d(c) { band(c, 0, 200, ['#12131f', '#161828', '#1a1d30', '#1a1d30']); for (let x = X0; x < X1; x += 24) R(c, x, 0, 1, 200, 'rgba(255,255,255,.03)');
          for (let i = 0; i < 4; i++) { const x = 20 + i * 118; R(c, x, 84, 54, 66, '#0c0c14'); R(c, x + 2, 86, 50, 62, ['#a8281e', '#1e5a98', '#1e8a4a', '#6a2a98'][i]); R(c, x + 2, 86, 50, 4, 'rgba(255,255,255,.25)'); disc(c, x + 27, 112, 11, 'rgba(0,0,0,.35)'); R(c, x + 12, 126, 30, 3, '#fff'); R(c, x + 12, 132, 22, 2, 'rgba(255,255,255,.6)'); R(c, x + 4, 138, 46, 1, 'rgba(255,255,255,.4)'); }
          R(c, 380, 44, 80, 70, '#1a1c2c'); R(c, 384, 48, 72, 62, '#0a1230'); for (let i = 0; i < 7; i++) R(c, 384, 48 + i * 9, 72, 3, '#2a3a68'); R(c, 384, 48, 72, 62, 'rgba(60,120,255,.12)'); } },
      { f: 0.2, d(c) { for (let row = 0; row < 2; row++) for (let i = -1; i < 10; i++) { const x = i * 56 + (row ? 20 : 0), y = 128 + row * 34; R(c, x - 6, y + 24, 56, 6, '#5a4630'); R(c, x - 6, y + 24, 56, 1, '#8a6a46'); R(c, x + 2, y + 30, 4, 22, '#3a2e22'); R(c, x + 40, y + 30, 4, 22, '#3a2e22'); R(c, x + 4, y - 4, 38, 30, '#d4cfbc'); R(c, x + 4, y - 4, 38, 2, '#f0ecda'); R(c, x + 40, y - 4, 2, 30, '#a8a28e'); R(c, x + 7, y, 32, 22, '#0e0e12'); R(c, x + 16, y + 26, 14, 4, '#bdb7a2'); R(c, x + 6, y + 31, 24, 4, '#c8c2ae'); R(c, x + 32, y + 31, 9, 5, '#26262c'); } } },
      { f: 0, d(c) { band(c, 204, 272, ['#2a2f4c', '#252a44', '#20243a', '#1a1d30']); for (let i = 0; i < 90; i++) R(c, hs(i) * W2 - M, 206 + hs(i + 9) * 64, 6, 1, 'rgba(255,255,255,.07)'); tex(c, X0, 206, W2, 62, '#14172a', 120, 2); R(c, X0, 200, W2, 4, '#0c0e1a'); R(c, X0, 204, W2, 1, '#3a4266');
          c.fillStyle = '#05050a'; for (let i = 0; i < 8; i++) wire(c, i * 80 - 20, 204, i * 80 + 60, 206, 10 + (i % 3) * 3, '#05050a'); wire(c, 10, 206, 170, 204, 12, '#b33'); wire(c, 200, 206, 360, 205, 11, '#33b'); wire(c, 330, 205, 470, 207, 10, '#3a3'); } },
      { a(c, t) { for (let row = 0; row < 2; row++) for (let i = -1; i < 10; i++) { const x = i * 56 + (row ? 20 : 0), y = 128 + row * 34, col = ['#2c8cff', '#27e0a0', '#ff6b5a', '#c8ff4a', '#ffc94a'][(i + row * 2 + 5) % 5]; R(c, x + 9, y + 2, 28, 18, col); for (let k = 0; k < 4; k++) R(c, x + 11, y + 4 + k * 4, 6 + (hs(i * 5 + k + Math.floor(t / 24) + row) * 16 | 0), 2, 'rgba(255,255,255,.55)'); R(c, x + 9, y + 2, 28, 2, 'rgba(255,255,255,.35)'); c.globalAlpha = 0.06 + Math.sin(t * 0.1 + i) * 0.015; R(c, x - 6, y - 12, 56, 52, col); c.globalAlpha = 1; }
          const fl = (Math.floor(t / 40) % 9 === 0) ? 0.3 : 1; c.globalAlpha = fl; T.draw(c, 'LAN HOUSE', 240, 44, { a: 'c', s: 3, c: '#37f0ff', sh: '#0a5a66' }); glow(c, 240, 54, 90, '#37f0ff', 0.05); c.globalAlpha = 1; T.draw(c, '2 REAIS A HORA', 240, 70, { a: 'c', s: 1, c: '#ff4fd8' }); T.draw(c, 'XEROX  IMPRESSAO  JOGOS', 240, 82, { a: 'c', s: 1, c: '#9a9ab0' });
          const fx = 120, fy = 50, ang = t * 0.2; for (let k = 0; k < 3; k++) { const a = ang + k * 2.094; c.fillStyle = '#3a3a48'; for (let u = 4; u < 30; u++) c.fillRect(Math.round(fx + Math.cos(a) * u), Math.round(fy + Math.sin(a) * u * 0.25), 2, 1); } R(c, fx - 2, fy - 2, 5, 5, '#6a6a7a'); } }
    ]
  });
  // ====================================================================== 5. CALÇADA DO BAR (noite)
  ST.push({
    id: 'bar', name: 'CALCADA DO BAR', tint: '#ff4fd8', layers: [
      { f: 0, d(c) { band(c, 0, 200, ['#0a0618', '#120a28', '#1c1038', '#2a1648', '#3a1c56']); for (let i = 0; i < 40; i++) R(c, hs(i) * W2 - M, hs(i + 20) * 70, 1, 1, '#d8c8f8'); disc(c, 420, 40, 10, '#f4ecd4'); disc(c, 424, 38, 9, '#12082a'); disc(c, 420, 40, 10, '#ece4cc'); disc(c, 425, 37, 9, '#160a2e'); } },
      { f: 0.12, d(c) { for (let i = 0; i < 12; i++) { const x = i * 48 + X0, h = 90 + hs(i) * 50, base = ['#1e1436', '#241a3e', '#1a1230'][i % 3]; bld(c, x, 196 - h, 44, h, base, { win: 1, lit: '#ffcf70', dark: '#120a24', cw: 12, ch: 18, p: 0.4 }); } } },
      { f: 0.3, d(c) { // fachada do boteco
          const bx = 96; R(c, bx - 6, 56, 292, 146, '#2a1830'); bricks(c, bx, 62, 280, 140, '#4a2a44', '#2e1a30', 14, 7); R(c, bx - 10, 50, 300, 10, '#16081c'); R(c, bx - 10, 50, 300, 2, '#4a2a52'); R(c, bx, 76, 280, 4, '#8a1a2a'); R(c, bx, 76, 280, 1, '#d8344a');
          R(c, bx + 14, 118, 252, 84, '#0e0810'); R(c, bx + 16, 120, 248, 80, '#e8a43c'); band(c, 120, 200, ['#f4b848', '#eaa43a', '#d88a2c'], bx + 16, bx + 264); for (let i = 0; i < 4; i++) { R(c, bx + 40 + i * 58, 118, 3, 84, '#0e0810'); }
          R(c, bx + 16, 118, 248, 7, '#c8302a'); for (let i = 0; i < 30; i++) R(c, bx + 18 + i * 8, 118, 4, 7, '#e8584a');
          R(c, bx + 22, 166, 236, 6, '#6a3a18'); R(c, bx + 22, 166, 236, 1, '#a8682a'); for (let i = 0; i < 22; i++) { const h = 16 + (i % 3) * 4; R(c, bx + 26 + i * 10, 166 - h, 5, h, ['#3a8a3a', '#a46a2a', '#2a5ab0', '#c8c8c0'][i % 4]); R(c, bx + 27 + i * 10, 166 - h, 1, h, 'rgba(255,255,255,.4)'); R(c, bx + 27 + i * 10, 166 - h - 3, 3, 3, '#ddd'); }
          R(c, bx + 190, 128, 60, 36, '#e8e8e2'); R(c, bx + 190, 128, 60, 2, '#fff'); R(c, bx + 192, 134, 56, 28, '#a8d8f0'); R(c, bx + 192, 134, 56, 28, 'rgba(255,255,255,.2)'); for (let i = 0; i < 10; i++) R(c, bx + 196 + i * 5, 140 + (i % 3) * 6, 3, 14, ['#3a8a3a', '#a46a2a'][i % 2]);
          poste(c, 430, 70, 206, '#2a2a32'); wire(c, 434, 80, 520, 74, 14, '#08060c'); wire(c, 434, 82, -50, 76, 14, '#08060c'); } },
      { f: 0, d(c) { // calçada e rua
          R(c, X0, 202, W2, 32, '#6c6578'); band(c, 202, 234, ['#7a7388', '#6c6578', '#605a6e']); for (let x = X0; x < X1; x += 40) { R(c, x, 202, 1, 32, '#4a4458'); } for (let x = X0; x < X1; x += 20) R(c, x + (((x / 20) & 1) ? 10 : 0), 218, 1, 16, '#524c62'); R(c, X0, 218, W2, 1, '#524c62'); tex(c, X0, 204, W2, 30, '#8a8498', 60, 4);
          R(c, X0, 232, W2, 5, '#a09aae'); R(c, X0, 232, W2, 1, '#d0cae0'); R(c, X0, 236, W2, 1, '#3a3446'); band(c, 237, 272, ['#2e2a3a', '#26222f', '#1e1a26']); for (let i = 0; i < 7; i++) R(c, i * 90 - 20, 256, 44, 3, '#d6c44a'); tex(c, X0, 240, W2, 30, '#403a50', 60, 9); R(c, X0, 200, W2, 2, '#3a3446'); } },
      { f: 0.3, d(c) { for (const [x, col] of [[28, '#e53935'], [330, '#fdd835']]) { R(c, x, 196, 50, 5, col); R(c, x, 196, 50, 1, sh(col, 0.4)); R(c, x + 22, 201, 6, 26, '#e0e0e0'); R(c, x + 12, 226, 26, 3, '#c8c8c8'); for (const cx of [x - 16, x + 54]) { R(c, cx, 202, 12, 4, col); R(c, cx + (cx < x ? 0 : 8), 184, 4, 20, col); R(c, cx + 1, 206, 3, 20, '#e0e0e0'); R(c, cx + 8, 206, 3, 20, '#e0e0e0'); } R(c, x + 8, 187, 6, 9, '#3a8a3a'); R(c, x + 9, 184, 4, 4, '#4aaa4a'); R(c, x + 30, 189, 9, 7, '#f0f0ec'); R(c, x + 40, 190, 5, 6, '#c8a040'); }
          R(c, 380, 196, 30, 16, '#c8302a'); R(c, 372, 202, 14, 14, '#16161c'); disc(c, 376, 216, 6, '#16161c'); disc(c, 376, 216, 3, '#6a6a72'); R(c, 392, 204, 20, 6, '#16161c'); disc(c, 408, 216, 6, '#16161c'); disc(c, 408, 216, 3, '#6a6a72'); R(c, 372, 196, 22, 4, '#e8e8e8'); } },
      { a(c, t) { const bx = 96, fl = (Math.floor(t / 70) % 11 === 0) ? 0.35 : 1; c.globalAlpha = fl; R(c, bx + 80, 84, 120, 30, '#1a0828'); R(c, bx + 80, 84, 120, 2, '#7a2a8a'); T.draw(c, 'BAR DO ZE', bx + 140, 92, { a: 'c', s: 2, c: '#ff4fd8', sh: '#7a1566' }); glow(c, bx + 140, 100, 90, '#ff4fd8', 0.06); T.draw(c, 'CERVEJA GELADA', bx + 140, 120 - 2, { a: 'c', s: 1, c: '#37f0ff' }); c.globalAlpha = 1;
          glow(c, 424, 78, 34, '#fff1b0', 0.09); R(c, 422, 66, 7, 4, '#fff6c8'); } }
    ]
  });
  // ====================================================================== 6. CAMPINHO DE TERRA (chuva)
  const drops = []; for (let i = 0; i < 150; i++) drops.push([hs(i) * W, hs(i + 99) * H, 3 + hs(i + 7) * 3]);
  ST.push({
    id: 'campinho', name: 'CAMPINHO DE TERRA', tint: '#9ab0c8', rain: true, layers: [
      { f: 0, d(c) { band(c, 0, 190, ['#3e4856', '#4a5462', '#58626f', '#6a7480', '#7c8690', '#8e98a2']); for (let i = 0; i < 9; i++) { const cx = i * 70 + X0 + hs(i) * 30, cy = 24 + hs(i + 3) * 60; c.globalAlpha = 0.7; for (let k = 0; k < 4; k++) disc(c, cx + k * 22, cy + (k % 2) * 6, 20 - k * 2, k % 2 ? '#56606c' : '#4c5662'); c.globalAlpha = 1; } } },
      { f: 0.1, d(c) { c.fillStyle = '#3a5444'; c.beginPath(); c.moveTo(X0, 200); for (let x = X0; x <= X1; x += 10) c.lineTo(x, 118 + Math.sin(x * 0.018 + 1) * 22 + Math.sin(x * 0.05) * 6); c.lineTo(X1, 200); c.fill(); for (let i = 0; i < 90; i++) { const x = X0 + hs(i) * W2, y = 140 + hs(i + 4) * 50; R(c, x, y, 5, 3, hs(i + 9) > 0.5 ? '#46644e' : '#2e4638'); } dither(c, X0, 170, W2, 24, '#8e98a2', 0.35); } },
      { f: 0.25, d(c) { // casas de tijolo e reboco, caixas d'água, coqueiros
          const cl = ['#b9a07a', '#a1b4c2', '#c9917a', '#8aa070', '#c8b8a0']; for (let i = 0; i < 12; i++) { const x = i * 46 + X0 + hs(i + 11) * 8, y = 150 + hs(i + 31) * 24, col = cl[i % 5]; if (i % 3 === 0) bricks(c, x, y, 40, 40, '#a4553a', '#8a7a6a', 9, 5); else { R(c, x, y, 40, 40, col); R(c, x, y, 3, 40, sh(col, 0.2)); R(c, x + 37, y, 3, 40, sh(col, -0.25)); } R(c, x - 3, y - 9, 46, 10, '#9a4a38'); for (let k = 0; k < 5; k++) R(c, x - 3 + k * 9, y - 9, 1, 10, '#7a3a2a'); R(c, x - 3, y - 9, 46, 1, '#c8705a'); R(c, x + 6, y + 14, 9, 14, '#5a3a22'); R(c, x + 22, y + 10, 11, 11, '#5a90b0'); R(c, x + 22, y + 10, 11, 2, '#8ac0d8'); R(c, x + 27, y + 10, 1, 11, '#3a6a88'); if (i % 4 == 1) { R(c, x + 12, y - 24, 14, 14, '#2a6fb0'); R(c, x + 12, y - 24, 14, 2, '#5aa0e0'); } }
          for (let i = 0; i < 6; i++) { const x = 20 + i * 90 + hs(i) * 20; R(c, x, 150, 4, 52, '#5a3d28'); R(c, x, 150, 1, 52, '#7a5a38'); for (let k = 0; k < 7; k++) { const a = -2.6 + k * 0.7; for (let u = 0; u < 18; u++) R(c, x + 2 + Math.cos(a) * u, 148 + Math.sin(a) * u * 0.55 + u * u * 0.012, 2, 2, k % 2 ? '#2a6a34' : '#3a8a44'); } } } },
      { f: 0.4, d(c) { // traves de madeira + cerca
          for (const x of [8, 438]) { R(c, x, 150, 6, 56, '#8a6a42'); R(c, x, 150, 2, 56, '#b08a5a'); R(c, x + 34, 150, 6, 56, '#8a6a42'); R(c, x, 148, 40, 6, '#9b7a50'); R(c, x, 148, 40, 2, '#c09a68'); for (let j = 0; j < 8; j++) R(c, x + 6, 156 + j * 6, 28, 1, 'rgba(200,200,190,.35)'); }
          for (let x = X0; x < X1; x += 22) { R(c, x, 186, 3, 18, '#6a4a2a'); } R(c, X0, 190, W2, 1, '#8a8a82'); R(c, X0, 196, W2, 1, '#8a8a82'); } },
      { f: 0, d(c) { band(c, 204, 272, ['#8a6444', '#7e5a3c', '#72503a', '#664834', '#5a3e2c']); tex(c, X0, 206, W2, 64, '#9e7a56', 140, 1); tex(c, X0, 206, W2, 64, '#4a3424', 140, 6); for (let i = 0; i < 40; i++) { const x = X0 + hs(i) * W2, y = 208 + hs(i + 3) * 60; R(c, x, y, 3, 2, '#4e7a3a'); R(c, x + 1, y - 2, 1, 2, '#6a9a4a'); R(c, x + 3, y - 1, 1, 2, '#5a8a3a'); } R(c, X0, 202, W2, 3, '#4a6a3a'); R(c, X0, 204, W2, 1, '#3a2a1c');
          R(c, 205, 216, 12, 6, '#d8d4c8'); R(c, 205, 216, 12, 1, '#fff'); disc(c, 360, 258, 5, '#e8e8e0'); R(c, 355, 257, 10, 1, '#222'); R(c, 359, 253, 2, 10, '#222'); } },
      { a(c, t) { for (let i = 0; i < 4; i++) { const x = 60 + i * 120, y = 238 + (i % 2) * 14; c.globalAlpha = 0.5; c.fillStyle = '#9ab4c8'; for (let j = -4; j <= 4; j++) { const w = Math.floor(34 * Math.sqrt(1 - j * j / 17)); c.fillRect(x - w, y + j, 2 * w, 1); } c.globalAlpha = 1; for (let k = 0; k < 2; k++) { const r = ((t * 0.3 + i * 9 + k * 14) % 20); c.strokeStyle = `rgba(255,255,255,${0.5 * (1 - r / 20)})`; c.lineWidth = 1; c.beginPath(); c.ellipse(x - 8 + k * 12, y, r, r * 0.2, 0, 0, 6.283); c.stroke(); } } } }
    ], fore(c, t) { c.fillStyle = 'rgba(200,216,236,.5)'; for (const d of drops) { const x = (d[0] - t * 1.4 + W * 10) % W, y = (d[1] + t * (6 + d[2])) % H; c.fillRect(Math.round(x), Math.round(y), 1, 6); } c.fillStyle = 'rgba(60,80,110,.14)'; c.fillRect(0, 0, W, H); }
  });
  // ====================================================================== 7. PONTO DE ÔNIBUS LOTADO
  ST.push({
    id: 'onibus', name: 'PONTO DE ONIBUS LOTADO', tint: '#ffd24a', layers: [
      { f: 0, d(c) { band(c, 0, 180, ['#4a90d4', '#5aa0dc', '#6cb0e4', '#84c2ec', '#a0d2f2', '#c0e2f8', '#dcf0fc']); } },
      { a(c, t) { for (let i = 0; i < 5; i++) { const x = ((i * 130 + t * 0.2) % (W + 140)) - 70, y = 26 + (i % 3) * 20; for (let k = 0; k < 4; k++) { disc(c, x + k * 14, y + (k % 2) * 4, 13 - k % 2 * 3, '#fff'); } R(c, x - 8, y + 6, 66, 6, '#e8f2fc'); R(c, x - 8, y + 10, 66, 2, '#c8dcf0'); } } },
      { f: 0.12, d(c) { const cl = ['#b8a99a', '#a3b0b8', '#c9b6a0', '#9aa4b0', '#d0c0a8']; for (let i = 0; i < 12; i++) { const bx = i * 46 + X0, bh = 70 + hs(i + 21) * 80, col = cl[i % 5]; bld(c, bx, 184 - bh, 42, bh, col, { win: 1, lit: '#ffe9a0', dark: '#5c7080', cw: 12, ch: 17, p: 0.15 }); R(c, bx, 184 - bh, 42, 3, sh(col, -0.35)); if (i % 3 === 0) { R(c, bx + 12, 184 - bh - 10, 18, 9, '#d8d4c8'); } if (i % 4 === 1) T.draw(c, ['LOJA', 'FARMACIA', 'CELULAR', 'LANCHES'][i % 4], bx + 21, 184 - bh + 4, { a: 'c', s: 1, c: '#c82a2a' }); } } },
      { f: 0, d(c) { R(c, X0, 178, W2, 22, '#4a4d55'); band(c, 178, 200, ['#555860', '#4a4d55', '#42454c']); R(c, X0, 198, W2, 3, '#a8a8a8'); R(c, X0, 198, W2, 1, '#d8d8d8'); band(c, 201, 272, ['#b9b4aa', '#b0aba0', '#a8a398', '#a09b90']); for (let x = X0; x < X1; x += 50) R(c, x, 201, 1, 70, '#8a867c'); for (let y = 215; y < 272; y += 28) R(c, X0, y, W2, 1, '#8a867c'); tex(c, X0, 203, W2, 66, '#948f84', 100, 2); for (let x = X0; x < X1; x += 6) { R(c, x, 232, 5, 6, '#e8c82a'); R(c, x, 232, 5, 1, '#fff2a0'); } for (let y = 238; y < 272; y += 6) for (let x = X0 + 100; x < X0 + 160; x += 6) R(c, x, y, 5, 5, '#e8c82a'); } },
      { a(c, t) { const bxx = ((t * 1.4) % (W + 340)) - 250; R(c, bxx, 124, 200, 56, '#e8b923'); R(c, bxx, 124, 200, 4, '#f8dc60'); R(c, bxx, 166, 200, 14, '#b8861a'); R(c, bxx, 148, 200, 3, '#2a6a3a'); for (let i = 0; i < 8; i++) { R(c, bxx + 8 + i * 22, 132, 18, 20, '#7ac4ee'); R(c, bxx + 8 + i * 22, 132, 18, 3, '#b8e4fa'); if (i % 2 === 0) { R(c, bxx + 11 + i * 22, 138, 6, 6, '#3a2a1a'); } } R(c, bxx + 170, 128, 26, 36, '#7ac4ee'); T.draw(c, '0842 CENTRO', bxx + 60, 156, { s: 1, c: '#222' }); for (const wx of [34, 150]) { disc(c, bxx + wx, 180, 12, '#111'); disc(c, bxx + wx, 180, 6, '#9a9aa2'); disc(c, bxx + wx, 180, 2, '#4a4a52'); } R(c, bxx + 190, 150, 8, 6, '#fff8c0'); } },
      { f: 0.5, d(c) { const sx = 110; R(c, sx, 118, 262, 7, '#3a4252'); R(c, sx, 118, 262, 1, '#6a7488'); R(c, sx + 4, 125, 254, 3, '#222a36'); R(c, sx + 6, 125, 5, 80, '#3a4252'); R(c, sx + 250, 125, 5, 80, '#3a4252'); R(c, sx + 6, 125, 1, 80, '#6a7488'); c.globalAlpha = 0.22; R(c, sx + 12, 128, 238, 72, '#bfe4ff'); c.globalAlpha = 1; for (let i = 0; i < 6; i++) R(c, sx + 20 + i * 36, 130, 1, 60, 'rgba(255,255,255,.4)');
          R(c, sx + 20, 102, 64, 15, '#d62828'); R(c, sx + 20, 102, 64, 2, '#f06a5a'); T.draw(c, 'PONTO 12', sx + 52, 106, { a: 'c', s: 1, c: '#fff' }); R(c, sx + 100, 88, 50, 28, '#fff'); R(c, sx + 100, 88, 50, 5, '#2a5aa8'); for (let i = 0; i < 5; i++) R(c, sx + 104, 97 + i * 4, 40 - (i % 2) * 8, 1, '#8a8a92');
          R(c, sx + 14, 184, 232, 5, '#6b4a2a'); R(c, sx + 14, 184, 232, 1, '#9a7a4a'); for (let i = 0; i < 4; i++) R(c, sx + 20 + i * 58, 189, 3, 16, '#444');
          const ux = 410; R(c, ux, 146, 2, 58, '#7a7a82'); for (let k = 0; k < 9; k++) { const w = 38 - Math.abs(k - 4) * 8 + 8; R(c, ux - w + 1, 134 + k, w * 2, 1, k % 2 ? '#e8342a' : '#fff'); } R(c, ux - 26, 148, 54, 4, '#c8c8c0'); R(c, ux - 22, 152, 46, 14, '#8a5a2a'); for (let i = 0; i < 6; i++) R(c, ux - 18 + i * 7, 154, 5, 8, ['#e8c040', '#d85a3a', '#4a8ad0'][i % 3]); poste(c, 46, 70, 206, '#4a4a52'); wire(c, 50, 78, 130, 84, 10, '#1a1a22'); } },
      { a(c, t) { crowd(c, t, 17, 124, 14, 212, { s: 1.1, dy: 3, j: 5, o: 0, sp: 0.06, phone: 1 }); for (let i = 0; i < 3; i++) pp(c, 428 + i * 14, 222 + i * 2, { s: 1.12, top: TP[(i + 4) % 9], sk: SK[i + 1], hair: HR[i], bot: '#3a3a44' }); for (let i = 0; i < 3; i++) { const x = ((t * 0.3 + i * 180) % 520) - 20; R(c, x, 232 + i * 8, 5, 3, '#8a8a94'); R(c, x + 4, 231 + i * 8, 2, 2, '#8a8a94'); R(c, x, 235 + i * 8, 1, 2, '#c85a3a'); } } }
    ]
  });

  // ---------- renderização ----------
  function ensure(s) {
    if (s.ready) return; s.ready = true;
    for (const L of s.layers) {
      if (!L.d) continue; const cv = document.createElement('canvas'); cv.width = W2; cv.height = H; const x = cv.getContext('2d'); x.imageSmoothingEnabled = false; x.translate(M, 0); L.d(x); L.cv = cv;
    }
  }
  RC.Stages = {
    list: ST,
    draw(c, idx, t, px) {
      const s = ST[idx]; ensure(s); px = px || 0;
      for (const L of s.layers) { if (L.cv) c.drawImage(L.cv, Math.round(-M - px * L.f), 0); else L.a(c, t, px); }
    },
    fore(c, idx, t) { const s = ST[idx]; if (s.fore) s.fore(c, t); },
    warm() { ST.forEach((s, i) => setTimeout(() => ensure(s), 400 + i * 250)); }
  };
})();
