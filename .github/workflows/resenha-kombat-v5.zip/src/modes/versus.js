// Partida: Versus 1v1/2v2/3v3 e Treino. Rounds, KO, times, fusões, time stop, Resenhatality.
(function () {
  const RC = window.RC, FX = RC.FX, A = RC.Audio, GY = RC.GY, W = RC.W, H = RC.H, S = RC.Sprites, Col = RC.Col;

  // ---------- diálogos ----------
  RC.Dialogue = {
    get(a, b) {
      const D = RC.DATA.dialogues;
      const arr = D[a + '_vs_' + b] || D[b + '_vs_' + a];
      if (arr) return arr.map(l => ({ speaker: l.speaker, text: l.text, shout: l.shout, draft: l.draft }));
      const g = D._generic || {};
      return [{ speaker: a, text: g[a] || '...', generic: true }, { speaker: b, text: g[b] || '...', generic: true }];
    }
  };

  class Team {
    constructor(idx, ids, ctrl, human) {
      Object.assign(this, { idx, ids, ctrl, human, pi: idx, meter: 0, fat: 0, wins: 0, fighters: [], active: 0, fusion: null, swapT: 0, swapCd: 0, combo: null, trail: 1 });
    }
    get cur() { return this.fusion ? this.fusion.F : this.fighters[this.active]; }
    hasReserve() { return this.fighters.some((f, i) => f.alive && i !== this.active); }
    hpRatio() { let h = 0, m = 0; for (const f of this.fighters) { h += Math.max(0, f.hp); m += f.maxhp; } return h / m; }
  }

  class Match {
    constructor(o) {
      this.o = o; this.training = o.mode === 'training'; this.mode = o.mode; this.stage = o.stage || 0; this.ents = []; this.round = 0;
      const ctrls = [o.cpu[0] ? RC.AI.make(o.diff) : RC.Input.p[0], o.cpu[1] ? (this.training ? RC.AI.dummy() : RC.AI.make(o.diff)) : RC.Input.p[1]];
      this.teams = [0, 1].map(i => new Team(i, o.picks[i], ctrls[i], !o.cpu[i]));
      this.cut = null; this.paused = false; this.pmenu = 0; this.vsel = 0; this.showCmd = false; this.noBlood = false;
      RC.Match = this; RC.FX.clear(); this.startRound();
    }
    activeOf(i) { return this.teams[i].cur; }
    startRound() {
      this.round++; this.ents.length = 0; FX.clear(); RC.Cam.reset(); this.timer = this.training ? 1e9 : 99 * 60; this.phase = 'intro'; this.pt = 0; this.noInput = true;
      this.acid = 0; this.timeStop = null; this.cut = null; this.big = null; this.banner = null; this.title = null; this.slowT = 0; this.hitstopN = 0; this.flashT = 0; this.winner = null; this.t = 0;
      for (const t of this.teams) {
        t.fighters = t.ids.map(id => new RC.Fighter(this, t, id)); t.active = 0; t.fusion = null; t.swapT = 0; t.swapCd = 0; t.combo = null; t.trail = 1;
        t.cur.init(t.idx === 0 ? 150 : 330, t.idx === 0 ? 1 : -1);
      }
      A.music('fight');
    }
    // ---------- API usada pelos poderes ----------
    ent(e) { Object.assign(e, { t: 0, w: e.w || 10, h: e.h || 10, life: e.life || 60, dmg: e.dmg || 0, cool: new Map(), vx: e.vx || 0, vy: e.vy || 0 }); this.ents.push(e); return e; }
    shake(p, t) { RC.Cam.shake(p, t); }
    flash(col, t, a = 0.8) { this.flashC = col; this.flashT = t; this.flashMax = t; this.flashA = a; }
    say(text, col = '#fff', dur = 60) { this.banner = { text, col, t: dur, dur }; }
    setTitle(text, col, dur, s, sub) { this.title = { text, col, t: 0, dur, s, sub }; }
    bigText(text, col) { this.big = { text, col, t: 150, s: 5 }; }
    hitstop(n) { this.hitstopN = Math.max(this.hitstopN, n); }
    cutscene(f, title, dur, col, sub, kind) { this.cut = { f, title, dur, t: 0, col, sub, kind: kind || 'ult' }; RC.Cam.focus(f.x, f.y - 50, 1.7); this.cutKind = kind; }
    dizzy(v, n) { if (!v || !v.alive || v.armor || v.sInv || v.invuln > 0) return; v.cancelScript(); v.move = null; v.state = 'dizzy'; v.stun = n; v.vx = 0; v.anim = 'dizzy'; }
    startTimeStop(owner, dur) {
      this.timeStop = { owner, t: dur, max: dur }; const v = this.teams[1 - owner.team.idx].cur; if (v) { v.frozen = true; v.frozenHits = 0; v.cancelScript && 0; }
    }
    endTimeStop() {
      const ts = this.timeStop; this.timeStop = null; const v = this.teams[1 - ts.owner.team.idx].cur;
      if (v) { v.frozen = false; if (v.frozenHits > 0 && v.alive) { v.cancelScript(); v.state = 'launched'; v.vy = -7; v.vx = ts.owner.face * 6; v.y = Math.min(v.y, GY - 2); this.shake(10, 20); this.flash('#fff', 6, 0.7); A.play('hitH'); v.frozenHits = 0; } else if (v.hp <= 0 && v.alive) v.die(ts.owner, {}); }
      A.play('time');
    }
    canFuse(team) {
      if (team.fusion || this.training && false) return false; const a = team.cur; if (!a || !a.alive || a.form || a.fusionId) return false;
      return RC.DATA.fusions.some(fu => { const p = fu.a === a.id ? fu.b : fu.b === a.id ? fu.a : null; return p && team.fighters.some(x => x.id === p && x.alive); });
    }
    tryFusion(team) {
      if (this.phase !== 'fight' || team.meter < 300 || !this.canFuse(team)) return false; const a = team.cur; if (!a.grounded) return false;
      for (const fu of RC.DATA.fusions) {
        const p = fu.a === a.id ? fu.b : fu.b === a.id ? fu.a : null; if (!p) continue;
        const b = team.fighters.find(x => x.id === p && x.alive); if (!b) continue;
        team.meter -= 300; const F = new RC.Fighter(this, team, fu.id, { baseId: fu.a, fusionId: fu.id, hp: 1500, name: fu.name });
        F.init(a.x, a.face); F.hp = F.maxhp = 1500; F.pow = 3; F.spd = 1.4; F.fuseT = 1800; F.auraCol = null; F.invuln = 40; team.fusion = { F, a, b };
        this.cutscene(a, 'FUSAO: ' + fu.name, 110, '#ffffff', a.name + ' + ' + b.name, 'transform'); A.play('transform'); this.flash('#fff', 12, 1); this.say(fu.name + '!', '#fff', 80);
        FX.ring(a.x, a.y - 30, '#fff', 90, 30); return true;
      }
      return false;
    }
    endFusion(team) {
      const fz = team.fusion; if (!fz) return; const F = fz.F, a = fz.a; F.cancelScript();
      a.x = F.x; a.y = GY; a.face = F.face; a.vx = a.vy = 0; a.state = 'idle'; a.anim = 'idle'; a.gen = null; a.invuln = 60; a.alive = true; a.move = null;
      team.fusion = null; FX.ring(a.x, a.y - 30, '#fff', 70); A.play('select'); this.say('FUSAO DESFEITA', '#fff', 50);
    }
    // ---------- dano ----------
    hit(att, vic, d) {
      if (!att || !vic || !vic.alive || vic.state === 'ko' || vic.state === 'fatal') return false;
      if (vic.invuln > 0 || vic.sInv) return false;
      const type = d.type || 'mid', blockable = type !== 'throw' && type !== 'unblock';
      let dmg = Math.min(d.noCap ? 9999 : 450, (d.dmg || 0) * att.dmgMul); const dir = d.dir || att.face, cx = (att.x + vic.x) / 2 + dir * 6, cy = vic.y - 46;
      if (blockable && !vic.frozen && vic.isBlocking(att, type)) {
        vic.hp = Math.max(1, vic.hp - Math.max(1, Math.round(dmg * 0.1))); vic.state = 'blockstun'; vic.stun = d.bstun || 10; vic.vx = dir * (d.kx || 2) * 0.5; vic.move = null;
        if (vic.x <= 16 || vic.x >= W - 16) att.vx = -att.face * (d.kx || 2) * 0.6; FX.spark(cx, cy, '#cfe8ff', 5); A.play('block'); vic.team.meter = Math.min(300, vic.team.meter + dmg * 0.05); return 'block';
      }
      const sc = d.noScale ? 1 : Math.max(0.3, 1 - 0.1 * Math.max(0, vic.comboN - 1)); dmg = Math.round(dmg * sc);
      vic.comboN++; att.team.combo = { n: vic.comboN, t: 100 };
      vic.hp -= dmg; vic.flash = 5; att.team.meter = Math.min(300, att.team.meter + dmg * 0.25); vic.team.meter = Math.min(300, vic.team.meter + dmg * 0.2); att.team.fat = Math.min(100, att.team.fat + dmg * 0.1);
      const child = att.form === 'vitin';
      if (child) { FX.spark(cx, cy, '#ffd84a', 8); FX.add({ x: cx, y: cy - 8, vx: 0, vy: -0.4, life: 24, kind: 'text', c: '*', col: '#ffd84a', s: 2 }); }
      else if (dmg >= 25) { FX.blood(cx, cy, Math.min(14, 2 + dmg / 10), dir, 2 + dmg / 70); FX.spark(cx, cy, '#fff', 4); } else FX.spark(cx, cy, '#fff', 5);
      A.play(dmg >= 55 ? 'hitH' : 'hit'); if (!d.noScale) this.hitstop(dmg >= 55 ? 7 : 4); if (dmg >= 120) this.shake(6, 10);
      if (this.training && vic.hp <= 0) vic.hp = vic.maxhp;
      if (vic.frozen) { vic.frozenHits++; vic.flash = 4; return 'hit'; }
      if (vic.hp <= 0 && vic.fusionId) { this.endFusion(vic.team); return 'hit'; }
      vic.react({ face: dir }, d); return 'hit';
    }
    // ---------- ciclo ----------
    update() {
      if (this.paused) return this.pauseUpdate();
      if (RC.Input.nav.pause && this.phase !== 'victory') { this.paused = true; this.pmenu = 0; this.showCmd = false; A.play('select'); return; }
      FX.update(); RC.Cam.update(); if (this.acid > 0) this.acid--;
      if (this.title) { this.title.t++; if (this.title.t >= this.title.dur) this.title = null; }
      if (this.big) { this.big.t--; if (this.big.t <= 0) this.big = null; }
      if (this.hitstopN > 0) { this.hitstopN--; return; }
      if (this.cut) { this.cut.t++; RC.Cam.focus(this.cut.f.x, this.cut.f.y - 50, 1.7); if (this.cut.t >= this.cut.dur) { this.cut = null; } return; }
      if (this.slowT > 0) { this.slowT--; if (this.slowT & 1) return; }
      this.t++;
      switch (this.phase) {
        case 'intro': this.simulate(); this.pt++; if (this.pt === 2) this.setTitle(this.round > 1 ? 'ROUND ' + this.round : 'ROUND 1', '#ffe14a', 70, 4); if (this.pt === 82) { this.setTitle('FIGHT!', '#ff4a3a', 40, 5); A.play('bell'); } if (this.pt >= 118) { this.phase = 'fight'; this.noInput = false; } break;
        case 'fight': this.simulate(); this.checkKO(); if (!this.training) { this.timer--; if (this.timer <= 0) this.timeUp(); } break;
        case 'ko': this.simulate(); if (++this.pt >= 130) { this.phase = 'roundend'; this.pt = 0; this.award(); } break;
        case 'roundend': this.simulate(); if (++this.pt >= 150) { if (this.matchWinner != null) this.endMatch(); else this.startRound(); } break;
        case 'finish': this.simulate(); this.finishUpdate(); break;
        case 'fatal': this.simulate(); if (!this.winner.cur.gen && !this.big) { if (++this.pt > 20) this.toVictory(); } break;
        case 'victory': this.simulate(); this.victoryUpdate(); break;
      }
    }
    simulate() {
      const T = this.teams;
      for (const t of T) { if (t.swapCd > 0) t.swapCd--; if (t.ctrl.think) t.ctrl.think(t.cur, T[1 - t.idx].cur, this); if (this.training) t.meter = 300; }
      const ts = this.timeStop; if (ts && --ts.t <= 0) this.endTimeStop();
      for (const t of T) { const f = t.cur; if (!f) continue; if (f.frozen) { f.clock++; continue; } f.update(); }
      // empurrão entre lutadores
      const a = T[0].cur, b = T[1].cur;
      if (a && b && a.grounded && b.grounded && a.state !== 'down' && b.state !== 'down' && a.alive && b.alive && !a.gen && !b.gen) {
        const dx = b.x - a.x, min = 20 * Math.max(a.scale, b.scale) * 0.8; if (Math.abs(dx) < min) { const p = (min - Math.abs(dx)) / 2 * Math.sign(dx || 1); a.x -= p; b.x += p; a.x = RC.clamp(a.x, 14, W - 14); b.x = RC.clamp(b.x, 14, W - 14); }
      }
      // golpes normais
      for (const t of T) {
        const f = t.cur, o = T[1 - t.idx].cur;
        if (f && o && f.state === 'attack' && f.move && !f.hasHit && f.t >= f.move.startup && f.t < f.move.startup + f.move.active && o.alive) {
          const hb = Col.hit(f), hu = Col.hurt(o);
          if (RC.overlap(hb, hu)) { const m = f.move, r = this.hit(f, o, { dmg: m.dmg, kx: m.kx, ky: m.ky, stun: m.hitstun, bstun: m.blockstun, type: m.type, launch: m.type === 'throw' }); if (r) { f.hasHit = true; if (r === 'hit' && m.type === 'throw') this.shake(5, 10); } }
        }
      }
      // entidades
      for (let i = this.ents.length - 1; i >= 0; i--) {
        const e = this.ents[i]; if (ts && e.owner !== ts.owner) continue;
        e.t++; e.life--; if (e.update) e.update(e, this); e.x += e.vx; e.y += e.vy; e.vy += e.g || 0;
        if (e.dmg > 0 && e.owner) {
          const v = this.teams[1 - e.owner.team.idx].cur;
          if (v && v.alive && RC.overlap({ x: e.x - e.w / 2, y: e.y - e.h / 2, w: e.w, h: e.h }, Col.hurt(v)) && RC.frame >= (e.cool.get(v) || 0)) {
            const dd = Object.assign({ dmg: e.dmg }, e.d, { dir: Math.sign(e.vx) || (v.x >= e.x ? 1 : -1) });
            const r = this.hit(e.owner, v, dd);
            if (r) { e.cool.set(v, RC.frame + (e.every || 99999)); if (e.onHit) e.onHit(e, v, r); if (!e.pierce && !e.every) e.life = 0; }
          }
        }
        if (e.life <= 0 || e.x < -160 || e.x > W + 160 || e.y > H + 60) { if (e.onDie) e.onDie(e); this.ents.splice(i, 1); }
      }
      // fusão: tempo
      for (const t of T) if (t.fusion) { const F = t.fusion.F; if (!F.frozen && --F.fuseT <= 0 || F.hp <= 0) this.endFusion(t); }
      // câmera
      if (!this.cut && this.phase !== 'fatal') {
        const a2 = T[0].cur, b2 = T[1].cur, mx = (a2.x + b2.x) / 2, dist = Math.abs(a2.x - b2.x), z = 1 + 0.17 * RC.clamp(1 - dist / 300, 0, 1);
        RC.Cam.focus(mx, 135 + (z - 1) * 90, z);
      } else if (this.phase === 'fatal') { const a2 = T[0].cur, b2 = T[1].cur; RC.Cam.focus((a2.x + b2.x) / 2, 150, 1.45); }
    }
    checkKO() {
      const T = this.teams;
      for (const t of T) {
        const f = t.cur; if (f.fusionId || f.alive) continue;
        if (t.hasReserve()) { if (!t.swapT) t.swapT = 70; if (--t.swapT <= 0) { t.swapT = 0; this.swapIn(t); } }
      }
      const dead = T.map(t => !t.fighters.some(f => f.alive));
      if (dead[0] || dead[1]) this.roundOver(dead[0] && dead[1] ? -1 : dead[0] ? 1 : 0);
    }
    // troca manual de lutador (tag): o próximo vivo do time entra no lugar do atual
    trySwap(team) {
      if (this.phase !== 'fight' || this.noInput || this.cut || this.timeStop || team.fusion || team.swapCd > 0) return false;
      const a = team.cur, n = team.fighters.length; if (!a || !a.alive || n < 2) return false;
      let idx = -1; for (let k = 1; k < n; k++) { const j = (team.active + k) % n; if (team.fighters[j].alive) { idx = j; break; } } if (idx < 0) return false;
      const x = a.x, face = a.face; FX.burst(x, a.y - 30, 18, [a.color, '#fff'], 4, { g: 0, life: 18 }); FX.ring(x, a.y - 30, a.color, 50, 16);
      a.cancelScript(); a.move = null; a.state = 'idle'; a.anim = 'idle'; a.vx = 0; a.vy = 0; a.y = GY;
      team.active = idx; const f = team.cur; f.init(x, face); f.y = GY - 110; f.vy = 0; f.state = 'jump'; f.anim = 'jump'; f.invuln = 45; f.comboN = 0;
      team.swapCd = 100; this.say(f.name + ' ENTRA!', f.color, 50); A.play('whoosh'); FX.burst(x, f.y - 30, 18, [f.color, '#fff'], 4, { g: 0, life: 18 }); FX.ring(x, f.y - 30, f.color, 60, 16); return true;
    }
    swapIn(t) {
      const idx = t.fighters.findIndex(f => f.alive); if (idx < 0) return; t.active = idx; const f = t.cur, left = t.idx === 0;
      f.init(left ? -10 : W + 10, left ? 1 : -1); f.x = left ? 14 : W - 14; f.y = GY - 80; f.vx = left ? 4 : -4; f.vy = -2; f.state = 'jump'; f.anim = 'jump'; f.invuln = 70; f.auraCol = null;
      this.say(f.name + ' ENTRA!', f.color, 60); A.play('whoosh'); FX.burst(f.x, f.y, 14, [f.color, '#fff'], 3, { g: 0, life: 16 });
    }
    timeUp() {
      const r0 = this.teams[0].hpRatio(), r1 = this.teams[1].hpRatio(); this.setTitle('TEMPO!', '#ffe14a', 80, 4); this.roundOver(Math.abs(r0 - r1) < 0.001 ? -1 : r0 > r1 ? 0 : 1, true);
    }
    roundOver(w, timeout) {
      if (this.phase !== 'fight') return; this.phase = 'ko'; this.pt = 0; this.noInput = true; this.roundWinner = w; this.slowT = timeout ? 0 : 110;
      if (!timeout) { this.setTitle('K.O.', '#ff2a2a', 100, 6); A.play('ko'); this.shake(8, 20); }
      for (const t of this.teams) { if (t.fusion) this.endFusion(t); }
    }
    award() {
      const w = this.roundWinner; if (w === -1) { this.teams[0].wins++; this.teams[1].wins++; this.setTitle('EMPATE!', '#ffe14a', 120, 4); } else { this.teams[w].wins++; const f = this.teams[w].cur; this.setTitle(f.name + ' VENCEU!', f.color, 130, 3); }
      const [a, b] = [this.teams[0].wins, this.teams[1].wins];
      this.matchWinner = (a >= 2 || b >= 2) && a !== b ? (a > b ? 0 : 1) : null;
    }
    endMatch() {
      const w = this.teams[this.matchWinner], l = this.teams[1 - this.matchWinner]; this.winner = w; this.loser = l; const wf = w.cur;
      this.noInput = true; this.pt = 0;
      const can = !this.training && w.fat >= 100 && wf.def && wf.def.fatality && wf.form !== 'vitin' && wf.alive;
      if (can) {
        const o = l.cur; o.alive = true; o.hp = 1; o.state = 'kneel'; o.anim = 'kneel'; o.vx = o.vy = 0; o.y = GY; o.invuln = 99999; o.vis = null; o.downed = false; o.face = o.x > wf.x ? -1 : 1;
        this.phase = 'finish'; this.finishMax = 360; RC.Input.clearHist(); A.play('finish'); this.big = null; this.shake(6, 20);
      } else this.toVictory();
    }
    finishUpdate() {
      const w = this.winner, f = w.cur; this.pt++;
      if (w.human && RC.Input.seq(w.pi, f.def.cmd, f.face, 160) || !w.human && this.pt > 110) {
        this.phase = 'fatal'; this.pt = 0; f.state = 'idle'; f.run(f.def.fatality, { armor: true, inv: true }); A.play('ultimate'); return;
      }
      if (this.pt >= this.finishMax) { this.loser.cur.state = 'ko'; this.loser.cur.alive = false; this.loser.cur.hp = 0; this.loser.cur.anim = 'down'; this.toVictory(); }
    }
    toVictory() {
      this.phase = 'victory'; this.pt = 0; this.vsel = 0; const f = this.winner.cur; f.cancelScript(); f.state = 'win'; f.anim = 'win'; f.vx = 0; f.vis = null; f.gun = false; f.guard = null; f.invuln = 99999; f.frozen = false;
      RC.Cam.focus(f.x, 150, 1.3); this.setTitle('', '#fff', 1, 1); this.title = null; this.say(f.name + ' VENCEU A RESENHA!', f.color, 400); A.play('bell'); A.music('menu');
      this.vitems = ['REVANCHE', 'TROCAR LUTADORES', 'MENU PRINCIPAL']; this.vrect = [];
      if (this.o.auto) this.say(f.name + ' VENCEU!', f.color, 400);
    }
    victoryUpdate() {
      this.pt++; const n = RC.Input.nav, ptr = RC.Input.ptr; if (this.o.auto) { if (this.pt > 200 || (this.pt > 60 && (n.ok || ptr.clicked))) this.o.onExit && this.o.onExit(this.winner.idx === 0 ? 'win' : 'lose'); return; } if (this.pt < 40) return;
      if (n.up) this.vsel = (this.vsel + 2) % 3; if (n.down) this.vsel = (this.vsel + 1) % 3; let pick = n.ok;
      this.vrect.forEach((r, i) => { if (ptr.x > r.x && ptr.x < r.x + r.w && ptr.y > r.y && ptr.y < r.y + r.h) { if (ptr.moved) this.vsel = i; if (ptr.clicked) { this.vsel = i; pick = true; } } });
      if (pick) { A.play('confirm'); this.o.onExit && this.o.onExit(['rematch', 'select', 'menu'][this.vsel]); }
    }
    pauseUpdate() {
      const n = RC.Input.nav, ptr = RC.Input.ptr, items = ['CONTINUAR', 'COMANDOS', 'SAIR PARA O MENU'];
      if (n.pause) { this.paused = false; return; }
      if (n.up) this.pmenu = (this.pmenu + 2) % 3; if (n.down) this.pmenu = (this.pmenu + 1) % 3; let pick = n.ok;
      items.forEach((_, i) => { const r = { x: 160, y: 90 + i * 26, w: 160, h: 22 }; if (ptr.x > r.x && ptr.x < r.x + r.w && ptr.y > r.y && ptr.y < r.y + r.h) { if (ptr.moved) this.pmenu = i; if (ptr.clicked) { this.pmenu = i; pick = true; } } });
      if (pick) { A.play('confirm'); if (this.pmenu === 0) this.paused = false; else if (this.pmenu === 1) this.showCmd = !this.showCmd; else this.o.onExit && this.o.onExit('menu'); }
    }
    // ---------- render ----------
    render(c) {
      const Cam = RC.Cam, T = this.teams;
      Cam.begin(c); this.drawWorld(c); Cam.end(c);
      RC.HUD.draw(c, this);
      if (this.cut) RC.HUD.cut(c, this, () => { Cam.begin(c); const f = this.cut.f; S.drawFighter(c, f); Cam.end(c); });
      if (this.phase === 'victory') this.drawVictory(c);
      if (this.paused) this.drawPause(c);
    }
    drawWorld(c) {
      const Cam = RC.Cam; RC.Stages.draw(c, this.stage, this.t, Cam.x - 240); FX.drawStains(c);
      const fs = this.teams.map(t => t.cur).filter(Boolean).sort((a, b) => (a.gen || a.state === 'attack' ? 1 : 0) - (b.gen || b.state === 'attack' ? 1 : 0));
      for (const f of fs) { if (f.vis && (f.vis.mode === 'hidden' || f.vis.mode === 'gone' || f.vis.mode === 'burger')) continue; const hgt = GY - f.y; c.globalAlpha = Math.max(0.1, 0.35 - hgt / 500); c.fillStyle = '#000'; c.beginPath(); c.ellipse(Math.round(f.x), GY + 2, 18 * (f.scale || 1) - hgt / 14, 4, 0, 0, 6.283); c.fill(); c.globalAlpha = 1; }
      for (const f of fs) { if (f.invuln > 0 && f.invuln < 90 && f.alive && (f.invuln >> 2) % 2 && !f.gen && !f.sInv) continue; S.drawFighter(c, f); }
      for (const e of this.ents) { if (e.draw) e.draw(c, e, this); else { c.fillStyle = '#fff'; c.fillRect(Math.round(e.x - e.w / 2), Math.round(e.y - e.h / 2), e.w, e.h); } }
      FX.draw(c); RC.Stages.fore(c, this.stage, this.t);
      if (this.training) {
        c.lineWidth = 1; for (const t of this.teams) { const f = t.cur; const hu = Col.hurt(f); c.strokeStyle = '#3f3'; c.strokeRect(Math.round(hu.x) + 0.5, Math.round(hu.y) + 0.5, hu.w, hu.h); if (f.state === 'attack' && f.move) { const hb = Col.hit(f), act = f.t >= f.move.startup && f.t < f.move.startup + f.move.active; c.strokeStyle = act ? '#f33' : '#a55'; c.strokeRect(Math.round(hb.x) + 0.5, Math.round(hb.y) + 0.5, hb.w, hb.h); } }
        c.strokeStyle = '#f84'; for (const e of this.ents) if (e.dmg) c.strokeRect(Math.round(e.x - e.w / 2) + 0.5, Math.round(e.y - e.h / 2) + 0.5, e.w, e.h);
      }
    }
    drawVictory(c) {
      if (this.o.auto) return;
      const f = this.winner.cur, Tx = RC.Text; c.fillStyle = 'rgba(0,0,0,.45)'; c.fillRect(0, 168, W, 102);
      this.vrect = [];
      this.vitems.forEach((it, i) => { const r = { x: 150, y: 176 + i * 28, w: 180, h: 22 }; this.vrect.push(r); c.fillStyle = i === this.vsel ? '#d8142f' : '#1a1a26'; c.fillRect(r.x, r.y, r.w, r.h); c.strokeStyle = i === this.vsel ? '#fff' : '#555'; c.strokeRect(r.x + 0.5, r.y + 0.5, r.w, r.h); Tx.draw(c, it, 240, r.y + 8, { a: 'c', c: '#fff' }); });
    }
    drawPause(c) {
      const Tx = RC.Text; c.fillStyle = 'rgba(0,0,0,.7)'; c.fillRect(0, 0, W, H); Tx.draw(c, 'PAUSADO', 240, 50, { a: 'c', s: 3, c: '#fff', ol: '#d8142f' });
      ['CONTINUAR', 'COMANDOS', 'SAIR PARA O MENU'].forEach((it, i) => { const r = { x: 160, y: 90 + i * 26, w: 160, h: 22 }; c.fillStyle = i === this.pmenu ? '#d8142f' : '#1a1a26'; c.fillRect(r.x, r.y, r.w, r.h); c.strokeStyle = '#fff'; c.strokeRect(r.x + 0.5, r.y + 0.5, r.w, r.h); Tx.draw(c, it, 240, r.y + 8, { a: 'c', c: '#fff' }); });
      if (this.showCmd) {
        const m = RC.Input.map, k = a => RC.keyName(m[0][a]), k2 = a => RC.keyName(m[1][a]);
        c.fillStyle = 'rgba(0,0,0,.85)'; c.fillRect(20, 60, 440, 200);
        Tx.draw(c, 'P1: MOVER ' + k('u') + k('l') + k('d') + k('r') + '  SOCO ' + k('lp') + '/' + k('hp') + '  CHUTE ' + k('lk') + '/' + k('hk'), 28, 70, { c: '#ffe14a' });
        Tx.draw(c, 'AGARRAO ' + k('grab') + '  ESPECIAL ' + k('special') + '  ULTIMATE ' + k('ultimate') + '  TRANSFORMAR ' + k('transform') + '  FUSAO ' + k('fusion') + '  AUX ' + k('aux'), 28, 82, { c: '#fff' });
        Tx.draw(c, 'P2: MOVER ' + k2('u') + k2('l') + k2('d') + k2('r') + '  SOCO ' + k2('lp') + '/' + k2('hp') + '  CHUTE ' + k2('lk') + '/' + k2('hk'), 28, 100, { c: '#ffe14a' });
        Tx.draw(c, 'AGARRAO ' + k2('grab') + '  ESPECIAL ' + k2('special') + '  ULTIMATE ' + k2('ultimate') + '  TRANSFORMAR ' + k2('transform') + '  FUSAO ' + k2('fusion') + '  AUX ' + k2('aux'), 28, 112, { c: '#fff' });
        const cur = this.teams[0].cur; Tx.draw(c, 'RESENHATALITY DE ' + cur.name + ': ' + RC.HUD.cmdText(cur.def.cmd || [], 1), 28, 134, { c: '#ff6a6a' });
        Tx.draw(c, 'SEGURE PARA TRAS PARA DEFENDER. ESPECIAL GASTA 1 BARRA.', 28, 154, { c: '#9aa' }); Tx.draw(c, 'ULTIMATE E TRANSFORMACAO PEDEM A BARRA CHEIA.', 28, 166, { c: '#9aa' });
        Tx.draw(c, 'BAIXO+ESPECIAL = ESPECIAL 2 (TODDY, FORMA ALEXANDRE)', 28, 178, { c: '#9aa' }); Tx.draw(c, 'GUILHERME: AUX JOGA CALOPSITA, AUX DE NOVO TELEPORTA', 28, 190, { c: '#9aa' });
        Tx.draw(c, 'FUSAO: DUPLA DO MESMO TIME COM BARRA CHEIA (2V2/3V3)', 28, 202, { c: '#9aa' });
        Tx.draw(c, 'TROCAR LUTADOR (2V2/3V3/TREINO): ' + k('swap') + ' (P1)  ' + k2('swap') + ' (P2)  BOTAO TROCA NO TOQUE', 28, 214, { c: '#2fe0c8' });
      }
    }
  }
  RC.keyName = code => String(code || '?').replace('Key', '').replace('Arrow', '').replace('Digit', '').replace('Comma', ',').replace('Period', '.').replace('Slash', '/').replace('Space', 'ESP').replace('Semicolon', ';').replace('Quote', "'").toUpperCase();
  RC.MatchClass = Match;
})();
