// IA do CPU: dificuldade 1 (fácil) a 5 (insano). Produz o mesmo formato de controle que o jogador humano.
(function () {
  const RC = window.RC;
  RC.AI = {
    names: ['FACIL', 'NORMAL', 'DIFICIL', 'MESTRE', 'INSANO'],
    make(level) {
      const A = RC.Input.ACTS, c = { held: {}, pressed: {}, prev: {}, lv: level, mt: 0, mode: 'approach', cd: 0, blockT: 0 };
      A.forEach(a => { c.held[a] = c.prev[a] = c.pressed[a] = false; });
      c.think = function (f, o, G) {
        const h = c.held, L = c.lv;
        for (const a of A) { c.prev[a] = h[a]; h[a] = false; }
        if (f && o && f.alive && !G.noInput && !(f.frozen)) c.decide(f, o, G, h, L);
        for (const a of A) c.pressed[a] = h[a] && !c.prev[a];
      };
      c.decide = function (f, o, G, h, L) {
        const dx = o.x - f.x, dist = Math.abs(dx), fwd = dx > 0 ? 'r' : 'l', back = dx > 0 ? 'l' : 'r', T = f.team;
        if (--c.cd > 0 && c.mode === 'attack') { /* espera */ }
        if (--c.mt <= 0) {
          const r = Math.random(); c.mt = RC.ri(Math.max(6, 28 - L * 4), Math.max(14, 46 - L * 6));
          if (dist > 150) c.mode = r < 0.78 ? 'approach' : (r < 0.88 ? 'jump' : 'wait');
          else if (dist > 70) c.mode = r < 0.5 ? 'approach' : r < 0.75 ? 'attack' : r < 0.85 ? 'retreat' : 'jump';
          else c.mode = r < 0.62 ? 'attack' : r < 0.72 ? 'retreat' : r < 0.82 ? 'block' : 'crouch';
        }
        // reação a ataques: bloquear
        const threat = (o.state === 'attack' || o.gen) && dist < 120 || G.ents.some(e => e.dmg && e.owner && e.owner.team !== T && Math.abs(e.x - f.x) < 100);
        if (threat && c.blockT <= 0 && Math.random() < 0.015 * L + 0.012) c.blockT = RC.ri(14, 30);
        if (c.blockT > 0) { c.blockT--; h[back] = true; if (Math.random() < 0.3) h.d = h.d || false; return c.maybeSuper(f, o, G, h, L, dist); }
        if (f.state === 'hit' || f.state === 'blockstun' || f.state === 'down' || f.state === 'dizzy') return;
        switch (c.mode) {
          case 'approach': h[fwd] = true; if (Math.random() < 0.01) h.u = true; break;
          case 'retreat': h[back] = true; break;
          case 'jump': h.u = true; h[fwd] = Math.random() < 0.6; c.mode = 'approach'; break;
          case 'block': h[back] = true; if (Math.random() < 0.5) h.d = true; break;
          case 'crouch': h.d = true; break;
          case 'attack':
            if (dist > 64) { h[fwd] = true; break; }
            if (c.cd <= 0 && (f.state === 'idle' || f.state === 'walk' || f.state === 'crouch' || f.hasHit)) {
              const mv = RC.pick(['lp', 'lp', 'hp', 'lk', 'hk', 'clk', 'chp', 'clp', 'grab']);
              if (mv[0] === 'c') h.d = true; h[mv[0] === 'c' ? mv.slice(1) : mv] = true; c.cd = RC.ri(Math.max(6, 20 - L * 3), 30 - L * 3);
            }
            break;
        }
        c.maybeSuper(f, o, G, h, L, dist);
      };
      c.maybeSuper = function (f, o, G, h, L, dist) {
        const T = f.team; if (f.state !== 'idle' && f.state !== 'walk' && f.state !== 'crouch') return;
        const r = Math.random();
        if (T.meter >= 300 && r < 0.01 + L * 0.004) {
          if (!f.form && !f.fusionId && f.def.form && r < 0.005 + L * 0.002) { h.transform = true; return; }
          if (G.canFuse && G.canFuse(T) && r < 0.004) { h.fusion = true; return; }
          if (dist < 220) { h.ultimate = true; return; }
        }
        if (T.meter >= 100 && dist < 240 && r < 0.012 + L * 0.004) { h.special = true; if (Math.random() < 0.3) h.d = true; return; }
        if (f.def.aux && f.id === 'guilherme' && r < 0.004) h.aux = true;
      };
      return c;
    },
    dummy() { const d = RC.AI.make(1); d.think = function () { for (const a of RC.Input.ACTS) { d.held[a] = false; d.pressed[a] = false; } }; return d; }
  };
})();
