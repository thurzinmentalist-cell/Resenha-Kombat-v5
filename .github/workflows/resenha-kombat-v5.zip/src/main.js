// Bootstrap: canvas, redimensionamento, loop e máquina de telas
(function () {
  const RC = window.RC;
  addEventListener('load', () => {
    const cv = document.getElementById('c'), ctx = cv.getContext('2d', { alpha: false, desynchronized: true });
    ctx.imageSmoothingEnabled = false;
    function fit() { const s = Math.min(innerWidth / RC.W, innerHeight / RC.H); cv.style.width = Math.floor(RC.W * s) + 'px'; cv.style.height = Math.floor(RC.H * s) + 'px'; }
    addEventListener('resize', fit); fit();
    RC.step = () => { RC.frame++; RC.Input.update(); RC.App.update(); RC.Input.endFrame(); };
    RC.Loop.start(RC.step, () => { ctx.imageSmoothingEnabled = false; ctx.setTransform(1, 0, 0, 1, 0, 0); RC.App.render(ctx); });
    RC.App.goto('splash'); RC.Stages.warm();
  });
})();
