// RAFAEL: grife e harém
(function () {
  const RC = window.RC, P = RC.P, FX = RC.FX, A = RC.Audio, D = RC.Draw, GY = RC.GY;
  RC.Chars.rafael = {
    cmd: ['U', 'D', 'F', 'hk'],
    *special(f, o, G) { // harém
      f.anim = 'raise'; P.face(f); G.say('VENHAM, MEUS AMORES!', '#ff8ad0', 60); A.play('special'); yield 14;
      for (let i = 0; i < 5; i++) {
        const fx = i % 2 ? RC.clamp(f.opp.x + f.face * 120, 20, 460) : RC.clamp(f.x - f.face * 24, 20, 460);
        FX.burst(fx, GY - 30, 10, ['#ff8ad0', '#fff'], 3, { g: 0, life: 14 });
        P.runner(G, f, o, (c, x, y, face, t, run) => D.harem(c, x, y, face, t, i, run), { fromX: fx, hits: 1, dmg: 36, sp: 3.6 + i * 0.2, col: '#ff8ad0', gap: 14, launchLast: i === 4, ent: { life: 200 } }); yield 9;
      }
      f.anim = 'cast'; yield 30;
    },
    *ultimate(f, o, G) { // namorada + poder gigante
      G.cutscene(f, 'PODER A DOIS', 104, '#9be8ff', 'RAFAEL'); P.face(f); f.anim = 'cast'; yield 2; A.play('ultimate');
      const gf = G.ent({ owner: f, x: f.x - f.face * 28, y: GY, dmg: 0, life: 170, always: true, draw(c, e) { D.girlfriend(c, e.x, e.y, f.face, e.t); if (e.t % 12 === 0) FX.text(e.x, e.y - 76, '♥', '#ff4d8d', 1, 36); } });
      yield 46; G.shake(12, 76); G.flash('#fff', 5, 0.8);
      const b = P.beam(G, f, { h: 72, c1: '#9be8ff', c2: '#ffffff', life: 74, dmg: 30, every: 6 });
      const upd = b.update; b.update = e => { upd(e); if (e.life < 7) e.d = { kx: 10, ky: -6, launch: true, type: 'unblock', noScale: true }; };
      yield 78; gf.life = 0;
    },
    *fatality(f, o, G) { // ossos, tiro e a fala
      P.fatalSetup(f, o, G); yield 24; P.tp(f, o.x - f.face * 28, '#fff'); f.anim = 'grab'; yield 10;
      for (let i = 0; i < 4; i++) { A.play('hit'); G.shake(7, 8); FX.text(o.x + RC.rnd(-14, 14), o.y - RC.rnd(20, 70), 'CRACK!', '#ece6d2', 1, 30); P.gore(o.x, o.y - 40, 8, RC.pick([-1, 1]), 2); if (i === 1) o.anim = 'broken'; yield 18; }
      o.anim = 'broken'; yield 20; f.face = o.x >= f.x ? 1 : -1; P.tp(f, o.x - f.face * 60, '#fff'); f.gun = true; f.anim = 'shoot'; yield 26;
      A.play('shot'); G.shake(10, 12); G.flash('#fff', 3, 0.6); o.vis = { mode: 'riddled', holes: [[5, -56]] }; P.gore(o.x, o.y - 56, 50, -f.face, 5);
      o.state = 'ko'; o.alive = false; o.downed = true; o.anim = 'down'; yield 30; f.gun = false; f.anim = 'taunt'; yield 14;
      G.say('RESENHATALITY', '#fff', 70); A.play('shout'); yield 70; yield* P.resenhatality(G);
    },
    form: {
      *special(f, o, G) { // espada de cristal + flecha
        P.face(f); f.anim = 'point'; G.say('CRISTAL!', '#9be8ff', 50); yield 12;
        P.proj(G, f, { x: f.x + f.face * 24, y: f.y - 56, vx: f.face * 9, vy: 0, w: 26, h: 26, dmg: 110, life: 90, d: { kx: 4, stun: 20 }, draw: (c, e) => { D.sword(c, e.x, e.y, e.t * 0.5, 1.2); c.globalAlpha = 0.3; D.circ(c, e.x, e.y, 16, '#9be8ff'); c.globalAlpha = 1; } }); A.play('whoosh'); yield 22;
        f.anim = 'shoot'; P.face(f); yield 10;
        P.proj(G, f, { x: f.x + f.face * 24, y: f.y - 52, vx: f.face * 14, vy: 0, w: 22, h: 6, dmg: 100, life: 70, d: { kx: 6, stun: 18 }, draw: (c, e) => D.arrow(c, e.x, e.y, Math.sign(e.vx) || 1) }); A.play('shot'); yield 24;
      }
    }
  };
})();
