// ALEXANDRE: pesadão da cadeirada
(function () {
  const RC = window.RC, P = RC.P, FX = RC.FX, A = RC.Audio, D = RC.Draw, GY = RC.GY;
  function chairEnt(G, f, scale) {
    return G.ent({ owner: f, x: f.x, y: f.y, dmg: 0, life: 300, always: true, update(e) { const k = f.ext; e.x = f.x + f.face * (6 + k * 26); e.y = f.y - 92 * scale / 1.6 + k * 66; e.rot = f.face * (-0.9 + k * 1.7); }, draw(c, e) { D.chair(c, e.x, e.y, scale, e.rot || 0); } });
  }
  RC.Chars.alexandre = {
    cmd: ['D', 'D', 'U', 'hk'],
    *special(f, o, G) { // 4 a 6 hambúrgueres
      f.anim = 'point'; P.face(f); yield 8; const n = RC.ri(4, 6);
      for (let i = 0; i < n; i++) {
        P.proj(G, f, { x: f.x + f.face * 24, y: f.y - 54, vx: f.face * RC.rnd(3.5, 7), vy: RC.rnd(-5.5, -1.5), g: 0.2, w: 18, h: 16, dmg: 34, life: 110, d: { kx: 3, stun: 16 },
          update(e) { if (e.y > GY - 6 && e.vy > 0) { FX.burst(e.x, GY - 4, 5, ['#d98c3a', '#4cc04c', '#6a2d14'], 2, { life: 14 }); e.life = 0; } }, draw(c, e) { D.burger(c, e.x, e.y, 1, e.t * 0.25); } });
        A.play('whoosh'); yield 6;
      }
      yield 12;
    },
    *ultimate(f, o, G) { // cadeirada
      G.cutscene(f, 'CADEIRADA', 100, '#ef6c00', 'ALEXANDRE'); yield 2; P.face(f);
      yield* P.dashTo(f, f.opp, 8, 44, 34); f.anim = 'pound'; f.ext = 0; const ch = chairEnt(G, f, 1.6);
      for (let i = 1; i <= 14; i++) { f.ext = i / 14 * 0.1; yield 1; } yield 12;
      A.play('whoosh'); for (let i = 1; i <= 6; i++) { f.ext = 0.1 + i / 6 * 0.9; yield 1; }
      const v = f.opp; G.hit(f, v, { dmg: 330, kx: 9, ky: -6, launch: true, type: 'unblock' }); G.shake(16, 36); G.flash('#fff', 4, 0.7); A.play('boom');
      FX.burst(f.x + f.face * 30, GY - 20, 30, ['#c43b2b', '#aaa', '#fff'], 5, { life: 40 }); ch.life = 0; yield 34;
    },
    *fatality(f, o, G) { // vira hambúrguer e devora
      P.fatalSetup(f, o, G); yield 24; f.anim = 'raise'; A.play('boom'); G.flash('#fff', 6, 0.9); G.shake(10, 20);
      G.ent({ owner: f, x: o.x, y: 0, dmg: 0, life: 14, always: true, draw(c, e) { D.bolt(c, e.x, 0, o.x, o.y - 40, '#ffe14a', 3); } }); yield 10;
      o.vis = { mode: 'burger', s: 1 }; for (let i = 0; i < 32; i++) { o.vis.s = 1 + i * 0.03; yield 1; } yield 20;
      f.anim = 'grab'; P.tp(f, o.x - f.face * 36, '#fff'); yield 16;
      for (let i = 0; i < 4; i++) { A.play('chomp'); f.anim = i % 2 ? 'lp' : 'hp'; f.ext = 1; o.vis.s *= 0.62; FX.burst(f.x + f.face * 24, f.y - 52, 10, ['#d98c3a', '#fff3c0', '#6a2d14'], 3, { life: 24 }); G.shake(4, 8); yield 26; }
      o.vis = { mode: 'gone' }; o.state = 'ko'; o.alive = false; o.downed = true; f.anim = 'taunt'; FX.text(f.x, f.y - 90, 'ROT!', '#ffe14a', 2, 50); yield 40;
      yield* P.resenhatality(G);
    },
    form: {
      *special(f, o, G) { // teleporta e soca a barriga
        P.face(f); f.anim = 'cast'; yield 6; const v0 = f.opp; P.tp(f, v0.x - f.face * 36, '#e8e8ff'); P.face(f); f.anim = 'point'; yield 4;
        const sph = G.ent({ owner: f, x: f.x, y: f.y, dmg: 0, life: 200, always: true, update(e) { e.x = f.x + f.face * 24; e.y = f.y - 34; }, draw(c, e) { const r = 5 + Math.min(e.t, 24) * 0.25; D.circ(c, e.x, e.y, r + 2, '#111'); D.circ(c, e.x, e.y, r, '#ffe14a'); c.fillStyle = '#111'; c.beginPath(); c.arc(e.x, e.y, r * 0.55, 0, 6.283); c.fill(); c.globalAlpha = 0.35; D.circ(c, e.x, e.y, r * 1.9 + Math.sin(e.t) * 2, '#ffe14a'); c.globalAlpha = 1; } });
        yield 26; f.anim = 'hp'; f.ext = 1; const v = f.opp; G.hit(f, v, { dmg: 120, kx: 11, ky: -4, launch: true, type: 'unblock' }); G.shake(14, 30); G.flash('#ffe14a', 5, 0.6); FX.ring(f.x + f.face * 30, f.y - 34, '#ffe14a', 60); sph.life = 0; yield 22;
      },
      *ultimate(f, o, G) { // raio de 5 segundos
        G.cutscene(f, 'RAIO SOMBRIO', 96, '#e8e8ff', 'ALEXANDRE'); P.face(f); f.anim = 'cast'; yield 2; A.play('ultimate'); yield 14;
        const b = P.beam(G, f, { h: 40, c1: '#e8e8ff', c2: '#16161f', life: 300, dmg: 3, every: 6, d: { kx: 0.6, stun: 8, type: 'unblock', noScale: true } }); G.shake(5, 300);
        while (b.life > 0) { f.anim = 'cast'; yield 2; } yield 10;
      },
      *special2(f, o, G) { // Chuva de Socos Sombrios
        G.cutscene(f, 'CHUVA DE SOCOS SOMBRIOS', 100, '#8a5aff', 'ALEXANDRE'); yield 2; P.face(f); P.tp(f, f.opp.x - f.face * 36, '#222'); P.face(f);
        G.say('SOCOS SOMBRIOS!', '#9a7aff', 60);
        for (let i = 0; i < 24; i++) {
          const v = f.opp; P.face(f); f.anim = i % 2 ? 'hp' : 'lp'; f.ext = 1; if (Math.abs(v.x - f.x) > 60) P.tp(f, v.x - f.face * 36, '#222');
          G.hit(f, v, { dmg: 6, kx: 0.5, stun: 8, type: 'unblock', noScale: true, ...(i === 23 ? { dmg: 40, kx: 9, ky: -6, launch: true } : {}) });
          FX.burst(v.x, v.y - 44, 4, ['#111', '#6a3fd0', '#e8e8ff'], 3, { life: 12 }); yield 5;
        }
        yield 14;
      }
    }
  };
})();
