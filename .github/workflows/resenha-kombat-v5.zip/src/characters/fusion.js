// As 9 FUSÕES (dados em data/fusions.json). Força x3, vida própria, um especial exclusivo.
(function () {
  const RC = window.RC, P = RC.P, FX = RC.FX, A = RC.Audio, D = RC.Draw, GY = RC.GY;
  const ultOf = id => function* (f, o, G) { const pw = f.pow; f.pow = 1.3; yield* RC.Chars[id].ultimate(f, o, G); f.pow = pw; };
  const gothRider = (c, x, y, face, t) => { D.bird(c, x, y, face, t, 2.6); c.save(); c.translate(x, y - 14); c.scale(0.7, 0.7); D.goth(c, 0, 0, face, t, false); c.restore(); };
  RC.Fusions.artugui = {
    ultimate: ultOf('arthur'),
    *special(f, o, G) { // Revoada Gótica
      f.anim = 'raise'; G.say('REVOADA GOTICA', '#f3d54a', 60); A.play('special'); yield 14;
      for (const side of [-1, 1]) {
        G.ent({ owner: f, x: side < 0 ? -30 : 510, y: 30, w: 44, h: 44, dmg: 30, every: 18, pierce: true, life: 220, d: { kx: 4, ky: -4, stun: 16, launch: false }, ph: 0, tx: 0, ty: 0,
          update(e) { const v = f.opp; if (e.t % 60 === 1) { e.tx = v.x; e.ty = v.y - 40; } const dx = e.tx - e.x, dy = e.ty - e.y, d = Math.hypot(dx, dy) || 1; if (e.t % 60 < 30) { e.vx = dx / d * 8; e.vy = dy / d * 8; } else { e.vx = side * 3; e.vy = -5; } e.face = Math.sign(e.vx) || 1; },
          draw(c, e) { gothRider(c, e.x, e.y, e.face || 1, e.t); } });
        yield 22;
      }
      yield 80;
    }
  };
  RC.Fusions.kagui = {
    ultimate: ultOf('guilherme'),
    *special(f, o, G) { // Chuva de Calopsitas Sorridentes
      f.anim = 'raise'; G.say('CHUVA DE CALOPSITAS!', '#ffe14a', 60); A.play('special'); yield 14;
      yield* RC.P.smileyRain(G, f, o, 18, 14, (c, e) => D.bird(c, e.x, e.y, Math.sign(e.vx) || 1, e.t, 1.2, { ball: true }), 100, 5); yield 16;
    }
  };
  RC.Fusions.xantur = {
    ultimate: ultOf('alexandre'),
    *special(f, o, G) { // Cadeirada Presidencial
      G.say('CADEIRADA PRESIDENCIAL', '#2fd06b', 70); P.face(f); yield* P.dashTo(f, f.opp, 8, 46, 34); f.anim = 'pound'; f.ext = 0; A.play('special');
      const ch = G.ent({ owner: f, x: f.x, y: f.y, dmg: 0, life: 300, always: true, update(e) { const k = f.ext; e.x = f.x + f.face * (6 + k * 26); e.y = f.y - 100 + k * 70; e.rot = f.face * (-0.9 + k * 1.7); if (e.t % 2 === 0) FX.add({ x: e.x + RC.rnd(-16, 16), y: e.y + RC.rnd(-16, 16), life: 10, c: RC.pick(['#2fd06b', '#ffe14a', '#fff']), s: 2 }); }, draw(c, e) { D.chair(c, e.x, e.y, 1.8, e.rot || 0, { col: '#2fd06b' }); D.bolt(c, e.x - 20, e.y - 20, e.x + 20, e.y + 10, '#ffe14a', 2); } });
      for (let i = 1; i <= 16; i++) { f.ext = i / 16 * 0.1; yield 1; } yield 12;
      for (let i = 1; i <= 6; i++) { f.ext = 0.1 + i / 6 * 0.9; yield 1; }
      G.hit(f, f.opp, { dmg: 160, kx: 10, ky: -7, launch: true, type: 'unblock' }); G.shake(18, 40); G.flash('#2fd06b', 5, 0.8); A.play('boom'); ch.life = 0; yield 34;
    }
  };
  RC.Fusions.artoddy = {
    ultimate: ultOf('toddy'),
    *special(f, o, G) { G.say('COMICIO DO GUARDIAO', '#2fd06b', 60); yield* P.toddyBarrage(f, o, G, 35, 4, 6, 30); }
  };
  RC.Fusions.guiddy = {
    ultimate: ultOf('toddy'),
    *special(f, o, G) { // Parada do Poleiro
      f.anim = 'point'; P.face(f); G.say('PARADA DO POLEIRO', '#8a3ff0', 70); yield 8;
      G.ent({ owner: f, x: f.x + f.face * 14, y: f.y - 50, dmg: 0, life: 24, update(e) { const v = f.opp; e.x += (v.x - e.x) * 0.3; e.y += (v.y - 55 - e.y) * 0.3; }, draw(c, e) { D.bird(c, e.x, e.y, f.face, e.t, 1); } }); yield 14;
      P.tp(f, P.behind(f, f.opp, 34), '#8a3ff0'); P.face(f); A.play('time'); G.flash('#fff', 8, 0.9); G.startTimeStop(f, 180); yield 20;
    }
  };
  RC.Fusions.kaxandre = {
    ultimate: ultOf('alexandre'),
    *special(f, o, G) { // Hambúrguer Sorridente
      G.say('HAMBURGUER SORRIDENTE', '#ffe14a', 70); P.face(f); f.anim = 'cast'; yield 12; f.vis = { mode: 'hidden' }; const dir = f.face; let bx = f.x;
      const ball = G.ent({ owner: f, x: f.x, y: GY - 28, vx: dir * 6, w: 56, h: 56, dmg: 50, life: 70, d: { kx: 6, ky: -3, stun: 20 }, pierce: false, update(e) { bx = e.x; e.y = GY - 28 - Math.abs(Math.sin(e.t * 0.2)) * 8; if (e.t % 8 === 0) { P.proj(G, f, { x: e.x, y: e.y - 20, vx: dir * RC.rnd(3, 6), vy: RC.rnd(-7, -3), g: 0.25, w: 18, h: 16, dmg: 16, life: 90, d: { kx: 3, stun: 14 }, update(b) { if (b.y > GY - 6 && b.vy > 0) b.life = 0; }, draw: (c, b) => D.burger(c, b.x, b.y, 1, b.t * 0.3) }); } }, draw(c, e) { D.smiley(c, e.x, e.y, 28, e.t * 0.2 * dir); } });
      A.play('whoosh'); while (ball.life > 0) yield 2;
      f.x = RC.clamp(bx, 20, 460); f.vis = null; P.face(f); yield* P.dashTo(f, f.opp, 8, 40, 20); P.face(f); f.anim = 'hp'; f.ext = 1; yield 14;
      const sph = G.ent({ owner: f, x: f.x, y: f.y, dmg: 0, life: 40, always: true, update(e) { e.x = f.x + f.face * 24; e.y = f.y - 34; }, draw(c, e) { D.circ(c, e.x, e.y, 12, '#111'); D.circ(c, e.x, e.y, 10, '#ffe14a'); D.circ(c, e.x, e.y, 5, '#111'); } });
      G.hit(f, f.opp, { dmg: 90, kx: 11, ky: -5, launch: true, type: 'unblock' }); G.shake(14, 30); G.flash('#ffe14a', 5, 0.7); yield 26; sph.life = 0;
    }
  };
  RC.Fusions.vithur = {
    ultimate: ultOf('vitin'),
    *special(f, o, G) { // Tio Presidente
      f.anim = 'raise'; G.say('TIO PRESIDENTE', '#2fd06b', 70); A.play('shout'); yield 14; const v0 = f.opp;
      const ux = RC.clamp(v0.x + f.face * 50, 20, 460), px = RC.clamp(v0.x - f.face * 50, 20, 460);
      FX.burst(ux, GY - 30, 16, ['#fff', '#ffd84a'], 3, { g: 0, life: 16 }); FX.burst(px, GY - 30, 16, ['#fff', '#2fd06b'], 3, { g: 0, life: 16 });
      const unc = G.ent({ owner: f, x: ux, y: GY, dmg: 0, life: 200, always: true, atk: 0, draw(c, e) { D.uncle(c, e.x + (e.atk > 0 ? -f.face * 8 : 0), e.y, -f.face, e.t); if (e.atk > 0) e.atk--; } });
      const pre = G.ent({ owner: f, x: px, y: GY, dmg: 0, life: 200, always: true, atk: 0, draw(c, e) { D.suited(c, e.x + (e.atk > 0 ? f.face * 8 : 0), e.y, f.face, e.t); if (e.atk > 0) e.atk--; } });
      yield 20;
      for (let i = 0; i < 6; i++) { const v = f.opp; (i % 2 ? unc : pre).atk = 8; G.hit(f, v, { dmg: 20, kx: 0.8, stun: 14, type: 'unblock', noScale: true }); FX.text(v.x + RC.rnd(-14, 14), v.y - 80, RC.pick(['POW!', 'BAM!', 'PLOC!']), '#ffd84a', 2, 30); yield 11; }
      f.anim = 'shoot'; P.face(f); const g = G.ent({ owner: f, x: f.x, y: f.y, dmg: 0, life: 80, always: true, update(e) { e.x = f.x + f.face * 18; e.y = f.y - 50; }, draw(c, e) { D.gun(c, e.x, e.y, f.face, true); } }); yield 14;
      FX.burst(f.x + f.face * 46, f.y - 50, 10, ['#ffe27a', '#fff'], 4, { life: 10 }); A.play('shot'); G.shake(10, 12);
      const v = f.opp; G.hit(f, v, { dmg: 70, kx: 10, ky: -5, launch: true, type: 'unblock' }); FX.text(v.x, v.y - 96, '200', '#ffe14a', 4, 80); yield 30; unc.life = 0; pre.life = 0; g.life = 0;
    }
  };
  RC.Fusions.vitoddy = {
    ultimate: ultOf('toddy'),
    *special(f, o, G) { // Lição do Pequeno
      G.say('LICAO DO PEQUENO', '#b36bff', 70); P.face(f); yield* P.dashTo(f, f.opp, 9, 52, 30); P.face(f); f.anim = 'grab'; yield 6; let v = f.opp;
      if (Math.abs(v.x - f.x) > 90) P.tp(f, v.x - f.face * 46, '#8a3ff0');
      if (!G.hit(f, v, { dmg: 20, kx: 0, stun: 12, type: 'unblock', noScale: true })) { yield 12; return; }
      f.guard = { pose: 'punch', off: 40, e: 0 };
      for (let i = 0; i < 30; i++) { v = f.opp; if (!v.alive) break; v.vx = 0; G.hit(f, v, { dmg: 4, kx: 0, stun: 14, type: 'unblock', noScale: true, ...(i === 29 ? { dmg: 35, kx: 10, ky: -6, launch: true } : {}) }); FX.spark(v.x, v.y - 46 + RC.rnd(-12, 12), '#b36bff', 3); yield 10; }
      f.guard = null; FX.text(v.x, v.y - 96, '200', '#ffe14a', 4, 90); G.shake(10, 20); yield 24;
    }
  };
  RC.Fusions.kaddy = {
    ultimate: ultOf('toddy'),
    *special(f, o, G) { // Vazio Sorridente
      f.anim = 'cast'; P.face(f); G.say('VAZIO SORRIDENTE', '#ffe14a', 70); A.play('special');
      const orbDraw = (c, x, y, r, t) => { c.globalAlpha = 0.3; D.circ(c, x, y, r * 1.6, '#8a2be2'); c.globalAlpha = 1; D.circ(c, x, y, r, '#8a2be2'); for (let i = 0; i < 5; i++) { const a = t * 0.2 + i * 1.256; D.smiley(c, x + Math.cos(a) * r * 0.55, y + Math.sin(a) * r * 0.55, 5, a); } };
      const o1 = G.ent({ owner: f, x: 0, y: 0, dmg: 0, life: 300, always: true, update(e) { e.x = f.x + f.face * 18; e.y = f.y - 52; }, draw(c, e) { orbDraw(c, e.x, e.y, 4 + Math.min(e.t, 44) * 0.3, e.t); } });
      yield 56; o1.life = 0; G.flash('#ffe14a', 5, 0.6); A.play('beam');
      P.proj(G, f, { x: f.x + f.face * 14, y: f.y - 52, vx: f.face * 5, w: 38, h: 38, dmg: 90, life: 160, d: { kx: 10, ky: -6, launch: true }, draw: (c, e) => orbDraw(c, e.x, e.y, 20, e.t), onHit() { G.acid = 240; } });
      yield 20; G.acid = 240; yield 30;
      for (let i = 0; i < 34; i++) { const x = RC.rnd(8, 472); G.ent({ owner: f, x, y: -10, vy: RC.rnd(5, 8), w: 6, h: 12, dmg: 8, life: 80, d: { kx: 1, stun: 10, type: 'unblock', noScale: true }, update(e) { if (e.y >= GY - 2) { FX.burst(e.x, GY - 2, 4, ['#aaff3a', '#6ad82a'], 2, { life: 12 }); e.life = 0; } }, draw(c, e) { c.fillStyle = '#0c0a10'; c.fillRect(Math.round(e.x - 2), Math.round(e.y - 7), 5, 13); c.fillStyle = '#aaff3a'; c.fillRect(Math.round(e.x - 1), Math.round(e.y - 6), 3, 11); } }); yield 3; }
      yield 20;
    }
  };
})();
