// KAIQUE: sorriso mortal
(function () {
  const RC = window.RC, P = RC.P, FX = RC.FX, A = RC.Audio, D = RC.Draw, GY = RC.GY;
  function smileyRain(G, f, o, n, dmg, drawFn, spread, gap) {
    return (function* () {
      for (let i = 0; i < n; i++) {
        const v = f.opp, x = RC.clamp(v.x + RC.rnd(-spread, spread), 12, 468);
        G.ent({ owner: f, x, y: -12, vx: RC.rnd(-0.4, 0.4), vy: RC.rnd(3, 5), g: 0.1, w: 18, h: 18, dmg, life: 140, d: { kx: 2, stun: 14 }, rot: RC.rnd(0, 6),
          update(e) { e.rot += 0.1; if (e.y >= GY - 9 && e.vy > 0) { if (!e.bn) { e.bn = 1; e.vy *= -0.5; FX.dust(e.x, GY, 3); } else e.life = 0; } },
          draw: drawFn || ((c, e) => D.smiley(c, e.x, e.y, 9, e.rot)) });
        yield gap;
      }
    })();
  }
  RC.Chars.kaique = {
    cmd: ['B', 'F', 'D', 'hk'],
    *special(f, o, G) { // Chuva de Verities
      f.anim = 'raise'; G.say('CHUVA DE VERITIES', '#ffe14a', 50); A.play('special'); yield 14; yield* smileyRain(G, f, o, 12, 28, null, 90, 5); yield 14;
    },
    *ultimate(f, o, G) { // GONHA-GONHA
      G.cutscene(f, 'GONHA-GONHA', 100, '#ffe14a', 'KAIQUE'); P.face(f); yield 2; yield* P.dashTo(f, f.opp, 8, 40, 34); P.face(f);
      f.anim = 'hp'; f.ext = 1; yield 10; G.say('GONHA-GONHA!!!', '#ffe14a', 90); A.play('shout'); G.shake(14, 40); G.flash('#fff', 4, 0.6);
      for (let i = 0; i < 3; i++) FX.ring(f.x + f.face * 26, f.y - 56, '#ffe14a', 90 + i * 20, 24 + i * 4);
      const v = f.opp; G.hit(f, v, { dmg: 280, kx: 13, ky: -4, launch: true, dizzy: 130, type: 'unblock' }); yield 40;
    },
    *fatality(f, o, G) { // vira bola gigante e engole
      P.fatalSetup(f, o, G); yield 24; f.anim = 'cast'; A.play('transform'); G.flash('#ffe14a', 8, 0.8);
      const bl = { r: 14, x: f.x, face: f.face, inside: false };
      f.vis = { mode: 'hidden' };
      const ent = G.ent({ owner: f, x: f.x, y: GY, dmg: 0, life: 900, always: true, draw(c) {
        D.smiley(c, bl.x, GY - bl.r, bl.r, 0);
        if (bl.inside) { c.save(); c.beginPath(); c.arc(bl.x, GY - bl.r, bl.r - 3, 0, 6.283); c.clip(); c.globalAlpha = 0.55; for (let i = 0; i < 4; i++) D.circ(c, bl.x + Math.sin(ent.t * 0.4 + i) * bl.r * 0.4, GY - bl.r + Math.cos(ent.t * 0.5 + i * 2) * bl.r * 0.4, 5, '#b3001b'); c.restore(); }
      } });
      for (let i = 0; i < 26; i++) { bl.r += 2.2; yield 1; } G.shake(6, 30); yield 14;
      for (let i = 0; i < 28; i++) { bl.x += (o.x - bl.x) * 0.16; yield 1; }
      A.play('chomp'); o.vis = { mode: 'hidden' }; bl.inside = true; bl.x = o.x; G.shake(10, 20); FX.ring(o.x, GY - 40, '#ffe14a', 80);
      for (let i = 0; i < 70; i++) { if (i % 5 === 0) { A.play('blood'); G.shake(4, 6); } if (i % 3 === 0) FX.blood(bl.x + RC.rnd(-14, 14), GY - bl.r, 3, RC.pick([-1, 1]), 2); bl.r += Math.sin(i * 0.6) * 0.3; yield 1; }
      A.play('chomp'); FX.blood(bl.x, GY - bl.r, 50, 1, 4); G.flash('#b3001b', 6, 0.6); yield 20;
      o.vis = { mode: 'gone' }; o.state = 'ko'; o.alive = false; o.downed = true;
      for (let i = 0; i < 26; i++) { bl.r -= 2.2; yield 1; } ent.life = 0; f.vis = null; f.x = bl.x; f.anim = 'taunt'; FX.text(f.x, f.y - 90, ':)', '#ffe14a', 3, 60); yield 40;
      yield* P.resenhatality(G);
    },
    form: {
      *special(f, o, G) { // CHUVA DE GONHA-GONHA (ácido)
        f.anim = 'raise'; G.say('CHUVA DE GONHA-GONHA', '#aaff3a', 80); A.play('shout'); G.acid = 300; G.flash('#aaff3a', 8, 0.5); yield 20;
        for (let i = 0; i < 54; i++) {
          const x = RC.rnd(8, 472);
          G.ent({ owner: f, x, y: -10, vy: RC.rnd(5, 8), w: 6, h: 12, dmg: 20, life: 80, d: { kx: 1.2, stun: 10, type: 'unblock', noScale: true }, update(e) { if (e.y >= GY - 2) { FX.burst(e.x, GY - 2, 4, ['#aaff3a', '#6ad82a'], 2, { life: 12 }); e.life = 0; } }, draw(c, e) { c.fillStyle = '#0c0a10'; c.fillRect(Math.round(e.x - 2), Math.round(e.y - 7), 5, 13); c.fillStyle = '#aaff3a'; c.fillRect(Math.round(e.x - 1), Math.round(e.y - 6), 3, 11); c.fillStyle = '#eaff9a'; c.fillRect(Math.round(e.x - 1), Math.round(e.y - 6), 1, 4); } });
          yield 3;
        }
        yield 24;
      }
    }
  };
  RC.P.smileyRain = smileyRain;
})();
