// JOEL: dança da derrota
(function () {
  const RC = window.RC, P = RC.P, FX = RC.FX, A = RC.Audio, D = RC.Draw, GY = RC.GY;
  RC.Chars.joel = {
    cmd: ['F', 'B', 'F', 'hp'],
    *special(f, o, G) { // dança da derrota (L) + poder
      P.face(f); f.anim = 'dance'; A.play('select'); yield 20; const v = f.opp;
      G.say('L', '#ffffff', 60); FX.text(v.x, v.y - 100, 'L', '#ffffff', 5, 70); for (const dx of [-14, 14]) FX.text(f.x + dx, f.y - 96, 'L', '#ffe14a', 2, 50);
      G.dizzy(v, 90); yield 40;
      P.proj(G, f, { x: f.x + f.face * 22, y: f.y - 50, vx: f.face * 6, w: 30, h: 30, dmg: 150, life: 140, d: { kx: 8, ky: -4, launch: true }, draw: P.ballDraw('#ff8a1a', '#ffe9a0') }); A.play('beam'); f.anim = 'cast'; yield 26;
    },
    *ultimate(f, o, G) { // pula na cabeça e peida
      G.cutscene(f, 'PEIDO NA CARA', 100, '#fbc02d', 'JOEL'); P.face(f); yield 2; f.noGrav = true; f.anim = 'jump'; A.play('jump');
      const x0 = f.x, v = f.opp, x1 = v.x - f.face * 6, n = 32;
      for (let i = 1; i <= n; i++) { f.x = x0 + (x1 - x0) * i / n; f.y = GY - Math.sin(i / n * Math.PI) * 130 - (i / n) * 66 * (i / n); yield 1; }
      f.y = f.opp.y - 72; f.x = f.opp.x; G.hit(f, f.opp, { dmg: 50, kx: 0, stun: 40, type: 'unblock', noScale: true }); G.shake(8, 14); yield 14;
      f.anim = 'taunt'; A.play('fart'); G.say('PRRRRT', '#9dd84a', 60);
      for (let i = 0; i < 14; i++) FX.add({ x: v.x + f.face * 8, y: v.y - 56, vx: RC.rnd(-1.4, 1.4), vy: RC.rnd(-1.5, 0.5), life: 50, c: RC.pick(['#8fd33a', '#6aa82a', '#b8e86a']), s: 4 });
      G.ent({ owner: f, x: v.x, y: v.y - 56, dmg: 0, life: 70, always: true, draw(c, e) { c.globalAlpha = 0.45 * Math.min(1, e.life / 30); for (let i = 0; i < 8; i++) D.circ(c, e.x + Math.sin(i * 2 + e.t * 0.2) * 14, e.y - Math.cos(i) * 8 - e.t * 0.2, 12 + i, '#8fd33a'); c.globalAlpha = 1; } });
      G.hit(f, f.opp, { dmg: 220, kx: 3, stun: 40, type: 'unblock', dizzy: 100, noScale: true }); G.shake(10, 30); yield 30;
      f.noGrav = false; f.vy = -2; f.vx = -f.face * 2; yield 30;
    },
    *fatality(f, o, G) { // quebra o pescoço, joga pro alto e incinera
      P.fatalSetup(f, o, G); yield 24; P.tp(f, o.x - f.face * 26, '#fff'); f.anim = 'grab'; yield 20;
      A.play('hit'); G.shake(10, 14); FX.text(o.x, o.y - 80, 'CRACK!', '#ece6d2', 2, 40); P.gore(o.x, o.y - 58, 20, f.face, 3); yield 24;
      o.noGrav = true; o.vis = { mode: 'ragdoll', rot: 0, p: 0 }; const y0 = o.y, ys = f.y;
      for (let i = 0; i < 34; i++) { o.y = y0 - i * 4.4; o.vis.rot += 0.22; f.anim = 'raise'; yield 1; }
      f.anim = 'crouch'; A.play('fart'); G.say('PRRRRRRRRT!!', '#ff8a1a', 80);
      for (let i = 0; i < 120; i++) {
        o.vis.p = Math.min(1, i / 70); o.vis.rot += 0.04;
        if (i === 70) o.vis.mode = 'ragdoll';
        for (let k = 0; k < 3; k++) { const t = Math.random(); FX.add({ x: f.x + (o.x - f.x) * t + RC.rnd(-6, 6), y: f.y - 20 + (o.y - 30 - f.y + 20) * t + RC.rnd(-6, 6), vx: RC.rnd(-0.5, 0.5), vy: RC.rnd(-1.2, 0), life: 18, c: RC.pick(['#ff8a1a', '#ffd24a', '#8fd33a', '#fff']), s: 3 }); }
        if (i % 5 === 0) G.shake(4, 6); yield 1;
      }
      o.vis = { mode: 'gone' }; for (let i = 0; i < 60; i++) FX.add({ x: o.x + RC.rnd(-14, 14), y: o.y - 30 + RC.rnd(-20, 20), vx: RC.rnd(-0.6, 0.6), vy: RC.rnd(0.2, 1.2), g: 0.02, life: 80, c: RC.pick(['#2a2420', '#4a423a', '#1a1612']), s: 2 });
      o.noGrav = false; o.y = GY; o.state = 'ko'; o.alive = false; o.downed = true; f.anim = 'taunt'; yield 60; yield* P.resenhatality(G);
    },
    form: {
      *special(f, o, G) { // supercarro esportivo
        P.face(f); G.say('VRUUUM!', '#ff4040', 60); A.play('special'); f.anim = 'raise'; yield 14; f.vis = { mode: 'hidden' };
        const dir = f.face, sx = dir > 0 ? -130 : 610; let carX = sx;
        const car = G.ent({ owner: f, x: sx, y: GY - 18, vx: dir * 15, w: 96, h: 40, dmg: 150, life: 70, d: { kx: 10, ky: -6, launch: true }, pierce: false,
          update(e) { carX = e.x; if (e.t % 2 === 0) FX.dust(e.x - dir * 50, GY, 2); },
          draw(c, e) { D.car(c, e.x, GY, dir, e.t); D.circ(c, e.x + dir * 4, GY - 24, 5, '#6b4220'); D.circ(c, e.x + dir * 6, GY - 25, 2, '#c79a68'); } });
        A.play('whoosh'); G.shake(5, 60);
        while (car.life > 0) yield 2;
        f.x = RC.clamp(carX, 20, 460); f.vis = null; f.anim = 'taunt'; yield 14;
      }
    }
  };
})();
