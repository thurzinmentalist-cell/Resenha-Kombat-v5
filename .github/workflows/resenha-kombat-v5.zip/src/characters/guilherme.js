// GUILHERME: mestre do teleporte (calopsita-marcador)
(function () {
  const RC = window.RC, P = RC.P, FX = RC.FX, A = RC.Audio, D = RC.Draw, GY = RC.GY;
  function markEnt(G, f) {
    const m = f.mark;
    G.ent({ owner: f, x: 0, y: 0, dmg: 0, life: 99999, always: true,
      update(e) { if (f.mark !== m || RC.frame - m.f > 600 || !f.alive) { e.life = 0; if (f.mark === m) f.mark = null; return; } if (m.target) { e.x = m.target.x; e.y = m.target.y - 82; } else { e.x = m.x; e.y = m.y; } },
      draw(c, e) { D.bird(c, e.x, e.y + Math.sin(e.t * 0.1) * 2, 1, 0, 1); const r = 10 + Math.sin(e.t * 0.2) * 3; c.strokeStyle = '#ffe066'; c.lineWidth = 1; c.beginPath(); c.arc(e.x, e.y - 6, r, 0, 6.283); c.stroke(); RC.Text.draw(c, 'X', e.x, e.y - 30, { a: 'c', c: '#ffe066', ol: '#000' }); } });
  }
  RC.Chars.guilherme = {
    cmd: ['D', 'F', 'D', 'hp'],
    aux(f, o, G) {
      f.cd.aux = 20;
      if (f.mark) {
        const m = f.mark, x = m.target && m.target.alive ? P.behind(f, m.target, 34) : m.x;
        P.tp(f, x, '#ffe066'); f.mark = null; f.invuln = Math.max(f.invuln, 6); P.face(f); return;
      }
      f.run(function* (f, o, G) {
        f.anim = 'point'; P.face(f); yield 7;
        G.ent({ owner: f, x: f.x + f.face * 18, y: f.y - 54, vx: f.face * 6.5, vy: -2.4, g: 0.16, w: 14, h: 12, dmg: 14, life: 90, d: { kx: 1, stun: 8 },
          update(e) { if (e.y >= GY - 6) { e.life = 0; f.mark = { x: e.x, y: GY - 12, f: RC.frame }; markEnt(G, f); } },
          onHit(e, v) { f.mark = { target: v, f: RC.frame }; markEnt(G, f); },
          draw(c, e) { D.bird(c, e.x, e.y, Math.sign(e.vx) || 1, e.t, 1); } });
        A.play('whoosh'); yield 8;
      });
    },
    *special(f, o, G) { // Troca de Poleiro
      f.anim = 'point'; P.face(f); yield 8;
      G.ent({ owner: f, x: f.x + f.face * 14, y: f.y - 50, dmg: 0, life: 30, update(e) { const v = f.opp; e.x += (v.x - e.x) * 0.3; e.y += (v.y - 55 - e.y) * 0.3; }, draw(c, e) { D.bird(c, e.x, e.y, f.face, e.t, 1); } });
      A.play('whoosh'); yield 12;
      let v = f.opp; P.tp(f, P.behind(f, v, 30), '#ffe066'); f.face = v.x >= f.x ? 1 : -1; f.invuln = 12;
      for (const [an, d] of [['lk', { dmg: 45, kx: 1.5, stun: 14 }], ['hp', { dmg: 50, kx: 1.5, stun: 14 }], ['hk', { dmg: 110, kx: 8, ky: -5, launch: true }]]) {
        v = f.opp; f.anim = an; f.ext = 1; f.face = v.x >= f.x ? 1 : -1;
        if (Math.abs(v.x - f.x) > 70) P.tp(f, P.behind(f, v, 30), '#ffe066');
        G.hit(f, v, Object.assign({ type: 'mid' }, d)); yield 9;
      }
      f.ext = 0;
    },
    *ultimate(f, o, G) { // Calopsita Gigante
      G.cutscene(f, 'CALOPSITA GIGANTE', 104, '#ffe066', 'GUILHERME'); f.anim = 'raise'; yield 2; A.play('ultimate');
      const bx = f.face > 0 ? 350 : 130, dir = -f.face;
      const bird = G.ent({ owner: f, x: bx, y: -80, dmg: 0, life: 150, always: true, charge: 0,
        update(e) { e.y = Math.min(150, e.y + 3.5); if (e.y >= 150) e.charge++; if (e.t % 9 === 0) FX.burst(e.x + RC.rnd(-30, 30), e.y - 20, 1, ['#f5f0e0', '#ffd93d'], 1, { g: 0.06, life: 40 }); },
        draw(c, e) {
          D.bird(c, e.x, e.y, dir, e.t * 1.4, 3.5, { glow: e.charge > 0 ? '#ffe066' : null });
          if (e.charge > 0) { const r = Math.min(20, e.charge * 0.4), ox = e.x + dir * 52, oy = e.y - 45;
            for (let i = 0; i < 10; i++) { const a = i * 0.628 + e.t * 0.12, d = 54 - ((e.t * 2.2 + i * 9) % 54); c.fillStyle = i % 2 ? '#fff6a8' : '#ffd93d'; c.fillRect(Math.round(ox + Math.cos(a) * d), Math.round(oy + Math.sin(a) * d), 3, 3); }
            D.orb(c, ox, oy, r, '#ffd93d', '#fff6a8', e.t); } } });
      yield 70;
      G.shake(10, 70); G.flash('#fff6a8', 6, 0.8); A.play('beam');
      const x0 = bx + dir * 52, y0 = 105;
      G.ent({ owner: f, x: 0, y: GY - 40, w: 100, h: 110, dmg: 30, every: 5, pierce: true, life: 62, d: { kx: 1.5, stun: 9, type: 'unblock', noScale: true },
        update(e) { const x1 = f.x + f.face * 16, lo = Math.min(x0, x1), hi = Math.max(x0, x1); e.x = (lo + hi) / 2; e.w = hi - lo; if (e.life < 7) e.d = { kx: 9, ky: -6, launch: true, type: 'unblock', noScale: true }; },
        draw(c, e) { const x1 = f.x + f.face * 16, y1 = GY - 40, dx = x1 - x0, dy = y1 - y0, len = Math.hypot(dx, dy), k = Math.min(1, e.t / 6) * Math.min(1, e.life / 8);
          c.save(); c.translate(x0, y0); c.rotate(Math.atan2(dy, dx)); D.beam(c, 0, 0, len, 30 * k, '#ffd93d', '#fff6a8', e.t); c.restore();
          D.orb(c, x0, y0, 22 * k, '#ffd93d', '#fff6a8', e.t); D.orb(c, x1, y1, 16 * k, '#ffe066', '#fff', e.t + 5);
          if (e.t % 4 === 0) { FX.burst(x1, y1, 4, ['#ffd93d', '#fff6a8', '#ff9a2a'], 4, { g: 0.1, life: 14 }); if (e.t % 12 === 0) FX.shock(x1, y1, '#ffe066', 36); } } });
      f.anim = 'cast'; yield 66; bird.life = 0;
    },
    *fatality(f, o, G) { // muriçocas
      P.fatalSetup(f, o, G); yield 30; f.anim = 'crouch'; A.play('fart'); G.say('...', '#9d9', 40);
      const cloud = G.ent({ owner: f, x: f.x + f.face * 14, y: f.y - 14, dmg: 0, life: 400, always: true, update(e) { e.x += (o.x - e.x) * 0.02; }, draw(c, e) { c.globalAlpha = 0.4; for (let i = 0; i < 6; i++) D.circ(c, e.x + Math.sin(e.t * 0.1 + i) * 10 + i * 4, e.y - Math.cos(i) * 8 - e.t * 0.05, 10 + i, '#7a9a3a'); c.globalAlpha = 1; } });
      yield 50;
      const bugs = []; for (let i = 0; i < 46; i++) bugs.push({ x: f.x + f.face * 20, y: f.y - 20, a: RC.rnd(0, 6.28) });
      const sw = G.ent({ owner: f, x: 0, y: 0, dmg: 0, life: 400, always: true, update(e) { for (const b of bugs) { const tx = o.x + Math.cos(b.a + e.t * 0.2) * 16, ty = o.y - 36 + Math.sin(b.a * 2 + e.t * 0.3) * 30; b.x += (tx - b.x) * 0.12 + RC.rnd(-2, 2); b.y += (ty - b.y) * 0.12 + RC.rnd(-2, 2); } }, draw(c) { c.fillStyle = '#111'; for (const b of bugs) c.fillRect(Math.round(b.x), Math.round(b.y), 2, 2); } });
      cloud.life = 0; o.vis = { mode: 'drain', p: 0 }; A.play('blood');
      for (let i = 0; i < 100; i++) { o.vis.p = i / 100; if (i % 3 === 0) { const b = RC.pick(bugs); FX.add({ x: o.x + RC.rnd(-8, 8), y: o.y - RC.rnd(10, 60), vx: (b.x - o.x) * 0.04, vy: (b.y - o.y + 36) * 0.04, life: 14, c: '#b3001b', s: 2 }); } yield 1; }
      o.vis = { mode: 'skeleton' }; G.shake(6, 20); yield 50;
      sw.life = 0; for (let i = 0; i < 20; i++) FX.add({ x: o.x + RC.rnd(-10, 10), y: o.y - RC.rnd(0, 60), vx: RC.rnd(-1, 1), vy: RC.rnd(-2, 0), g: 0.1, life: 40, c: '#ece6d2', s: 2 });
      o.state = 'ko'; o.alive = false; o.downed = true; o.anim = 'down'; yield 30;
      yield* P.resenhatality(G);
    },
    form: {
      *special(f, o, G) { // Enxame de Calopsitas
        f.anim = 'raise'; G.say('ENXAME!', '#ffe066', 40); A.play('shout'); yield 16;
        for (let i = 0; i < 14; i++) {
          G.ent({ owner: f, x: f.x + RC.rnd(-30, 30), y: f.y - RC.rnd(60, 110), vx: RC.rnd(-2, 2), vy: RC.rnd(-3, 0), w: 16, h: 12, dmg: 24, life: 120, d: { kx: 2, stun: 12 }, update(e) { P.homing(e, 6, 0.1); },
            draw(c, e) { D.bird(c, e.x, e.y, Math.sign(e.vx) || 1, e.t + i * 3, 1); } });
          A.play('whoosh'); yield 4;
        }
        yield 20;
      }
    }
  };
})();
