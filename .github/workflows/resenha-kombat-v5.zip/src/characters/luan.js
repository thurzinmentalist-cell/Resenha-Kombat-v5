// LUAN: lei e ordem
(function () {
  const RC = window.RC, P = RC.P, FX = RC.FX, A = RC.Audio, D = RC.Draw, GY = RC.GY;
  function bullet(G, f, o = {}) {
    A.play('shot'); FX.spark(f.x + f.face * 36, f.y - 50, '#ffe27a', 5); FX.add({ x: f.x + f.face * 10, y: f.y - 46, vx: -f.face * RC.rnd(1, 2), vy: RC.rnd(-3, -1), g: 0.3, life: 30, c: '#d4a82b', s: 2 });
    return P.proj(G, f, Object.assign({ x: f.x + f.face * 38, y: f.y - 50, vx: f.face * 13, w: 12, h: 5, dmg: 14, life: 50, d: { kx: 1.2, stun: 9, noScale: false }, draw: (c, e) => { c.fillStyle = '#ffe27a'; c.fillRect(Math.round(e.x - 8 * Math.sign(e.vx)), Math.round(e.y - 1), 16, 3); c.fillStyle = '#fff'; c.fillRect(Math.round(e.x - 3), Math.round(e.y - 1), 6, 2); } }, o));
  }
  RC.Chars.luan = {
    cmd: ['D', 'D', 'D', 'lp'],
    *special(f, o, G) { // duas pistolas, um tiro
      f.gun = true; f.anim = 'shoot'; P.face(f); yield 12; bullet(G, f, { dmg: 80, w: 16, d: { kx: 4, stun: 18 } }); f.vx = -f.face * 1.4; G.shake(3, 6); yield 22; f.gun = false;
    },
    *ultimate(f, o, G) { // rajada
      G.cutscene(f, 'RAJADA DE CHUMBO', 100, '#1e88e5', 'LUAN'); f.gun = true; f.anim = 'shoot'; P.face(f); yield 2; A.play('ultimate'); yield 10;
      for (let i = 0; i < 26; i++) { P.face(f); const last = i === 25; bullet(G, f, { y: f.y - 50 + RC.rnd(-16, 16), dmg: last ? 60 : 14, vx: f.face * RC.rnd(12, 15), d: last ? { kx: 9, ky: -6, launch: true } : { kx: 1, stun: 9 } }); G.shake(2, 4); yield 4; }
      f.gun = false; yield 16;
    },
    *fatality(f, o, G) { // tiro na testa e vários no corpo
      P.fatalSetup(f, o, G); yield 24; f.gun = true; f.anim = 'shoot'; yield 24; o.vis = { mode: 'riddled', holes: [] };
      A.play('shot'); G.shake(8, 10); G.flash('#fff', 3, 0.6); o.vis.holes.push([5, -62]); P.gore(o.x + o.face * 2, o.y - 62, 40, -f.face, 5); o.x += f.face * 3; yield 40;
      for (let i = 0; i < 7; i++) { A.play('shot'); G.shake(4, 6); o.vis.holes.push([RC.rnd(-5, 5) | 0, -RC.rnd(22, 50) | 0]); P.gore(o.x, o.y - RC.rnd(22, 50), 10, -f.face, 3); o.x += f.face * RC.rnd(0, 1.5); FX.add({ x: f.x + f.face * 10, y: f.y - 46, vx: -f.face, vy: -2, g: 0.3, life: 30, c: '#d4a82b', s: 2 }); yield 14; }
      f.gun = false; o.state = 'ko'; o.alive = false; o.downed = true; o.anim = 'down'; f.anim = 'taunt'; yield 40; yield* P.resenhatality(G);
    },
    form: {
      *special(f, o, G) { // legião de ratos
        f.anim = 'raise'; G.say('LEGIAO DE RATOS!', '#9aa0b4', 60); A.play('shout'); yield 16;
        for (let i = 0; i < 16; i++) {
          const dir = f.face; const sp = RC.rnd(4.5, 7);
          G.ent({ owner: f, x: f.x - dir * 20, y: GY - 8, vx: dir * sp, w: 24, h: 14, dmg: 24, life: 120, d: { kx: 2.5, stun: 14 }, onHit(e) { FX.burst(e.x, e.y, 6, ['#8a8b96', '#e7a3b6'], 2, { life: 14 }); }, draw(c, e) { D.rat(c, e.x, e.y + 8, Math.sign(e.vx) || 1, e.t, 1.1); } });
          yield 4;
        }
        yield 24;
      }
    }
  };
})();
