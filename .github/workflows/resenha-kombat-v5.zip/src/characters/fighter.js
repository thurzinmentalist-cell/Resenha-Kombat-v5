// Classe base do lutador: estados, física, golpes (do JSON), bloqueio, scripts de especial/ultimate/fatality
(function () {
  const RC = window.RC, GY = RC.GY;
  RC.Chars = RC.Chars || {}; RC.Fusions = RC.Fusions || {};

  class Fighter {
    constructor(G, team, id, o = {}) {
      this.G = G; this.team = team; this.id = id; this.baseId = o.baseId || id; this.fusionId = o.fusionId || null;
      this.data = RC.DATA.characters[this.baseId];
      this.def = this.fusionId ? RC.Fusions[this.fusionId] : RC.Chars[this.baseId];
      this.maxhp = o.hp || this.data.stats.hp; this.hp = this.maxhp;
      this.name = o.name || this.data.name; this.color = this.data.color; this.clock = 0; this.scale = 1; this.wide = 1;
      this.init(240, 1);
    }
    init(x, face) {
      Object.assign(this, { x, y: GY, vx: 0, vy: 0, face, state: 'idle', t: 0, anim: 'idle', move: null, mk: null, hasHit: false, stun: 0, gen: null, wait: 0, armor: false, sInv: false, noGrav: false, invuln: 0, form: null, formT: 0, pow: 1, spd: 1, buff: 1, buffT: 0, vis: null, comboN: 0, cd: { aux: 0 }, mark: null, ext: 0, flash: 0, alive: true, downed: false, guard: null, gun: false, auraCol: null, frozen: false, frozenHits: 0, ghost: false, onCancel: null });
      this.hp = Math.min(this.hp, this.maxhp);
    }
    get opp() { return this.G.activeOf(1 - this.team.idx); }
    get ctrl() { return this.team.ctrl; }
    get dmgMul() { return this.pow * this.buff; }
    get grounded() { return this.y >= GY - 0.5; }
    refreshLook() { const L = RC.Sprites.look(this); this.scale = L.scale; this.wide = L.wide >= 1.3 ? 1.2 : 1; }

    // ------------ ciclo ------------
    update() {
      this.clock++; if (this.clock % 12 === 1) this.refreshLook();
      if (this.flash > 0) this.flash--; if (this.invuln > 0) this.invuln--;
      for (const k in this.cd) if (this.cd[k] > 0) this.cd[k]--;
      if (this.formT > 0 && --this.formT === 0) this.endForm();
      if (this.buffT > 0 && --this.buffT === 0) { this.buff = 1; this.auraCol = this.form ? this.auraCol : null; }
      if (this.gen) this.stepScript(); else this.stateUpdate();
      this.physics();
    }
    physics() {
      if (!this.noGrav && (this.y < GY || this.vy < 0)) this.vy += 0.55;
      this.x += this.vx; this.y += this.vy;
      if (this.y >= GY) { this.y = GY; if (this.vy > 0) { this.vy = 0; this.land(); } }
      this.x = RC.clamp(this.x, 14, RC.W - 14);
      if (this.y >= GY && this.state !== 'walk' && !this.gen) this.vx *= (this.state === 'launched' || this.state === 'ko' ? 0.9 : 0.78);
    }
    land() {
      const s = this.state;
      if (s === 'jump') { this.state = 'idle'; this.anim = 'idle'; RC.Audio.play('land'); RC.FX.dust(this.x, GY, 4); }
      else if (s === 'launched') { this.state = 'down'; this.t = 0; this.anim = 'down'; this.vx *= 0.5; RC.Cam.shake(3, 8); RC.FX.dust(this.x, GY, 8); RC.Audio.play('land'); }
      else if (s === 'ko') { this.downed = true; this.anim = 'down'; this.vx *= 0.4; RC.Cam.shake(4, 10); RC.FX.dust(this.x, GY, 8); }
      else if (s === 'attack' && this.move && this.mk[0] === 'a') { this.endAttack(); }
    }
    threat() {
      const o = this.opp; if (!o) return false;
      if (Math.abs(o.x - this.x) < 130 && (o.state === 'attack' || (o.gen && !o.noThreat))) return true;
      return this.G.ents.some(e => e.dmg && e.owner && e.owner.team !== this.team && Math.abs(e.x - this.x) < 90);
    }
    stateUpdate() {
      const G = this.G, o = this.opp, c = this.ctrl, p = c.pressed, h = c.held, lock = G.noInput;
      switch (this.state) {
        case 'idle': case 'walk': case 'crouch': case 'block': {
          if (o && !lock) this.face = o.x >= this.x ? 1 : -1;
          if (this.tryActions(p, h, false)) return;
          const fwd = this.face > 0 ? 'r' : 'l', back = this.face > 0 ? 'l' : 'r';
          if (lock) { this.state = 'idle'; this.anim = 'idle'; this.vx = 0; return; }
          if (h.u) { this.jump(h, fwd, back); return; }
          let st = 'idle', an = 'idle', vx = 0;
          if (h.d) { st = 'crouch'; an = 'crouch'; if (h[back] && this.threat()) an = 'cblock'; }
          else if (h[fwd] || h[back]) {
            if (h[back] && !h[fwd] && this.threat()) { st = 'block'; an = 'block'; }
            else { st = 'walk'; an = 'walk'; const dir = h[fwd] && !h[back] ? 1 : -1; vx = dir * this.face * Math.min(5.5, this.data.stats.walk * this.spd) * (dir < 0 ? 0.75 : 1); this.walkDir = dir; }
          }
          this.state = st; this.anim = an; this.vx = vx; break;
        }
        case 'jump': this.anim = 'jump'; if (!lock) { if (p.lp || p.hp) this.startMove('alp'); else if (p.lk || p.hk) this.startMove('alk'); } break;
        case 'attack': this.updateAttack(p); break;
        case 'hit': this.anim = 'hit'; if (--this.stun <= 0) { this.comboN = 0; if (this.dizzyAfter) { this.state = 'dizzy'; this.stun = this.dizzyAfter; this.dizzyAfter = 0; } else this.state = 'idle'; } break;
        case 'blockstun': this.anim = this.ctrl.held.d ? 'cblock' : 'block'; if (--this.stun <= 0) this.state = 'idle'; break;
        case 'launched': this.anim = 'hit'; break;
        case 'down': this.t++; this.anim = 'down'; if (this.alive && this.t > 42) { this.state = 'idle'; this.anim = 'idle'; this.invuln = 20; this.comboN = 0; if (this.dizzyAfter) { this.state = 'dizzy'; this.stun = this.dizzyAfter; this.dizzyAfter = 0; this.invuln = 0; } } break;
        case 'ko': this.anim = this.downed ? 'down' : 'hit'; break;
        case 'dizzy': this.anim = 'dizzy'; this.vx = 0; if (--this.stun <= 0) { this.state = 'idle'; this.comboN = 0; } break;
        case 'win': this.anim = this.anim === 'win' || this.anim === 'dance' ? this.anim : 'win'; this.vx = 0; break;
        case 'kneel': this.anim = 'kneel'; this.vx = 0; break;
        case 'fatal': this.vx = 0; break;
        case 'script': break;
      }
    }
    jump(h, fwd, back) {
      this.vy = -this.data.stats.jump; const dir = h[fwd] ? 1 : h[back] ? -1 : 0;
      this.vx = dir * this.face * Math.min(4.5, this.data.stats.walk * 1.35 * Math.min(this.spd, 1.6)); this.state = 'jump'; this.anim = 'jump'; RC.Audio.play('jump');
    }
    pickSpecial(down) {
      const d = this.def, fd = this.form && d.form; let fn = null;
      if (down) fn = (fd && fd.special2) || d.special2 || null;
      return fn || (fd && fd.special) || d.special;
    }
    tryActions(p, h, air) {
      const G = this.G, T = this.team, d = this.def; if (G.noInput) return false;
      if (!air) {
        if (p.transform && T.meter >= 300 && !this.form && !this.fusionId && d.form && !G.training0) { T.meter -= 300; this.run(RC.transformScript, { armor: true, inv: true }); return true; }
        if (p.swap && G.trySwap(T)) return true;
        if (p.fusion && G.tryFusion(T)) return true;
        if (p.ultimate && T.meter >= 300) { const fn = (this.form && d.form && d.form.ultimate) || d.ultimate; if (fn) { T.meter -= 300; this.run(fn, { armor: true, inv: true }); return true; } }
        if (p.special && T.meter >= 100) { const fn = this.pickSpecial(h.d); if (fn) { T.meter -= 100; this.run(fn, { armor: !!(this.form && this.fusionId) }); return true; } }
        if (p.aux && d.aux && this.cd.aux <= 0) { d.aux(this, this.opp, G); return true; }
        if (p.grab) { this.startMove('grab'); return true; }
        const cr = h.d;
        if (p.lp) { this.startMove(cr ? 'clp' : 'lp'); return true; } if (p.hp) { this.startMove(cr ? 'chp' : 'hp'); return true; }
        if (p.lk) { this.startMove(cr ? 'clk' : 'lk'); return true; } if (p.hk) { this.startMove(cr ? 'chk' : 'hk'); return true; }
      }
      return false;
    }
    startMove(key) {
      const m = this.data.moves[key]; if (!m) return;
      this.move = m; this.mk = key; this.state = 'attack'; this.t = 0; this.hasHit = false; this.anim = key; this.ext = 0;
      if (this.grounded) this.vx = 0; RC.Audio.play('whoosh');
    }
    updateAttack(p) {
      const m = this.move; if (!m) { this.endAttack(); return; }
      const su = m.startup, ac = m.active, tot = su + ac + m.recovery; this.t += this.spd > 1 ? 1.5 : 1;
      this.ext = this.t < su ? this.t / su * 0.35 : this.t < su + ac ? 1 : Math.max(0, 1 - (this.t - su - ac) / m.recovery);
      if (this.mk === 'hp' && this.t < su) this.vx = this.face * 0.8;
      if (this.hasHit && this.t >= su && !this.G.noInput) {
        const g = this.grounded;
        if (g && p.special && this.team.meter >= 100) { const fn = this.pickSpecial(this.ctrl.held.d); if (fn) { this.team.meter -= 100; this.run(fn, {}); return; } }
        if (p.lp) this.startMove(g ? (this.ctrl.held.d ? 'clp' : 'lp') : 'alp'); else if (p.lk) this.startMove(g ? (this.ctrl.held.d ? 'clk' : 'lk') : 'alk');
        else if (p.hp && this.t >= su + ac - 1) this.startMove(g ? (this.ctrl.held.d ? 'chp' : 'hp') : 'alp'); else if (p.hk && this.t >= su + ac - 1) this.startMove(g ? (this.ctrl.held.d ? 'chk' : 'hk') : 'alk');
      }
      if (this.t >= tot) this.endAttack();
    }
    endAttack() { this.move = null; this.vx = 0; this.state = this.grounded ? 'idle' : 'jump'; this.anim = this.grounded ? 'idle' : 'jump'; this.ext = 0; }
    isBlocking(att, type) {
      if (!this.grounded || this.G.noInput) return false;
      const s = this.state; if (!(s === 'idle' || s === 'walk' || s === 'crouch' || s === 'block' || s === 'blockstun')) return false;
      const h = this.ctrl.held; if (!h[this.x > att.x ? 'r' : 'l']) return false;
      if (type === 'low') return !!h.d; if (type === 'overhead') return !h.d; return true;
    }
    // reação ao golpe (chamada por G.hit)
    react(att, d) {
      if (this.armor && !d.launch) return;
      this.cancelScript();
      const air = !this.grounded, kx = d.kx != null ? d.kx : 2, ky = d.ky || 0;
      if (this.hp <= 0) { this.die(att, d); return; }
      this.move = null;
      const dirx = d.dir || att.face;
      if (ky || air || d.launch) { this.state = 'launched'; this.vy = ky || (air ? -3.5 : -4.5); this.vx = dirx * kx; this.y = Math.min(this.y, GY - 1); }
      else { this.state = 'hit'; this.stun = d.stun || 14; this.vx = dirx * kx; }
      this.anim = 'hit';
      if (d.dizzy) { this.dizzyAfter = d.dizzy; }
    }
    die(att, d) {
      this.hp = 0; this.alive = false; this.state = 'ko'; this.vy = -7; this.vx = (att ? att.face : 1) * 4; this.y = Math.min(this.y, GY - 1); this.anim = 'hit'; this.cancelScript(); this.move = null; this.endForm(true);
      RC.Audio.play('ko'); RC.Cam.shake(6, 18);
    }
    // ------------ scripts ------------
    run(fn, o = {}) {
      this.cancelScript(); this.state = 'script'; this.move = null; this.gen = fn(this, this.opp, this.G); this.wait = 0;
      this.armor = !!o.armor; this.sInv = !!o.inv; this.noGrav = false; this.vx = 0; this.anim = 'cast'; this.ext = 0; this.stepScript();
    }
    stepScript() {
      if (this.wait > 0) { this.wait--; return; }
      let r; try { r = this.gen.next(); } catch (e) { console.error('script', this.id, e); this.endScript(); return; }
      if (!this.gen) return;
      if (r.done) this.endScript(); else this.wait = Math.max(0, (r.value | 0) - 1);
    }
    endScript() {
      this.gen = null; this.armor = false; this.sInv = false; this.noGrav = false; this.gun = false; this.guard = null; this.onCancel = null; this.ext = 0;
      if (this.state === 'script') { this.state = this.grounded ? 'idle' : 'jump'; this.anim = this.grounded ? 'idle' : 'jump'; }
    }
    cancelScript() {
      if (!this.gen) return; const cb = this.onCancel; this.gen = null; this.armor = false; this.sInv = false; this.noGrav = false; this.gun = false; this.guard = null; this.onCancel = null; if (cb) cb(this);
    }
    endForm(silent) {
      if (!this.form && !this.fusionId) { return; }
      if (this.form) { this.form = null; this.pow = 1; this.spd = 1; this.auraCol = null; this.formT = 0; this.refreshLook(); if (!silent) { RC.FX.ring(this.x, this.y - 30, '#fff', 50); RC.Audio.play('select'); } }
    }
  }
  RC.Fighter = Fighter;

  // transformação genérica (cutscene curta + aura + buff de atributo)
  RC.transformScript = function* (f, o, G) {
    const fd = RC.DATA.transformations[f.baseId];
    G.cutscene(f, 'TRANSFORMACAO', 96, fd.aura, fd.name, 'transform'); f.anim = 'raise'; yield 2;
    RC.Audio.play('transform'); G.flash(fd.aura, 14, 0.9); G.shake(8, 50); RC.FX.ring(f.x, f.y - 30, fd.aura, 90, 30);
    f.form = f.baseId; f.formT = fd.dur * 60; f.pow = fd.stat === 'pow' ? 3 : 1; f.spd = fd.stat === 'spd' ? 3 : 1; f.auraCol = fd.aura; f.refreshLook();
    if (f.baseId === 'vitin') G.say('FORMA CRIANCA!', fd.aura, 70); else G.say(fd.name.toUpperCase() + '!', fd.aura, 70);
    for (let i = 0; i < 24; i++) RC.FX.add({ x: f.x + RC.rnd(-14, 14), y: f.y - RC.rnd(0, 60), vx: RC.rnd(-0.5, 0.5), vy: RC.rnd(-3, -1), life: 40, c: fd.aura, s: 2 });
    yield 40;
  };
})();
