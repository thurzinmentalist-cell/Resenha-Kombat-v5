// Biblioteca de poderes reutilizáveis (usada por todos os lutadores e fusões)
(function () {
  const RC = window.RC, GY = RC.GY, D = RC.Draw, S = RC.Sprites, FX = RC.FX, A = RC.Audio;
  const P = RC.P = {};

  P.ballDraw = (c1, c2 = '#fff') => (c, e) => {
    const r = Math.max(e.w, e.h) / 2; D.orb(c, e.x, e.y, r, c1, c2, e.t);
    if (e.t % 2 === 0) FX.add({ x: e.x - (e.vx || 0) * 2, y: e.y + RC.rnd(-r, r) * 0.6, vx: -(e.vx || 0) * 0.15, vy: RC.rnd(-0.3, 0.3), life: 14, c: e.t % 4 ? c1 : c2, s: 2 });
  };
  // imagens-fantasma (rastro de velocidade / teleporte)
  P.afterimage = (G, f, life = 14, col) => {
    const snap = Object.assign({}, f, { vis: f.vis, guard: null, flash: 0, auraCol: null });
    G.ent({ owner: f, x: f.x, y: f.y, dmg: 0, life, always: true, draw(c, e) { c.save(); c.globalAlpha = 0.55 * e.life / life; c.globalCompositeOperation = 'lighter'; S.drawFighter(c, snap); if (col) { c.globalAlpha = 0.25 * e.life / life; c.fillStyle = col; c.fillRect(snap.x - 18, snap.y - 76, 36, 76); } c.restore(); } });
  };
  // onda de choque
  P.shock = (x, y, col = '#fff', r = 40) => FX.shock(x, y, col, r);
  // projétil genérico
  P.proj = (G, f, o) => G.ent(Object.assign({ owner: f, x: f.x + f.face * 22, y: f.y - 44, vx: f.face * 5, vy: 0, w: 14, h: 14, dmg: 60, life: 150, d: { kx: 3, stun: 18 }, draw: P.ballDraw(o.col || '#ffe14a', o.col2 || '#fff') }, o));
  // feixe horizontal que segue o dono
  P.beam = (G, f, o) => {
    const len = o.len || 520, y = o.y != null ? o.y : f.y - 46, e = G.ent(Object.assign({
      owner: f, x: f.x, y, w: len, h: o.h || 22, dmg: 20, every: 6, pierce: true, life: 60, d: { kx: 1, stun: 9, type: 'unblock', noScale: true }, always: false,
      update(e) { const fy = o.follow === false ? y : f.y - (f.grounded ? 46 : 46); e.x = f.x + f.face * (len / 2 + 14); e.w = len; e.y = o.y != null && !o.follow ? o.y : fy; if (RC.frame % 3 === 0) { FX.spark(f.x + f.face * (30 + RC.rnd(0, 400)), e.y + RC.rnd(-8, 8), o.c1 || '#fff', 2); } },
      draw(c, e) { const x0 = f.face > 0 ? f.x + 14 : f.x - 14 - len; D.beam(c, x0, e.y, len, e.h * (e.life < 8 ? e.life / 8 : 1), o.c1 || '#ffe14a', o.c2 || '#fff', e.t); D.orb(c, f.x + f.face * 18, e.y, e.h * 0.8, o.c1 || '#ffe14a', o.c2 || '#fff', e.t); }
    }, o));
    A.play('beam'); return e;
  };
  // movimentos de script
  P.dashTo = function* (f, o, sp = 6, stop = 34, max = 40) {
    f.anim = 'run'; f.face = o.x >= f.x ? 1 : -1;
    for (let i = 0; i < max && Math.abs(o.x - f.x) > stop; i++) { f.vx = f.face * sp; yield 1; }
    f.vx = 0;
  };
  P.tp = (f, x, col = '#fff') => { FX.burst(f.x, f.y - 30, 14, [col, '#fff'], 3, { g: 0, life: 14 }); FX.ring(f.x, f.y - 30, col, 30, 12); f.x = RC.clamp(x, 20, RC.W - 20); FX.burst(f.x, f.y - 30, 14, [col, '#fff'], 3, { g: 0, life: 14 }); FX.ring(f.x, f.y - 30, col, 30, 12); A.play('whoosh'); };
  P.behind = (f, o, d = 32) => { const x = o.x - o.face * d; return (x < 24 || x > RC.W - 24) ? o.x + o.face * d : x; };
  P.hit = (f, d) => f.G.hit(f, f.opp, d);
  P.face = f => { const o = f.opp; if (o) f.face = o.x >= f.x ? 1 : -1; };
  P.gore = (x, y, n = 24, dir = 1, pw = 4) => { FX.blood(x, y, n, dir, pw); A.play('blood'); };
  P.shout = (G, text, col = '#fff') => { G.say(text, col, 70); A.play('shout'); };
  // prende o oponente em pose de joelhos para o fatality
  P.fatalSetup = (f, o, G) => {
    o.cancelScript(); o.state = 'fatal'; o.anim = 'kneel'; o.vx = 0; o.vy = 0; o.y = GY; o.invuln = 99999; o.alive = true; o.vis = null; o.move = null;
    f.face = o.x >= f.x ? 1 : -1; o.face = -f.face;
    if (Math.abs(o.x - f.x) > 70) P.tp(f, o.x - f.face * 50);
  };
  // letreiro final
  P.resenhatality = function* (G) { G.bigText('RESENHATALITY', '#d8142f'); A.play('finish'); G.shake(8, 40); yield 120; };
  // pessoa que corre até o oponente, ataca N vezes e some
  P.runner = (G, f, o, draw, opt) => {
    const dir = (opt.fromX != null ? (o.x > opt.fromX ? 1 : -1) : f.face);
    return G.ent(Object.assign({
      owner: f, x: opt.fromX != null ? opt.fromX : f.x - f.face * 20, y: GY, w: 26, h: 54, vx: 0, dmg: 0, life: 260, hitsLeft: opt.hits || 2, nextHit: 0, ga: 0,
      update(e) {
        const v = f.opp; if (!v) { e.life = 0; return; } const dx = v.x - e.x, face = dx >= 0 ? 1 : -1; e.face = face;
        if (e.hitsLeft <= 0) { e.vx = face * -2; e.life = Math.min(e.life, 20); return; }
        if (Math.abs(dx) > 26) { e.vx = face * (opt.sp || 3.4); e.run = true; }
        else { e.vx = 0; e.run = false; if (e.t >= e.nextHit) { e.nextHit = e.t + (opt.gap || 20); e.hitsLeft--; e.atk = 8; const r = G.hit(f, v, Object.assign({ dmg: opt.dmg || 40, kx: 2.5, stun: 16 }, opt.d || {}, { launch: e.hitsLeft === 0 && !!opt.launchLast })); FX.spark(v.x - face * 8, v.y - 40, opt.col || '#fff'); } }
        if (e.atk > 0) e.atk--;
      },
      draw(c, e) { if (opt.ghost && e.run) for (let k = 2; k >= 1; k--) { c.globalAlpha = 0.1 * (3 - k); draw(c, e.x - (e.face || 1) * k * 14, e.y, e.face || 1, e.t - k, e.run, 0); } c.globalAlpha = 1;
        draw(c, e.x + (e.atk > 0 ? e.face * 6 : 0), e.y, e.face || 1, e.t, e.run, e.atk); }
    }, opt.ent || {}));
  };
  // feixe com origem fixa (ajudantes)
  P.beamAt = (G, f, sx, y, o) => {
    const dir = o.dir || f.face, len = o.len || 520;
    return G.ent(Object.assign({ owner: f, x: sx + dir * len / 2, y, w: len, h: o.h || 20, dmg: 12, every: 6, pierce: true, life: 60, d: { kx: 1, stun: 9, type: 'unblock', noScale: true },
      draw(c, e) { const x0 = dir > 0 ? sx : sx - len; D.beam(c, x0, e.y, len, e.h * (e.life < 8 ? e.life / 8 : 1), o.c1 || '#ffe14a', o.c2 || '#fff', e.t); D.orb(c, sx, e.y, e.h * 0.8, o.c1 || '#ffe14a', o.c2 || '#fff', e.t); } }, o));
  };
  P.homing = (e, sp = 5, k = 0.12) => { const v = e.owner.opp; if (!v) return; const dx = v.x - e.x, dy = v.y - 40 - e.y, d = Math.hypot(dx, dy) || 1; e.vx += (dx / d * sp - e.vx) * k; e.vy += (dy / d * sp - e.vy) * k; };
  P.deathFlash = (G, col = '#fff') => { G.flash(col, 6, 0.8); };
})();
