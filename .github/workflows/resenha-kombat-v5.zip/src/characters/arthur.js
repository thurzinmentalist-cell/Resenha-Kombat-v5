// ARTHUR: invocador gótico
(function () {
  const RC = window.RC, P = RC.P, FX = RC.FX, A = RC.Audio, D = RC.Draw, GY = RC.GY;
  RC.Chars.arthur = {
    cmd: ['F', 'F', 'D', 'hp'],
    *special(f, o, G) { // duas mulheres góticas
      f.anim = 'raise'; P.face(f); yield 10; A.play('special');
      for (const fx of [f.x - f.face * 26, o.x + f.face * 110]) { const sx = RC.clamp(fx, 20, 460); FX.burst(sx, GY - 30, 18, ['#9a4dff', '#d9b8ff', '#111', '#fff'], 3.5, { g: -0.02, life: 20 }); FX.shock(sx, GY - 4, '#9a4dff', 34);
        G.ent({ owner: f, x: sx, y: GY, dmg: 0, life: 36, always: true, draw(c, e) { const k = Math.min(1, e.t / 8) * Math.min(1, e.life / 12), rr = 28 * k;
          c.save(); c.translate(e.x, e.y); c.globalAlpha = 0.85 * k; c.strokeStyle = '#9a4dff'; c.lineWidth = 2; c.beginPath(); c.ellipse(0, 0, rr, rr * 0.28, 0, 0, 6.283); c.stroke(); c.strokeStyle = '#d9b8ff'; c.lineWidth = 1; c.beginPath(); c.ellipse(0, 0, rr * 0.66, rr * 0.18, 0, 0, 6.283); c.stroke();
          for (let i = 0; i < 8; i++) { const a = i * 0.785 + e.t * 0.1; c.fillStyle = i % 2 ? '#fff' : '#9a4dff'; c.fillRect(Math.round(Math.cos(a) * rr), Math.round(Math.sin(a) * rr * 0.28) - 1, 3, 3); }
          c.globalAlpha = 0.3 * k; c.fillStyle = '#9a4dff'; c.fillRect(-rr * 0.6, -60 * k, rr * 1.2, 60 * k); c.globalAlpha = 1;
          for (let i = 0; i < 3; i++) D.bat(c, Math.sin(e.t * 0.2 + i * 2.1) * 20, -10 - ((e.t * 2 + i * 22) % 60), 0.9, e.t + i * 3, i % 2 ? 1 : -1);
          c.restore(); } });
        P.runner(G, f, o, D.goth, { fromX: sx, hits: 2, dmg: 46, sp: 4.2, col: '#b36bff', gap: 18, ghost: true }); yield 6; }
      f.anim = 'cast'; yield 40;
    },
    *ultimate(f, o, G) { // raio triplo
      G.cutscene(f, 'RAIO TRIPLO', 104, '#2fd06b', 'ARTHUR'); f.anim = 'raise'; yield 2; A.play('ultimate');
      const sx1 = f.x - f.face * 30, sx2 = f.x - f.face * 60;
      for (const [sx, fn] of [[sx1, D.sponge], [sx2, D.suited]]) {
        FX.burst(sx, GY - 30, 16, ['#fff', '#2fd06b', '#ffe14a'], 3, { g: 0, life: 16 });
        G.ent({ owner: f, x: sx, y: GY, dmg: 0, life: 150, always: true, draw(c, e) { fn(c, e.x, e.y, f.face, e.t); } });
      }
      f.anim = 'cast'; yield 44; G.shake(10, 70); G.flash('#ffffff', 5, 0.7);
      const y = f.y - 46;
      P.beamAt(G, f, f.x + f.face * 14, y - 10, { h: 26, c1: '#8a3ff0', c2: '#e0c8ff', life: 66, dmg: 14 });
      P.beamAt(G, f, sx1 + f.face * 14, y + 8, { h: 24, c1: '#ffe14a', c2: '#fff', life: 66, dmg: 14 });
      const last = P.beamAt(G, f, sx2 + f.face * 14, y + 26, { h: 24, c1: '#2fd06b', c2: '#e8ffe8', life: 66, dmg: 14 });
      last.update = e => { if (e.life < 7) e.d = { kx: 9, ky: -6, launch: true, type: 'unblock', noScale: true }; };
      A.play('beam'); yield 70;
    },
    *fatality(f, o, G) { // arranca o coração
      P.fatalSetup(f, o, G); yield 24; f.face = o.x >= f.x ? 1 : -1; P.tp(f, o.x - f.face * 22, '#600'); yield 10;
      f.anim = 'grab'; f.ext = 1; A.play('blood'); G.shake(8, 14); P.gore(o.x, o.y - 40, 30, f.face, 4); o.vis = { mode: 'riddled', holes: [[3, -40]] }; yield 30;
      f.anim = 'raise'; let beat = 0;
      const heart = G.ent({ owner: f, x: f.x + f.face * 8, y: f.y - 70, dmg: 0, life: 400, always: true, draw(c, e) { const s = 2.4 + Math.sin(e.t * 0.5) * 0.35; D.heart(c, e.x, e.y, s, '#c8102e'); if (e.t % 8 === 0) FX.blood(e.x, e.y + 8, 2, 0, 1); } });
      A.play('bell'); yield 70; heart.life = 0; f.anim = 'grab';
      P.gore(f.x + f.face * 8, f.y - 70, 70, f.face, 5); A.play('boom'); G.flash('#c8102e', 8, 0.8); G.shake(12, 30); yield 40;
      o.state = 'ko'; o.alive = false; o.downed = true; o.anim = 'down'; f.anim = 'taunt'; yield 40;
      yield* P.resenhatality(G);
    },
    form: {
      *special(f, o, G) { // COMBO RELAMPAGO: teleporta no inimigo, combo de socos e KAMEHAMEHA na cara
        P.face(f); f.anim = 'cast'; G.say('TELEPORTE RELAMPAGO!', '#2fd06b', 50); A.play('special');
        for (let i = 0; i < 4; i++) { P.afterimage(G, f, 16, '#2fd06b'); FX.burst(f.x, f.y - 30, 6, ['#2fd06b', '#fff'], 3, { g: 0, life: 14 }); yield 2; }
        f.vis = { mode: 'hidden' }; P.shock(f.x, f.y - 34, '#2fd06b', 44); yield 8; f.vis = null;
        let v = f.opp; if (!v || !v.alive) return; let fc = v.x >= f.x ? 1 : -1, tx = v.x - fc * 34; if (tx < 26 || tx > RC.W - 26) { tx = v.x + fc * 34; fc = -fc; }
        f.face = fc; P.tp(f, tx, '#2fd06b'); f.face = fc; P.shock(f.x, f.y - 34, '#2fd06b', 50); P.afterimage(G, f, 10, '#2fd06b'); yield 5;
        const hold = () => { const w = f.opp; if (w && w.alive && w.state === 'hit') { w.stun = Math.max(w.stun, 6); w.vx = 0; } };
        G.say('SOCOS DA RESENHA!', '#ffe14a', 50); A.play('shout');
        for (let i = 0; i < 14; i++) {
          v = f.opp; if (!v || !v.alive) break; P.face(f); f.anim = i % 2 ? 'hp' : 'lp'; f.ext = 1; v.vx = 0;
          G.hit(f, v, { dmg: 4, kx: 0.3, stun: 9, type: 'unblock', noScale: true });
          FX.spark(v.x - f.face * 6, v.y - 50 + RC.rnd(-18, 18), i % 2 ? '#2fd06b' : '#ffe14a', 5); FX.add({ x: f.x + f.face * 30, y: f.y - 52 + RC.rnd(-10, 10), vx: f.face * 5, life: 6, c: '#fff', s: 8, kind: 'flash' });
          if (i % 3 === 0) FX.text(f.x + f.face * (30 + RC.rnd(0, 20)), f.y - 80 + RC.rnd(-12, 12), RC.pick(['PA', 'PAH', 'TA', 'ORA']), '#ffe14a', 1, 18); if (i % 4 === 0) A.play('hit');
          yield 4;
        }
        v = f.opp; if (v && v.alive) { f.anim = 'hp'; f.ext = 1; G.hit(f, v, { dmg: 18, kx: 0.6, stun: 60, type: 'unblock', noScale: true }); P.shock(v.x, v.y - 46, '#ffe14a', 46); G.shake(8, 14); A.play('hitH'); }
        yield 8; f.anim = 'cast'; f.ext = 0;
        const ch = G.ent({ owner: f, x: 0, y: 0, dmg: 0, life: 260, always: true, update(e) { e.x = f.x + f.face * 22; e.y = f.y - 52; if (e.t % 2 === 0) { const a = RC.rnd(0, 6.283), d = RC.rnd(26, 46); FX.add({ x: e.x + Math.cos(a) * d, y: e.y + Math.sin(a) * d, vx: -Math.cos(a) * d / 9, vy: -Math.sin(a) * d / 9, life: 9, c: RC.pick(['#2f8bff', '#9fd0ff', '#fff']), s: 2 }); } },
          draw(c, e) { D.orb(c, e.x, e.y, Math.min(15, 3 + e.t * 0.3), '#2f8bff', '#bfe4ff', e.t); } });
        const words = ['KA', 'ME', 'HA', 'ME']; for (let i = 0; i < 4; i++) { FX.text(f.x - f.face * 6, f.y - 96, words[i] + (i === 3 ? '...' : '...'), '#9fd0ff', 2, 24); A.play('select'); for (let k = 0; k < 11; k++) { hold(); yield 1; } }
        G.say('HAAAAAA!', '#bfe4ff', 70); ch.life = 0; G.flash('#bfe4ff', 7, 0.9); G.shake(14, 64); P.shock(f.x + f.face * 24, f.y - 52, '#2f8bff', 70);
        const b = P.beam(G, f, { h: 48, c1: '#2f8bff', c2: '#cfe8ff', life: 62, dmg: 5, every: 5, d: { kx: 1.2, stun: 10, type: 'unblock', noScale: true } });
        const upd = b.update; b.update = e => { upd(e); if (e.life === 6) { e.dmg = 40; e.d = { kx: 11, ky: -6, launch: true, type: 'unblock', noScale: true }; e.cool.clear(); G.flash('#fff', 5, 0.8); } hold(); };
        while (b.life > 0) { f.anim = 'cast'; yield 2; } yield 12;
      },
      *special2(f, o, G) { // SAI FORA, FEMBOY!
        P.face(f); f.anim = 'cast'; G.say('SAI FORA, FEMBOY!', '#2fd06b', 80); A.play('shout'); yield 40;
        P.beam(G, f, { h: 34, c1: '#2fd06b', c2: '#ffe14a', life: 56, dmg: 14, every: 5 }); yield 62;
      },
      *ultimate(f, o, G) { // VAZIO DA RESENHA: bola vermelha + bola azul = bola roxa, lançada no inimigo
        G.cutscene(f, 'ENERGIA VERMELHA E AZUL', 84, '#ff4a5a', 'ARTHUR'); P.face(f); f.anim = 'raise'; yield 2; A.play('ultimate');
        let ph = 0, pt = 0; const oy = () => f.y - 84, SEP = 32;
        const sys = G.ent({ owner: f, x: f.x, y: f.y, dmg: 0, life: 600, always: true, draw(c, e) {
          const y = oy(), T = e.t;
          if (ph === 0) { const r = 3 + Math.min(1, pt / 54) * 12; D.orb(c, f.x - SEP, y, r, '#ff2a3a', '#ffc0c0', T); D.orb(c, f.x + SEP, y, r, '#2a6aff', '#c0d8ff', T); }
          else if (ph === 1) { const k = Math.min(1, pt / 34), sep = SEP * (1 - k * k), r = 15 + k * 4; D.orb(c, f.x - sep, y, r, '#ff2a3a', '#ffc0c0', T); D.orb(c, f.x + sep, y, r, '#2a6aff', '#c0d8ff', T); if (sep > 3) D.bolt(c, f.x - sep, y, f.x + sep, y, '#d36bff', 1); }
          else if (ph === 2) { const r = 22 + Math.sin(T * 0.4) * 2 + Math.min(8, pt * 0.25); D.orb(c, f.x, y, r, '#8a2be2', '#e8c8ff', T); for (let i = 0; i < 3; i++) { const a = RC.rnd(0, 6.283); D.bolt(c, f.x, y, f.x + Math.cos(a) * (r + 18), y + Math.sin(a) * (r + 18), '#c28bff', 1); } }
        } });
        for (; pt < 54; pt++) { // cresce, atraindo energia
          f.anim = 'raise'; if (pt % 2 === 0) for (const [cx, col] of [[f.x - SEP, '#ff6a6a'], [f.x + SEP, '#6aa8ff']]) { const a = RC.rnd(0, 6.283), d = RC.rnd(28, 50); FX.add({ x: cx + Math.cos(a) * d, y: oy() + Math.sin(a) * d, vx: -Math.cos(a) * d / 10, vy: -Math.sin(a) * d / 10, life: 10, c: col, s: 2 }); }
          if (pt % 18 === 0) { A.play('select'); FX.ring(f.x - SEP, oy(), '#ff2a3a', 30, 14); FX.ring(f.x + SEP, oy(), '#2a6aff', 30, 14); } yield 1;
        }
        ph = 1; pt = 0; G.shake(4, 36);
        for (; pt < 34; pt++) { const k = pt / 34; FX.add({ x: f.x + RC.rnd(-SEP, SEP) * (1 - k), y: oy() + RC.rnd(-20, 20), vx: RC.rnd(-1, 1), vy: RC.rnd(-1, 1), life: 10, c: pt % 2 ? '#ff2a3a' : '#2a6aff', s: 2 }); yield 1; }
        ph = 2; pt = 0; G.flash('#c28bff', 12, 0.95); G.shake(12, 30); P.shock(f.x, oy(), '#a24aff', 80); A.play('boom'); sys.life = 0;
        G.cutscene(f, 'VAZIO DA RESENHA', 100, '#a24aff', 'BOLA ROXA'); yield 2; G.say('VAZIO DA RESENHA!', '#c28bff', 90); A.play('shout');
        const merged = G.ent({ owner: f, x: f.x, y: f.y, dmg: 0, life: 40, always: true, draw(c, e) { D.orb(c, f.x, oy(), 28 + Math.sin(e.t * 0.4) * 2, '#8a2be2', '#e8c8ff', e.t); } });
        f.anim = 'raise'; for (let i = 0; i < 22; i++) { FX.add({ x: f.x + RC.rnd(-44, 44), y: oy() + RC.rnd(-44, 44), vx: 0, vy: 0, life: 12, c: '#c28bff', s: 2, fn: p => { p.vx = (f.x - p.x) * 0.18; p.vy = (oy() - p.y) * 0.18; } }); yield 1; }
        merged.life = 0; f.anim = 'point'; A.play('beam'); G.shake(8, 20); P.shock(f.x + f.face * 20, f.y - 66, '#a24aff', 60);
        let hit = false; const orb = P.proj(G, f, { x: f.x + f.face * 24, y: f.y - 64, vx: f.face * 7.5, w: 60, h: 60, dmg: 40, life: 150, pierce: false, d: { kx: 2, stun: 24, type: 'unblock' },
          onHit(e) { hit = true; }, draw(c, e) { D.orb(c, e.x, e.y, 30, '#8a2be2', '#e8c8ff', e.t); if (e.t % 2 === 0) FX.add({ x: e.x - f.face * 20, y: e.y + RC.rnd(-22, 22), vx: -f.face * 1.5, vy: 0, life: 18, c: RC.pick(['#a24aff', '#e8c8ff', '#fff']), s: 3 }); } });
        for (let i = 0; i < 160 && !hit && orb.life > 0; i++) yield 1;
        if (hit) {
          const v = f.opp; if (v && v.alive) {
            const vx0 = v.x; const vor = G.ent({ owner: f, x: vx0, y: GY - 50, dmg: 0, life: 120, always: true, draw(c, e) {
              const k = Math.min(1, e.t / 12), r = 30 * k; c.globalAlpha = 0.35; D.circ(c, e.x, e.y, r * 1.8, '#3a1a6a'); c.globalAlpha = 0.55; D.circ(c, e.x, e.y, r * 1.3, '#1a0a30'); c.globalAlpha = 1; D.circ(c, e.x, e.y, r * 0.85, '#05020a');
              for (let i = 0; i < 28; i++) { const a = e.t * 0.22 + i * 0.55, rr = r * (0.45 + i / 28 * 1.6); c.fillStyle = i % 3 ? '#b36bff' : '#fff', c.fillRect(Math.round(e.x + Math.cos(a) * rr), Math.round(e.y + Math.sin(a) * rr * 0.85), 2, 2); } } });
            G.say('VAZIO!', '#c28bff', 60); A.play('boom'); G.shake(6, 56);
            for (let i = 0; i < 44; i++) {
              const w = f.opp; if (!w || !w.alive) break; w.vx = 0; if (i % 4 === 0) { G.hit(f, w, { dmg: 5, kx: 0, stun: 10, type: 'unblock', noScale: true }); A.play('hit'); }
              const a = RC.rnd(0, 6.283), d = RC.rnd(50, 90); FX.add({ x: vx0 + Math.cos(a) * d, y: GY - 50 + Math.sin(a) * d * 0.7, vx: -Math.cos(a) * d / 12, vy: -Math.sin(a) * d * 0.7 / 12, life: 12, c: RC.pick(['#a24aff', '#e8c8ff', '#fff']), s: 2 }); yield 1;
            }
            vor.life = 0; G.flash('#fff', 9, 1); G.shake(20, 40); P.shock(vx0, GY - 50, '#a24aff', 110); P.shock(vx0, GY - 50, '#fff', 70); A.play('boom'); const w2 = f.opp; if (w2) G.hit(f, w2, { dmg: 60, kx: 11, ky: -7, launch: true, type: 'unblock', noScale: true });
            FX.burst(vx0, GY - 50, 36, ['#a24aff', '#e8c8ff', '#fff'], 6, { g: 0.05, life: 36 });
          }
        }
        yield 30;
      }
    }
  };
})();
