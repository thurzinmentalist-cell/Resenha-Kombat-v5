// VITIN: escopeta e o "200"
(function () {
  const RC = window.RC, P = RC.P, FX = RC.FX, A = RC.Audio, D = RC.Draw, GY = RC.GY;
  const gunEnt = (G, f) => G.ent({ owner: f, x: f.x, y: f.y, dmg: 0, life: 200, always: true, update(e) { e.x = f.x + f.face * 18; e.y = f.y - 50; }, draw(c, e) { D.gun(c, e.x, e.y, f.face, true); } });
  function blast(G, f, dmg, show) {
    FX.burst(f.x + f.face * 46, f.y - 50, 10, ['#ffe27a', '#fff', '#ff8a1a'], 4, { life: 10 }); A.play('shot'); G.shake(8, 10);
    return G.ent({ owner: f, x: f.x + f.face * 62, y: f.y - 50, w: 70, h: 32, dmg, life: 4, d: { kx: 7, ky: -3, launch: false, stun: 22 }, onHit(e, v) { if (show) FX.text(v.x, v.y - 96, '200', '#ffe14a', 4, 80, { vy: -0.3 }); }, draw(c, e) { c.fillStyle = 'rgba(255,230,120,.6)'; c.fillRect(Math.round(f.face > 0 ? f.x + 36 : f.x - 100), Math.round(f.y - 62), 64, 24); } });
  }
  RC.Chars.vitin = {
    cmd: ['D', 'B', 'F', 'hk'],
    *special(f, o, G) { // escopeta + 200
      f.anim = 'shoot'; P.face(f); const g = gunEnt(G, f); yield 16; blast(G, f, 120, true); f.vx = -f.face * 2; yield 26; g.life = 0;
    },
    *ultimate(f, o, G) { // combo aéreo + raio roxo
      G.cutscene(f, 'COMBO ESTELAR', 104, '#a855f7', 'VITIN'); P.face(f); yield 2; yield* P.dashTo(f, f.opp, 8, 40, 30); P.face(f);
      f.anim = 'chp'; f.ext = 1; let v = f.opp; G.hit(f, v, { dmg: 60, kx: 0.5, ky: -9.5, launch: true, type: 'unblock' }); A.play('hitH'); yield 8;
      f.vy = -9.6; f.anim = 'jump'; f.noGrav = false; f.state = 'script'; yield 12; f.noGrav = true; f.vy = 0;
      for (let i = 0; i < 6; i++) { v = f.opp; if (v.y < GY - 4) { v.vy = -1.2; v.vx = 0; } P.face(f); f.anim = i % 2 ? 'alk' : 'alp'; f.ext = 1; f.x += (v.x - f.face * 30 - f.x) * 0.5; f.y += (v.y - 8 - f.y) * 0.5; G.hit(f, v, { dmg: 26, kx: 0.3, stun: 14, type: 'unblock', noScale: true }); FX.spark(v.x, v.y - 40, '#a855f7'); yield 7; }
      f.anim = 'cast'; yield 6; G.shake(10, 50); A.play('beam');
      const b = P.beam(G, f, { y: f.y - 40, follow: false, h: 34, c1: '#a855f7', c2: '#f0d8ff', life: 44, dmg: 40, every: 6 }); const upd = b.update; b.update = e => { e.y = f.y - 40; upd(e); e.y = f.y - 40; if (e.life < 7) e.d = { kx: 9, ky: -6, launch: true, type: 'unblock', noScale: true }; };
      yield 46; f.noGrav = false; f.vy = 1; yield 20;
    },
    *fatality(f, o, G) { // estoura a cabeça
      P.fatalSetup(f, o, G); yield 24; f.anim = 'shoot'; const g = gunEnt(G, f); yield 34; A.play('shot'); G.shake(14, 20); G.flash('#fff', 4, 0.8);
      o.vis = { mode: 'headless' }; P.gore(o.x, o.y - 58, 90, -f.face, 6); A.play('boom');
      for (let i = 0; i < 24; i++) FX.add({ x: o.x, y: o.y - 58, vx: RC.rnd(-3, 3) - f.face * 0, vy: RC.rnd(-5, -1), g: 0.25, life: 60, c: RC.pick(['#ece6d2', '#e8b890', '#b3001b', '#8d0014']), s: RC.ri(1, 3) });
      yield 30; o.state = 'ko'; o.alive = false; o.downed = true; o.anim = 'down'; g.life = 0; f.anim = 'taunt'; yield 50; yield* P.resenhatality(G);
    },
    form: {
      *special(f, o, G) { // invoca o tio e fazem combo
        f.anim = 'raise'; G.say('TIOOO!', '#ffd84a', 60); A.play('shout'); yield 16; P.face(f);
        const v0 = f.opp, ux = RC.clamp(v0.x + f.face * 60, 20, 460); FX.burst(ux, GY - 30, 16, ['#fff', '#ffd84a'], 3, { g: 0, life: 16 });
        const unc = G.ent({ owner: f, x: ux, y: GY, dmg: 0, life: 300, always: true, atk: 0, draw(c, e) { D.uncle(c, e.x + (e.atk > 0 ? -f.face * 8 : 0), e.y, -f.face, e.t, false); if (e.atk > 0) e.atk--; } });
        yield 14; yield* P.dashTo(f, f.opp, 7, 40, 30); P.face(f);
        const words = ['POW!', 'BAM!', 'BOING!', 'PLOC!', 'ZAS!'];
        for (let i = 0; i < 5; i++) {
          const v = f.opp; if (i % 2) { unc.atk = 8; } else { f.anim = 'lp'; f.ext = 1; }
          G.hit(f, v, { dmg: 28, kx: 1.5, stun: 14, type: 'unblock', noScale: true }); FX.text(v.x + RC.rnd(-14, 14), v.y - 80, RC.pick(words), RC.pick(['#ffd84a', '#ff6a6a', '#6ad8ff']), 2, 36); yield 12;
        }
        const v = f.opp; f.anim = 'hk'; f.ext = 1; unc.atk = 12; G.hit(f, v, { dmg: 90, kx: 9, ky: -6, launch: true, type: 'unblock' }); G.shake(10, 20); yield 24; unc.life = 0; FX.burst(ux, GY - 30, 12, ['#fff', '#ffd84a'], 3, { g: 0, life: 14 });
      }
    }
  };
})();
