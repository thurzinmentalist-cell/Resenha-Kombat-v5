// MATHEUS: terno e amor
(function () {
  const RC = window.RC, P = RC.P, FX = RC.FX, A = RC.Audio, D = RC.Draw, GY = RC.GY;
  const blondeEnt = (G, f, dx, life) => G.ent({ owner: f, x: f.x + f.face * dx, y: GY, dmg: 0, life, always: true, update(e) { e.fc = f.face * -Math.sign(dx); }, draw(c, e) { D.blonde(c, e.x, e.y, -Math.sign(dx) * f.face || 1, e.t); if (e.t % 10 === 0) FX.text(e.x, e.y - 76, '♥', '#ff4d8d', 1, 40, { vx: RC.rnd(-0.3, 0.3) }); } });
  RC.Chars.matheus = {
    cmd: ['B', 'B', 'F', 'hp'],
    *special(f, o, G) { // beijo: força x3
      f.anim = 'cast'; P.face(f); A.play('special'); const b = blondeEnt(G, f, -30, 130); FX.burst(f.x - f.face * 30, GY - 30, 14, ['#ff4d8d', '#fff'], 3, { g: -0.02, life: 20 }); yield 40;
      for (let i = 0; i < 8; i++) FX.text(f.x + RC.rnd(-16, 16), f.y - 70, '♥', '#ff4d8d', 1, 34, { vx: RC.rnd(-0.4, 0.4) });
      f.buff = 3; f.buffT = 360; f.auraCol = '#ff7fa8'; G.say('FORCA X3!', '#ff7fa8', 60); A.play('bell'); G.flash('#ff7fa8', 8, 0.5); yield 40;
    },
    *ultimate(f, o, G) { // Raio do Amor
      G.cutscene(f, 'RAIO DO AMOR', 104, '#ff4d8d', 'MATHEUS'); P.face(f); f.anim = 'cast'; yield 2; A.play('ultimate'); blondeEnt(G, f, -34, 150); yield 40; G.shake(10, 70);
      const b = P.beam(G, f, { h: 44, c1: '#ff4d8d', c2: '#ffd0e0', life: 72, dmg: 20, every: 6 });
      const upd = b.update; b.update = e => { upd(e); if (e.life < 7) e.d = { kx: 9, ky: -6, launch: true, type: 'unblock', noScale: true }; if (e.t % 4 === 0) FX.text(f.x + f.face * RC.rnd(40, 420), f.y - 46 + RC.rnd(-24, 24), '♥', '#ff4d8d', 1, 30); };
      yield 76;
    },
    *fatality(f, o, G) { // corta o pescoço, quebra ossos, entrega à namorada
      P.fatalSetup(f, o, G); yield 24; P.tp(f, o.x - f.face * 28, '#fff'); f.anim = 'hp'; f.ext = 1; yield 8;
      G.ent({ owner: f, x: o.x, y: o.y - 56, dmg: 0, life: 8, always: true, draw(c, e) { c.strokeStyle = '#fff'; c.lineWidth = 2; c.beginPath(); c.moveTo(e.x - 18 * f.face, e.y - 6); c.lineTo(e.x + 18 * f.face, e.y + 6); c.stroke(); } });
      A.play('whoosh'); P.gore(o.x, o.y - 56, 60, f.face, 5); G.shake(8, 14); yield 30;
      f.anim = 'grab'; for (let i = 0; i < 4; i++) { A.play('hit'); G.shake(6, 8); FX.text(o.x + RC.rnd(-14, 14), o.y - RC.rnd(20, 70), 'CRACK!', '#ece6d2', 1, 30); if (i === 1) o.vis = { mode: 'ragdoll', rot: 0 }; yield 20; }
      o.state = 'ko'; o.alive = false; o.downed = true; o.anim = 'broken'; o.vis = null; yield 30;
      f.anim = 'taunt'; const gf = G.ent({ owner: f, x: o.x + (o.x < 240 ? 90 : -90), y: GY, dmg: 0, life: 400, always: true, carry: false,
        update(e) { const dir = Math.sign(o.x - e.x); if (!e.carry) { if (Math.abs(o.x - e.x) > 12) e.x += dir * 2.2; else { e.carry = true; o.vis = { mode: 'hidden' }; } } else e.x += Math.sign(e.x - 240 || 1) * 2.4; e.dir = e.carry ? Math.sign(e.x - 240 || 1) : dir; },
        draw(c, e) { D.blonde(c, e.x, e.y, e.dir || 1, e.t); if (e.carry) { c.save(); c.translate(e.x, e.y - 52); c.rotate(-0.4 * (e.dir || 1)); c.fillStyle = '#0c0a10'; c.fillRect(-5, -26, 11, 36); c.fillStyle = o.data.pal.top || '#444'; c.fillRect(-4, -25, 9, 34); c.restore(); } if (e.t % 12 === 0) FX.text(e.x, e.y - 76, '♥', '#ff4d8d', 1, 40); } });
      yield 110; FX.text(f.x, f.y - 90, 'OBRIGADO, AMOR', '#ff7fa8', 1, 60); yield 60; gf.life = 0; yield* P.resenhatality(G);
    },
    form: {
      *special(f, o, G) { // Esfera da Resenha
        f.anim = 'raise'; G.say('ESFERA DA RESENHA', '#ff7fa8', 80); A.play('special');
        const sx = f.x, sph = { r: 4 };
        const e1 = G.ent({ owner: f, x: 0, y: 0, dmg: 0, life: 300, always: true, update(e) { e.x = f.x + f.face * 4; e.y = f.y - 96; if (e.t % 2 === 0) { const a = RC.rnd(0, 6.28), d = RC.rnd(120, 220); FX.add({ x: e.x + Math.cos(a) * d, y: e.y + Math.sin(a) * d * 0.5, vx: -Math.cos(a) * d / 18, vy: -Math.sin(a) * d * 0.5 / 18, life: 18, c: RC.pick(['#ffd24a', '#6ad8ff', '#ff7fa8', '#fff']), s: 2 }); } sph.r = Math.min(26, 4 + e.t * 0.3); }, draw(c, e) { c.globalAlpha = 0.35; D.circ(c, e.x, e.y, sph.r * 1.5, '#ff7fa8'); c.globalAlpha = 1; D.circ(c, e.x, e.y, sph.r, '#ffd24a'); D.circ(c, e.x, e.y, sph.r * 0.7, '#6ad8ff'); D.circ(c, e.x, e.y, sph.r * 0.4, '#fff'); } });
        for (let i = 0; i < 74; i++) { f.anim = 'raise'; yield 1; } e1.life = 0; f.anim = 'point'; G.flash('#fff', 5, 0.6);
        P.proj(G, f, { x: f.x + f.face * 14, y: f.y - 90, vx: f.face * 6, vy: 1.6, w: 56, h: 56, dmg: 160, life: 160, d: { kx: 10, ky: -6, launch: true }, draw: (c, e) => { c.globalAlpha = 0.35; D.circ(c, e.x, e.y, 42, '#ff7fa8'); c.globalAlpha = 1; D.circ(c, e.x, e.y, 28, '#ffd24a'); D.circ(c, e.x, e.y, 20, '#6ad8ff'); D.circ(c, e.x, e.y, 10, '#fff'); }, update(e) { if (e.y > GY - 28) e.vy = 0; } });
        A.play('beam'); yield 30;
      }
    }
  };
})();
