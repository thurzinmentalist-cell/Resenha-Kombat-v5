// TODDY (o Todão) e seu Guardião
(function () {
  const RC = window.RC, P = RC.P, FX = RC.FX, A = RC.Audio, D = RC.Draw, GY = RC.GY, S = RC.Sprites;
  function* barrage(f, o, G, n, dmg, gap, finalDmg) {
    P.face(f); f.anim = 'point'; if (Math.abs(f.opp.x - f.x) > 90) yield* P.dashTo(f, f.opp, 7, 70, 30);
    f.guard = { pose: 'punch', off: 40, e: 0 }; G.say('PAPAPAPAPAPA!', '#b36bff', 60); A.play('shout');
    for (let i = 0; i < n; i++) {
      const v = f.opp; P.face(f); if (Math.abs(v.x - f.x) > 80) f.vx = f.face * 4; else f.vx = 0;
      if (Math.abs(v.x - f.x) < 115) {
        const last = i === n - 1;
        G.hit(f, v, Object.assign({ dmg, kx: 0.4, stun: 9, type: 'unblock', noScale: true }, last ? { dmg: finalDmg, kx: 9, ky: -6, launch: true } : {}));
        FX.spark(f.x + f.face * 66, f.y - 46 + RC.rnd(-14, 14), '#b36bff', 4); if (i % 3 === 0) A.play('hit');
      }
      yield gap;
    }
    f.vx = 0; f.guard = null; yield 10;
  }
  const orb = (c, x, y, r, t, c1, c2) => {
    c.globalAlpha = 0.3; D.circ(c, x, y, r * 1.6, c2); c.globalAlpha = 1; D.circ(c, x, y, r, c1); D.circ(c, x, y, r * 0.6, c2);
    for (let i = 0; i < 4; i++) { const a = t * 0.3 + i * 1.57; D.circ(c, x + Math.cos(a) * r * 0.9, y + Math.sin(a) * r * 0.9, 2, '#fff'); }
  };
  RC.Chars.toddy = {
    cmd: ['F', 'D', 'F', 'hp'],
    *special(f, o, G) { yield* barrage(f, o, G, 35, 10 * (f.fusionId ? 0.6 : 1), 6, 60); }, // 10 golpes/s por 3,5 s
    *special2(f, o, G) { // Vazio da Resenha
      f.anim = 'cast'; P.face(f); A.play('special');
      const o1 = G.ent({ owner: f, x: 0, y: 0, dmg: 0, life: 300, always: true, update(e) { const k = Math.min(1, e.t / 40); e.x = f.x + f.face * (26 - k * 14); e.y = f.y - 52 - (1 - k) * 10; }, draw(c, e) { const k = Math.min(1, e.t / 40); orb(c, e.x - (1 - k) * 12, e.y, 6 + k * 6, e.t, '#2a6aff', '#9bc2ff'); orb(c, e.x + (1 - k) * 12, e.y, 6 + k * 6, e.t, '#ff2a3a', '#ffa0a8'); if (k >= 1) orb(c, e.x, e.y, 14, e.t, '#8a2be2', '#e0b0ff'); } });
      yield 52; G.flash('#b36bff', 5, 0.7); o1.life = 0; A.play('beam');
      P.proj(G, f, { x: f.x + f.face * 14, y: f.y - 52, vx: f.face * 5, w: 36, h: 36, dmg: 190, life: 160, d: { kx: 9, ky: -5, launch: true }, draw: (c, e) => orb(c, e.x, e.y, 18, e.t, '#8a2be2', '#e0b0ff') });
      yield 30;
    },
    *ultimate(f, o, G) { // Guardião bate no chão
      G.cutscene(f, 'MARTELO DO GUARDIAO', 104, '#8a3ff0', 'TODDY'); P.face(f); f.anim = 'point'; yield 2; A.play('ultimate');
      f.guard = { pose: 'pound', off: 44, e: 0 }; for (let i = 0; i <= 24; i++) { f.guard.e = 0; yield 1; }
      G.shake(5, 20); for (let i = 0; i <= 5; i++) { f.guard.e = i / 5; yield 1; }
      G.shake(16, 40); G.flash('#fff', 4, 0.8); A.play('boom'); FX.dust(f.x + f.face * 60, GY, 16);
      G.ent({ owner: f, x: f.x + f.face * 60, y: GY - 20, vx: f.face * 9, w: 60, h: 44, dmg: 320, life: 70, d: { kx: 10, ky: -8, launch: true, type: 'unblock' }, pierce: false,
        update(e) { if (e.t % 2 === 0) FX.add({ x: e.x + RC.rnd(-20, 20), y: GY - RC.rnd(0, 6), vx: RC.rnd(-1, 1), vy: RC.rnd(-3, -1), g: 0.2, life: 24, c: RC.pick(['#cdbfa5', '#8a3ff0', '#fff']), s: 3 }); },
        draw(c, e) { c.fillStyle = '#8a3ff0'; for (let i = 0; i < 6; i++) { const h = 14 + (i % 3) * 10 - Math.abs(i - 2.5) * 2; c.fillRect(Math.round(e.x - 24 + i * 8), GY - h, 6, h); } c.fillStyle = '#e0b0ff'; c.fillRect(Math.round(e.x - 24), GY - 3, 48, 3); } });
      yield 36; f.guard = null; yield 10;
    },
    *fatality(f, o, G) { // arranca a cabeça, embaixadinhas e explode
      P.fatalSetup(f, o, G); yield 24; P.tp(f, o.x - f.face * 28, '#8a3ff0'); f.anim = 'grab'; f.guard = { pose: 'grab', off: 30, e: 0 }; yield 30;
      A.play('blood'); G.shake(10, 20); f.guard = null; o.vis = { mode: 'headless' }; P.gore(o.x, o.y - 56, 50, f.face, 5);
      const h = { x: o.x, y: o.y - 60, vx: 0, vy: -6 };
      const hent = G.ent({ owner: f, x: h.x, y: h.y, dmg: 0, life: 900, always: true, update(e) { h.vy += 0.32; h.x += h.vx; h.y += h.vy; if (h.y > GY - 8 && h.vy > 0) { h.y = GY - 8; h.vy *= -0.3; } e.x = h.x; e.y = h.y; if (e.t % 4 === 0) FX.blood(h.x, h.y, 1, 0, 1); }, draw(c, e) { D.head(c, o.baseId, h.x, h.y, e.t * 0.15); } });
      for (let i = 0; i < 40; i++) { if (i % 2 === 0) FX.blood(o.x, o.y - 56, 3, RC.pick([-1, 1]), 3); yield 1; }
      o.state = 'ko'; o.alive = false; o.downed = true; o.anim = 'down'; o.vy = 0;
      f.face = h.x >= f.x ? 1 : -1;
      for (let k = 0; k < 4; k++) {
        h.x = f.x + f.face * 24; h.y = f.y - 12; h.vx = 0; h.vy = k < 3 ? -6.2 : -12; f.anim = k % 2 ? 'lk' : 'hk'; f.ext = 1; A.play('hit'); yield 6; f.anim = 'idle'; f.ext = 0; yield k < 3 ? 26 : 36;
      }
      G.flash('#fff', 6, 0.9); G.shake(14, 30); A.play('boom'); P.gore(h.x, h.y, 90, 0, 6); for (let i = 0; i < 20; i++) FX.add({ x: h.x, y: h.y, vx: RC.rnd(-3, 3), vy: RC.rnd(-4, 1), g: 0.2, life: 50, c: RC.pick(['#ece6d2', '#b3001b', '#e8b890']), s: 2 }); hent.life = 0; yield 50;
      yield* P.resenhatality(G);
    },
    form: {
      *special(f, o, G) { // agarrão + lição de 30 golpes em 5 s
        P.face(f); yield* P.dashTo(f, f.opp, 9, 52, 30); P.face(f); f.anim = 'grab'; yield 6; let v = f.opp;
        if (Math.abs(v.x - f.x) > 90) P.tp(f, v.x - f.face * 46, '#8a3ff0');
        const r = G.hit(f, v, { dmg: 20, kx: 0, stun: 12, type: 'unblock', noScale: true }); if (!r) { yield 12; return; }
        G.say('LICAO!', '#b36bff', 60); A.play('shout'); f.guard = { pose: 'punch', off: 40, e: 0 };
        for (let i = 0; i < 30; i++) {
          v = f.opp; if (!v || !v.alive) break; v.vx = 0; if (v.state === 'launched' && v.y < GY) { v.vy = -1; }
          G.hit(f, v, { dmg: 5, kx: 0, stun: 14, type: 'unblock', noScale: true, ...(i === 29 ? { dmg: 40, kx: 10, ky: -6, launch: true } : {}) });
          FX.spark(v.x, v.y - 46 + RC.rnd(-12, 12), '#b36bff', 3); if (i % 2 === 0) FX.text(f.x + f.face * 40, f.y - 90 + RC.rnd(-10, 10), RC.pick(['PA', 'PAH', 'ORA?']), '#e0b0ff', 1, 20); yield 10;
        }
        f.guard = null; yield 12;
      },
      *ultimate(f, o, G) { // para o tempo
        G.cutscene(f, 'RESENHA, PARA O MUNDO!', 110, '#8a3ff0', 'TODDY'); f.anim = 'point'; yield 2;
        G.say('RESENHA, PARA O MUNDO!', '#b36bff', 90); A.play('time'); G.flash('#fff', 10, 1); G.startTimeStop(f, 300); yield 20;
      }
    }
  };
  RC.P.toddyBarrage = barrage;
})();
