// Caixas de colisão (hitbox x hurtbox, AABB)
(function () {
  const RC = window.RC;
  const Col = RC.Col = {};
  Col.hurt = function (f) {
    const h = f.data.hurtboxes, sc = f.scale || 1; let b = h.stand;
    if (f.state === 'down' || f.state === 'ko') b = h.down;
    else if (f.y < RC.GY - 2) b = h.air;
    else if (f.anim === 'crouch' || f.anim === 'cblock' || /^c(lp|hp|lk|hk)$/.test(f.anim)) b = h.crouch;
    return { x: f.x + b.x * sc, y: f.y + b.y * sc, w: b.w * sc * (f.wide || 1), h: b.h * sc };
  };
  Col.hit = function (f) {
    const m = f.move, b = m.box, sc = f.scale || 1;
    return { x: f.face > 0 ? f.x + b.x * sc : f.x - (b.x + b.w) * sc, y: f.y + b.y * sc, w: b.w * sc, h: b.h * sc };
  };
})();
