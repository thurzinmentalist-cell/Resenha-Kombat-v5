// Áudio sintetizado (WebAudio). Para trocar por arquivos: RC.Audio.load('hit','assets/hit.ogg')
(function () {
  const RC = window.RC;
  const A = RC.Audio = { vol: { master: 0.6, music: 0.5, sfx: 0.8 }, ctx: null, buf: {}, cur: null };
  try { const s = JSON.parse(localStorage.getItem('rc_vol') || 'null'); if (s) Object.assign(A.vol, s); } catch (e) { }
  A.save = () => { try { localStorage.setItem('rc_vol', JSON.stringify(A.vol)); } catch (e) { } A.apply(); };
  A.apply = () => { if (!A.ctx) return; A.master.gain.value = A.vol.master; A.mus.gain.value = A.vol.music * 0.5; A.sfx.gain.value = A.vol.sfx; };
  A.resume = () => {
    if (!A.ctx) {
      try {
        A.ctx = new (window.AudioContext || window.webkitAudioContext)();
        A.master = A.ctx.createGain(); A.master.connect(A.ctx.destination);
        A.mus = A.ctx.createGain(); A.mus.connect(A.master); A.sfx = A.ctx.createGain(); A.sfx.connect(A.master);
        A.apply(); if (A.want) A.music(A.want);
      } catch (e) { A.ctx = null; }
    }
    if (A.ctx && A.ctx.state === 'suspended') A.ctx.resume();
  };
  function tone(type, f0, f1, dur, vol, delay = 0, dest) {
    const c = A.ctx, t = c.currentTime + delay, o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g); g.connect(dest || A.sfx); o.start(t); o.stop(t + dur + 0.02);
  }
  let nbuf = null;
  function noise(dur, vol, lo = 0, hi = 20000, delay = 0) {
    const c = A.ctx; if (!nbuf) { nbuf = c.createBuffer(1, c.sampleRate, c.sampleRate); const d = nbuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1; }
    const s = c.createBufferSource(); s.buffer = nbuf; s.loop = true; const g = c.createGain(), t = c.currentTime + delay;
    const f1 = c.createBiquadFilter(); f1.type = 'highpass'; f1.frequency.value = lo; const f2 = c.createBiquadFilter(); f2.type = 'lowpass'; f2.frequency.value = hi;
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    s.connect(f1); f1.connect(f2); f2.connect(g); g.connect(A.sfx); s.start(t); s.stop(t + dur + 0.02);
  }
  A.sounds = {
    hit: () => { noise(.07, .5, 600, 6000); tone('square', 200, 60, .09, .25); },
    hitH: () => { noise(.14, .7, 200, 5000); tone('sawtooth', 140, 40, .18, .35); },
    block: () => { noise(.05, .35, 1500, 9000); tone('triangle', 500, 300, .06, .2); },
    whoosh: () => noise(.12, .18, 800, 3500),
    jump: () => tone('square', 200, 420, .12, .1),
    land: () => noise(.06, .25, 100, 700),
    special: () => { tone('sawtooth', 200, 900, .35, .22); noise(.3, .2, 1000, 8000); },
    ultimate: () => { tone('sawtooth', 80, 700, .9, .3); tone('square', 160, 1400, .9, .15, .1); noise(.8, .3, 400, 9000); },
    beam: () => { tone('sawtooth', 300, 280, .6, .25); noise(.6, .25, 1000, 7000); },
    boom: () => { noise(.7, .8, 40, 900); tone('sine', 90, 25, .7, .6); },
    ko: () => { tone('sawtooth', 400, 60, .8, .4); noise(.5, .5, 100, 3000); },
    select: () => tone('square', 660, 660, .05, .15),
    confirm: () => { tone('square', 523, 523, .07, .18); tone('square', 784, 784, .1, .18, .07); },
    back: () => tone('square', 400, 250, .09, .15),
    bell: () => { tone('sine', 880, 880, .9, .3); tone('sine', 1320, 1320, .6, .15); },
    shout: () => { tone('sawtooth', 220, 180, .5, .35); tone('square', 330, 250, .5, .2); noise(.4, .25, 500, 4000); },
    transform: () => { tone('sawtooth', 100, 1200, 1.1, .3); noise(1, .25, 300, 8000); tone('square', 200, 2000, 1.1, .12); },
    blood: () => { noise(.15, .45, 100, 1500); tone('sine', 120, 50, .15, .3); },
    blip: () => tone('square', 380 + Math.random() * 160, 380, .035, .1),
    shot: () => { noise(.12, .8, 200, 7000); tone('square', 160, 30, .12, .4); },
    tick: () => tone('square', 900, 900, .03, .1),
    finish: () => { tone('sawtooth', 90, 70, 1.2, .45); tone('square', 60, 50, 1.2, .3); },
    chomp: () => { noise(.1, .4, 200, 2500); tone('square', 130, 70, .1, .3); },
    fart: () => { tone('sawtooth', 90, 55, .5, .3); noise(.5, .25, 80, 700); },
    time: () => { tone('sine', 220, 50, 1, .4); tone('sine', 110, 40, 1, .3); }
  };
  A.play = function (n) {
    if (!A.ctx) return;
    const b = A.buf[n];
    if (b) { const s = A.ctx.createBufferSource(); s.buffer = b; s.connect(A.sfx); s.start(); return; }
    const f = A.sounds[n]; if (f) { try { f(); } catch (e) { } }
  };
  A.load = function (name, url) {
    A.resume(); if (!A.ctx) return;
    fetch(url).then(r => r.arrayBuffer()).then(b => A.ctx.decodeAudioData(b)).then(d => { A.buf[name] = d; }).catch(() => { });
  };
  // música em loop sintetizada (substitua com A.load('music_fight', ...) e A.musicFile)
  const N = n => 440 * Math.pow(2, (n - 69) / 12);
  const SONGS = {
    menu: { bpm: 96, bass: [33, 0, 33, 0, 36, 0, 31, 0, 33, 0, 33, 0, 38, 0, 36, 0], lead: [57, 0, 60, 0, 64, 0, 62, 60, 57, 0, 60, 0, 67, 0, 64, 0] },
    fight: { bpm: 138, bass: [28, 28, 0, 28, 31, 0, 28, 0, 26, 26, 0, 26, 29, 0, 33, 31], lead: [52, 0, 55, 52, 0, 59, 0, 55, 50, 0, 53, 50, 0, 57, 55, 0] },
    vs: { bpm: 110, bass: [31, 0, 0, 31, 0, 0, 34, 0, 31, 0, 0, 31, 0, 38, 36, 0], lead: [55, 0, 0, 58, 0, 0, 62, 0, 55, 0, 0, 58, 0, 65, 62, 0] }
  };
  A.music = function (name) {
    A.want = name; if (!A.ctx) return; if (A.cur === name) return; A.cur = name;
    clearInterval(A.timer); if (!name || !SONGS[name]) return;
    const s = SONGS[name]; let step = 0; const ms = 60000 / s.bpm / 2;
    A.timer = setInterval(() => {
      if (!A.ctx || A.ctx.state !== 'running') return;
      const b = s.bass[step % 16], l = s.lead[step % 16];
      if (b) tone('triangle', N(b), N(b), ms / 1000 * 1.6, .45, 0, A.mus);
      if (l) tone('square', N(l), N(l), ms / 1000 * 1.2, .12, 0, A.mus);
      if (step % 4 === 0) { noise(.05, .25, 60, 400); A.ctx && noise(.0001, 0.0001); }
      if (step % 2 === 1) noise(.03, .12, 6000, 12000);
      step++;
    }, ms);
  };
})();
