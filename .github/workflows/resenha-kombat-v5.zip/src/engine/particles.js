// Partículas, sangue pixelado, textos flutuantes
(function () {
  const RC = window.RC;
  const FX = RC.FX = { list: [], stains: [], texts: [] };
  FX.clear = () => { FX.list.length = 0; FX.stains.length = 0; FX.texts.length = 0; };
  FX.add = p => { if (FX.list.length < 500) FX.list.push(Object.assign({ x: 0, y: 0, vx: 0, vy: 0, g: 0, life: 30, max: 30, c: '#fff', s: 2, drag: 1, kind: 'px' }, p, { max: p.life || 30 })); };
  FX.burst = (x, y, n, cols, sp = 3, o = {}) => {
    for (let i = 0; i < n; i++) { const a = Math.random() * 6.283, v = RC.rnd(sp * 0.3, sp); FX.add(Object.assign({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, g: 0.1, life: RC.ri(14, 34), c: RC.pick(cols), s: RC.ri(1, 3) }, o)); }
  };
  FX.blood = (x, y, n, dir = 1, pw = 3) => {
    if (RC.Match && RC.Match.noBlood) return;
    for (let i = 0; i < n; i++) FX.add({ x, y, vx: dir * RC.rnd(0.3, 1) * pw + RC.rnd(-1, 1), vy: RC.rnd(-3.2, 0.5) * pw / 2, g: 0.22, life: RC.ri(30, 70), c: RC.pick(['#b3001b', '#8d0014', '#d8142f', '#640010']), s: RC.ri(1, 3), kind: 'blood' });
  };
  FX.spark = (x, y, col = '#fff', n = 8) => { FX.burst(x, y, n, [col, '#fff', '#ffe27a'], 3.5, { g: 0.05, life: 10 }); FX.add({ x, y, life: 6, kind: 'flash', c: col, s: 12 }); FX.add({ x, y, life: 8, kind: 'ring', c: col, s: 16 }); };
  FX.shock = (x, y, col = '#fff', r = 40) => { FX.add({ x, y, life: 18, kind: 'ring', c: col, s: r }); FX.add({ x, y, life: 11, kind: 'ring', c: '#fff', s: r * 0.6 }); for (let i = 0; i < 14; i++) { const a = i / 14 * 6.283; FX.add({ x, y, vx: Math.cos(a) * 4.5, vy: Math.sin(a) * 4.5, life: 13, c: i % 2 ? col : '#fff', s: 2, g: 0, drag: 0.88 }); } };
  FX.ring = (x, y, col = '#fff', r = 30, life = 18) => FX.add({ x, y, life, kind: 'ring', c: col, s: r });
  FX.text = (x, y, str, col = '#fff', s = 1, life = 40, o = {}) => FX.add(Object.assign({ x, y, vy: -0.6, life, kind: 'text', c: str, col, s }, o));
  FX.dust = (x, y, n = 6) => FX.burst(x, y, n, ['#cdbfa5', '#a99f8a', '#e6dcc7'], 1.6, { g: 0.0, life: 18, vy: -0.4 });
  FX.update = () => {
    for (let i = FX.list.length - 1; i >= 0; i--) {
      const p = FX.list[i]; p.x += p.vx; p.y += p.vy; p.vy += p.g; p.vx *= p.drag; p.life--;
      if (p.kind === 'blood' && p.y >= RC.GY + RC.rnd(0, 14) && p.vy > 0) { if (FX.stains.length < 400) FX.stains.push({ x: p.x, y: Math.min(RC.H - 6, p.y), w: p.s + RC.ri(0, 2), c: p.c }); p.life = 0; }
      if (p.fn) p.fn(p);
      if (p.life <= 0) FX.list.splice(i, 1);
    }
  };
  FX.drawStains = ctx => { for (const s of FX.stains) { ctx.fillStyle = s.c; ctx.fillRect(Math.round(s.x), Math.round(s.y), s.w, 1); } };
  FX.draw = ctx => {
    for (const p of FX.list) {
      const a = Math.min(1, p.life / (p.max * 0.5)); ctx.globalAlpha = a;
      if (p.kind === 'text') { RC.Text.draw(ctx, p.c, p.x, p.y, { s: p.s, c: p.col, a: 'c', ol: '#000' }); }
      else if (p.kind === 'ring') { const r = p.s * (1 - p.life / p.max); ctx.strokeStyle = p.c; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(p.x, p.y, Math.max(1, r), 0, 6.283); ctx.stroke(); }
      else if (p.kind === 'flash') { ctx.fillStyle = p.c; const r = p.s * (p.life / p.max); ctx.fillRect(Math.round(p.x - r / 2), Math.round(p.y - r / 2), Math.round(r), Math.round(r)); }
      else if (p.kind === 'go') { RC.Text.go(ctx, p.x, p.y, p.s, p.c); }
      else { ctx.fillStyle = p.c; ctx.fillRect(Math.round(p.x), Math.round(p.y), p.s, p.s); }
    }
    ctx.globalAlpha = 1;
  };
})();
