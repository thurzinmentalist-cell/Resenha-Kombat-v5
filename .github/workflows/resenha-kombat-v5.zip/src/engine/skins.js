// Skins (roupas alternativas). Algumas são roupas inspiradas em personagens famosos (só a roupa, sem mudar o corpo do lutador).
// Cada skin altera a paleta (pal), remove/adiciona flags e extras que o sprite sabe desenhar.
(function () {
  const RC = window.RC, KEY = 'rc_skins';
  const LIST = {
    arthur: [
      // Só a roupa: o rosto e o cabelo do Arthur continuam à mostra (sem máscara).
      { id: 'aranha', name: 'TRAJE HOMEM-ARANHA', desc: 'TRAJE VERMELHO COM TEIAS PRETAS, ARANHA NO PEITO, LATERAIS E PERNAS AZUIS, LUVAS E BOTAS VERMELHAS. SEM MASCARA.',
        pal: { top: '#d0202e', bottom: '#1f3f9e', sleeve: '#d0202e', long: 1, shoes: '#d0202e', glove: '#d0202e', web: '#2a0608', side: '#1f3f9e' }, del: ['jacket'], ex: ['spider'] },
      // Só a roupa: cabelo, rosto e corpo do Arthur não mudam.
      { id: 'goku', name: 'ROUPA DO GOKU', desc: 'KIMONO LARANJA DE TREINO, CAMISA AZUL POR BAIXO, FAIXA E MUNHEQUEIRAS AZUIS E BOTAS AZUIS.',
        pal: { top: '#f27a1a', bottom: '#f27a1a', upper: '#1f3d8f', long: 1, shoes: '#1f3d8f', boot: '#1f3d8f', bootBand: '#e6c14a', wrist: '#1f3d8f', under: '#1f3d8f', obi: '#1f3d8f' }, del: ['jacket'], ex: ['gi'] }
    ],
    guilherme: [
      { id: 'calopsita', name: 'MANTO CALOPSITA', desc: 'MANTO VERDE-AGUA COM CALOPSITA DESENHADA NAS COSTAS E OUTRA CALOPSITA NA CABECA.',
        pal: { top: '#ffe9a8', bottom: '#24485a', shoes: '#e8c24a', cape: '#1d7f86', capeD: '#14585e', capeT: '#ffd84a' }, ex: ['cape', 'calop'] }
    ],
    kaique: [
      { id: 'terno', name: 'LORD KAIQUE', desc: 'TERNO E CHAPEU DE ABA LARGA BRANCOS, COLETE AZUL-CLARO E GRAVATA AZUL.',
        pal: { top: '#f8f8f8', bottom: '#f4f4f4', long: 1, shoes: '#ffffff', tie: '#1f4fa8', shirt: '#7ac7ff', hat: '#ffffff', hatBand: '#1f4fa8' }, del: ['dress'], add: ['suit'], ex: ['brimhat'] }
    ],
    toddy: [
      { id: 'jojo', name: 'JOJO', desc: 'SOBRETUDO LONGO BRANCO COM DETALHES DOURADOS, CAMISA AZUL-ESCURA, BONE BRANCO E GUARDIAO ROXO E AZUL COM OURO.',
        pal: { coat: '#eef0f4', coatD: '#b9bfcc', trim: '#e0b020', top: '#2b2f7a', bottom: '#eef0f4', cap: '#eef0f4', capTrim: '#e0b020',
          gp: { P: '#9a6ad0', Pd: '#5a3a8e', Pl: '#c49af0', G: '#e0b020', H: '#4fb8d8' } }, ex: [] }
    ]
  };
  // ordem antiga das skins (quando a escolha era salva por índice), para migrar saves antigos
  const LEGACY = { arthur: ['padrao', 'solar', 'neon', 'aranha', 'goku'] };
  for (const k in LIST) if (!LEGACY[k]) LEGACY[k] = ['padrao'].concat(LIST[k].map(s => s.id));
  let sel = {}; try { const s = JSON.parse(localStorage.getItem(KEY)); if (s && typeof s === 'object') sel = s; } catch (e) { }
  RC.Skins = {
    list(id) { return [{ id: 'padrao', name: 'PADRAO', desc: 'VISUAL ORIGINAL DO PERSONAGEM.', pal: {} }].concat(LIST[id] || []); },
    // a escolha é salva pelo id da skin; números antigos (índices) são convertidos
    get(id) { let v = sel[id]; if (typeof v === 'number') v = (LEGACY[id] || [])[v]; const i = this.list(id).findIndex(s => s.id === v); return i > 0 ? i : 0; },
    set(id, i) { const s = this.list(id)[i]; sel[id] = s ? s.id : 'padrao'; try { localStorage.setItem(KEY, JSON.stringify(sel)); } catch (e) { } },
    // skin efetiva (idx opcional força um índice, usado na prévia); null para o padrão
    cur(id, idx) { const i = idx != null ? idx : this.get(id); return i > 0 ? this.list(id)[i] || null : null; }
  };
})();
