// Arte procedural de invocações, projéteis e objetos (originais)
(function () {
  const RC = window.RC, D = RC.Draw = {}, S = RC.Sprites, R = S.R, L = S.L, sh = RC.shade, OUT = '#0c0a10';
  const circ = (c, x, y, r, col) => { c.fillStyle = col; c.beginPath(); c.arc(x, y, r, 0, 6.283); c.fill(); };
  D.circ = circ;
  // pessoa genérica simples (mulheres, tio, careca)
  function person(c, x, y, face, t, o) {
    c.save(); c.translate(Math.round(x), Math.round(y)); c.scale(face * (o.s || 1), o.s || 1);
    const run = o.run ? Math.sin(t * 0.5) : 0, skin = o.skin || '#f1d5bc', dress = o.dress || '#222';
    const dressy = o.kind === 'woman';
    // pernas
    L(c, -2, -26, -3 + run * 7, 0, 5, OUT); L(c, -2, -26, -3 + run * 7, 0, 3, o.legs || skin); L(c, 2, -26, 3 - run * 7, 0, 5, OUT); L(c, 2, -26, 3 - run * 7, 0, 3, o.legs || skin);
    if (o.kind === 'man') { L(c, -2, -26, -3 + run * 7, 0, 5, OUT); L(c, -2, -26, -3 + run * 7, 0, 4, o.pants || '#2c3550'); L(c, 2, -26, 3 - run * 7, 0, 5, OUT); L(c, 2, -26, 3 - run * 7, 0, 4, o.pants || '#2c3550'); }
    R(c, -6 + run * 7, -2, 7, 3, o.shoes || '#111'); R(c, 0 - run * 7, -2, 7, 3, o.shoes || '#111');
    // corpo
    if (dressy) { for (let yy = -48; yy < -20; yy += 2) { const t2 = (yy + 48) / 28, hw = 5 + t2 * 5; R(c, -hw - 1, yy, hw * 2 + 2, 2, OUT); R(c, -hw, yy, hw * 2, 2, dress); } R(c, -5, -48, 10, 2, sh(dress, 0.25)); }
    else { R(c, -8, -50, 17, 28, OUT); R(c, -7, -49, 15, 26, o.shirt || '#c0392b'); if (o.suit) { R(c, -7, -49, 4, 26, '#1c1c24'); R(c, 4, -49, 4, 26, '#1c1c24'); R(c, -1, -49, 3, 20, '#fff'); R(c, 0, -48, 1, 14, '#111'); } if (o.sash) { L(c, -7, -49, 7, -24, 5, OUT); L(c, -7, -49, 7, -24, 3, '#2fd06b'); L(c, -6, -48, 7, -25, 1, '#f3d54a'); } if (o.belly) R(c, 2, -40, 8, 9, o.shirt || '#c0392b'); }
    // braços
    const ax = o.armsUp ? 10 : 8 + Math.sin(t * 0.3) * 2;
    L(c, 3, -46, ax + 4, o.armsUp ? -64 : -34, 4, OUT); L(c, 3, -46, ax + 4, o.armsUp ? -64 : -34, 3, o.sleeve || skin);
    // cabeça
    R(c, -5, -61, 11, 12, OUT); R(c, -4, -60, 9, 10, skin);
    R(c, 0, -56, 1, 2, '#111'); R(c, 3, -56, 1, 2, '#111'); R(c, 1, -52, 3, 1, '#8a2a2a');
    if (o.hair === 'long') { R(c, -6, -64, 13, 6, o.hairc); R(c, -7, -60, 4, 22, o.hairc); R(c, -4, -64, 6, 1, sh(o.hairc, 0.3)); }
    else if (o.hair === 'bun') { R(c, -5, -64, 11, 5, o.hairc); R(c, -3, -68, 6, 5, o.hairc); R(c, -6, -60, 3, 6, o.hairc); }
    else if (o.hair === 'bald') { R(c, -4, -61, 9, 2, sh(skin, 0.2)); R(c, -6, -57, 2, 3, sh(skin, -0.1)); }
    else if (o.hair === 'short') { R(c, -5, -63, 11, 5, o.hairc || '#222'); R(c, -6, -60, 2, 5, o.hairc || '#222'); }
    if (o.stache) R(c, 1, -53, 5, 2, '#2a1a10');
    if (o.glam) { R(c, 1, -57, 4, 1, '#fff'); }
    c.restore();
  }
  D.person = person;
  D.bat = (c, x, y, s, t, face) => { // morcego pixel art
    const fl = Math.sin(t * 0.7); c.save(); c.translate(Math.round(x), Math.round(y)); c.scale((face || 1) * s, s);
    c.fillStyle = OUT; c.beginPath(); c.moveTo(0, -1); c.lineTo(-7, -4 - fl * 4); c.lineTo(-5, 0); c.lineTo(-3, -1); c.lineTo(-2, 2); c.lineTo(0, 0); c.lineTo(2, 2); c.lineTo(3, -1); c.lineTo(5, 0); c.lineTo(7, -4 - fl * 4); c.closePath(); c.fill();
    c.fillStyle = '#3a1f5e'; c.beginPath(); c.moveTo(0, -1); c.lineTo(-6, -3 - fl * 3); c.lineTo(-4, 0); c.lineTo(-2, 0); c.lineTo(0, 1); c.lineTo(2, 0); c.lineTo(4, 0); c.lineTo(6, -3 - fl * 3); c.closePath(); c.fill();
    R(c, -1, -3, 3, 4, '#150b25'); R(c, -1, -5, 1, 2, '#150b25'); R(c, 1, -5, 1, 2, '#150b25'); R(c, 0, -2, 1, 1, '#ff4d6d'); c.restore();
  };
  D.goth = (c, x, y, face, t, run, atk, hist) => { // gótica invocada: vestido espartilhado, cabelo longo, botas
    const sw = run ? Math.sin(t * 0.5) : Math.sin(t * 0.08) * 0.3, P = '#9a4dff', Pd = '#4b2480', DR = '#2a1f3d', DL = '#43306a', SK = '#ece3ec';
    c.save(); c.translate(Math.round(x), Math.round(y)); c.scale(face, 1);
    // brilho e sombra
    c.globalAlpha = 0.3; c.fillStyle = P; c.beginPath(); c.ellipse(0, -32, 19, 38, 0, 0, 6.283); c.fill(); c.globalAlpha = 0.18; c.fillStyle = '#d9b8ff'; c.beginPath(); c.ellipse(0, -34, 12, 30, 0, 0, 6.283); c.fill(); c.globalAlpha = 0.35; c.fillStyle = '#000'; c.beginPath(); c.ellipse(0, 0, 13, 3, 0, 0, 6.283); c.fill(); c.globalAlpha = 1;
    // cabelo de trás (flui para trás)
    const hs = Math.sin(t * 0.18) * 2 - (run ? 6 : 0);
    for (let i = 0; i < 9; i++) { const yy = -62 + i * 4, off = -5 - i * 0.9 + hs * (i / 8) + Math.sin(t * 0.2 + i * 0.7) * 1.2; R(c, off - 4, yy, 9, 5, OUT); R(c, off - 3, yy, 7, 5, i % 3 === 0 ? '#2a1f46' : '#120e1c'); R(c, off - 2, yy, 1, 4, '#6a4aa8'); R(c, off + 1, yy + 1, 1, 3, '#4a3480'); }
    // pernas
    const l1 = -3 + sw * 7, l2 = 3 - sw * 7;
    for (const [lx, col] of [[l1, '#26202f'], [l2, '#332a40']]) { L(c, lx > 0 ? 2 : -2, -22, lx, -8, 6, OUT); L(c, lx > 0 ? 2 : -2, -22, lx, -8, 4, col); R(c, lx - 4, -9, 9, 9, OUT); R(c, lx - 3, -9, 7, 8, '#0d0a12'); R(c, lx - 3, -9, 7, 1, '#3d2d58'); R(c, lx - 3, -5, 7, 1, P); R(c, lx + 1, -9, 2, 7, '#1f1830'); R(c, lx - 4, -2, 11, 2, '#050407'); }
    // saia em camadas com barra de renda
    for (let k = 0; k < 3; k++) { const y0 = -33 + k * 5, hw = 7 + k * 5 + Math.abs(sw) * 1.5; R(c, -hw - 1 + sw * 1.5, y0, hw * 2 + 2, 6, OUT); R(c, -hw + sw * 1.5, y0, hw * 2, 5, k % 2 ? DL : DR); R(c, -hw + sw * 1.5, y0, hw * 2, 1, k === 2 ? P : '#3d2d58'); }
    for (let i = -2; i <= 2; i++) { R(c, i * 4 - 1 + sw * 1.5, -18, 3, 3, P); R(c, i * 4 + sw * 1.5, -16, 1, 2, Pd); } // renda
    // espartilho
    R(c, -7, -49, 14, 18, OUT); R(c, -6, -48, 12, 16, DR); R(c, -6, -48, 12, 2, '#3d2d58'); R(c, 0, -47, 1, 15, P); for (let i = 0; i < 5; i++) { R(c, -2, -46 + i * 3, 5, 1, Pd); R(c, -1, -46 + i * 3, 1, 1, P); R(c, 1, -46 + i * 3, 1, 1, P); }
    R(c, -6, -33, 12, 2, P); R(c, -1, -34, 3, 4, '#d9b8ff');
    // colar com pingente
    R(c, -4, -52, 9, 3, OUT); R(c, -3, -51, 7, 1, P); R(c, 0, -50, 2, 3, '#d9b8ff');
    // braço de trás
    const bx = run ? -6 + sw * 6 : -7, by = run ? -36 : -34;
    L(c, -3, -46, bx, by, 6, OUT); L(c, -3, -46, bx, by, 4, DL); R(c, bx - 3, by - 2, 7, 6, OUT); R(c, bx - 2, by - 1, 5, 4, SK); // luva
    // cabeça
    R(c, -5, -62, 12, 13, OUT); R(c, -4, -61, 10, 11, SK); R(c, -4, -53, 10, 2, '#cfc4d0'); R(c, 4, -60, 2, 8, '#d7cdd8');
    R(c, 0, -57, 4, 3, OUT); R(c, 1, -56, 3, 2, '#fff'); R(c, 3, -56, 1, 2, '#9a4dff'); R(c, 0, -58, 5, 1, '#0b0912'); // olho com delineador
    R(c, 3, -53, 3, 1, '#4a1a5e'); R(c, 4, -52, 1, 1, '#2a0f38'); // batom
    R(c, 3, -55, 1, 1, '#d9a0b8'); // bochecha
    // franja e coroa de cabelo
    R(c, -6, -66, 14, 6, OUT); R(c, -5, -65, 12, 5, '#120e1c'); R(c, -2, -64, 5, 1, '#6a4aa8'); R(c, 1, -62, 6, 3, '#0b0912'); R(c, -4, -65, 6, 1, '#3b2a5c'); R(c, 3, -61, 3, 1, '#0b0912');
    D.bat(c, -1, -69, 0.8, t, 1); // presilha de morcego
    // braço da frente
    if (atk > 0) { const k = atk / 8, hx = 15 + (1 - k) * 4, hy = -44; L(c, 2, -46, hx, hy, 6, OUT); L(c, 2, -46, hx, hy, 4, DL); R(c, hx - 2, hy - 3, 7, 6, OUT); R(c, hx - 1, hy - 2, 5, 4, SK); for (let i = 0; i < 3; i++) L(c, hx + 4, hy - 2 + i * 2, hx + 11, hy - 4 + i * 4, 1, i === 1 ? '#fff' : P); c.globalAlpha = 0.6 * k; L(c, hx - 4, hy + 8, hx + 16, hy - 10, 3, '#d9b8ff'); c.globalAlpha = 1; }
    else { const fx = run ? 7 - sw * 6 : 8 + Math.sin(t * 0.1) * 1, fy = run ? -38 : -35; L(c, 2, -46, fx, fy, 6, OUT); L(c, 2, -46, fx, fy, 4, DL); R(c, fx - 2, fy - 2, 6, 6, OUT); R(c, fx - 1, fy - 1, 4, 4, SK); }
    c.restore();
  };
  D.blonde = (c, x, y, face, t) => person(c, x, y, face, t, { kind: 'woman', dress: '#c8102e', skin: '#f6dcc8', hair: 'long', hairc: '#f0cf5a', legs: '#f6dcc8', shoes: '#8c0a20', glam: 1 });
  D.harem = (c, x, y, face, t, i, run) => person(c, x, y, face, t, { kind: 'woman', dress: ['#ff4d8d', '#3bb4ff', '#3fd17f', '#ffb534', '#b86bff'][i % 5], skin: ['#f6dcc8', '#e6bf9f', '#fbe6d6', '#c9967a'][i % 4], hair: i % 2 ? 'bun' : 'long', hairc: ['#2a1a10', '#8a4b20', '#111', '#d9b25a'][i % 4], run, legs: '#f2d8c4', shoes: '#222' });
  D.girlfriend = (c, x, y, face, t) => person(c, x, y, face, t, { kind: 'woman', dress: '#f4f4f8', skin: '#fbe6d6', hair: 'long', hairc: '#6b3a1c', legs: '#fbe6d6', shoes: '#ddd' });
  D.suited = (c, x, y, face, t) => person(c, x, y, face, t, { kind: 'man', suit: 1, sash: 1, hair: 'bald', skin: '#e9c7a8', pants: '#1c1c24', belly: 0, s: 1.05 });
  D.uncle = (c, x, y, face, t, run) => person(c, x, y, face, t, { kind: 'man', shirt: '#2f8f6a', pants: '#3a4a7a', hair: 'short', hairc: '#2a1a10', stache: 1, skin: '#e0b894', run, belly: 1, s: 1.08 });
  D.sponge = (c, x, y, face, t) => {
    c.save(); c.translate(Math.round(x), Math.round(y)); c.scale(face, 1);
    L(c, -4, -18, -4, 0, 4, OUT); L(c, -4, -18, -4, 0, 2, '#e8c542'); L(c, 5, -18, 5, 0, 4, OUT); L(c, 5, -18, 5, 0, 2, '#e8c542'); R(c, -8, -2, 7, 3, '#222'); R(c, 2, -2, 7, 3, '#222');
    R(c, -13, -52, 27, 36, OUT); R(c, -12, -51, 25, 34, '#f2d03a'); R(c, -12, -51, 25, 3, '#ffe97a');
    for (const [hx, hy] of [[-8, -44], [6, -40], [-4, -28], [8, -26], [-9, -22]]) { R(c, hx, hy, 3, 3, '#c9a21c'); }
    R(c, -7, -44, 7, 7, '#fff'); R(c, 2, -44, 7, 7, '#fff'); R(c, -4, -42, 2, 2, '#111'); R(c, 5, -42, 2, 2, '#111');
    R(c, -5, -33, 12, 2, '#7a2a10'); R(c, -2, -31, 3, 4, '#fff'); R(c, 3, -31, 3, 4, '#fff');
    L(c, -13, -38, -20, -28 + Math.sin(t * 0.3) * 3, 3, '#f2d03a'); L(c, 13, -38, 20, -28 - Math.sin(t * 0.3) * 3, 3, '#f2d03a');
    c.restore();
  };
  // calopsita
  D.bird = (c, x, y, face, t, s = 1, o = {}) => { // calopsita: crista de penas, bochecha laranja, asa em camadas, cauda longa
    c.save(); c.translate(Math.round(x), Math.round(y)); c.scale(face * s, s);
    const fl = Math.sin(t * 0.6), ball = o.ball, G1 = ball ? '#ffe14a' : '#a9afbb', G2 = ball ? '#e8b800' : '#7d8493', G3 = ball ? '#fff0a0' : '#d3d8e2', Y = '#ffd93d', O = '#ff7f2a';
    if (o.glow) { c.globalAlpha = 0.25; c.fillStyle = o.glow; c.beginPath(); c.arc(0, -8, 20, 0, 6.283); c.fill(); c.globalAlpha = 1; }
    // asa de trás
    c.fillStyle = OUT; c.beginPath(); c.moveTo(-2, -5); c.lineTo(-12, -15 + fl * 5); c.lineTo(-15, -6 + fl * 3); c.lineTo(-8, 0); c.fill();
    c.fillStyle = G2; c.beginPath(); c.moveTo(-2, -5); c.lineTo(-11, -14 + fl * 5); c.lineTo(-13, -6 + fl * 3); c.lineTo(-7, -1); c.fill();
    // cauda
    for (let i = 0; i < 3; i++) { R(c, -17 + i, -4 + i * 2, 11, 3, OUT); R(c, -16 + i, -3 + i * 2, 10, 1, i === 1 ? G3 : G1); R(c, -16 + i, -2 + i * 2, 10, 1, G2); }
    // corpo
    R(c, -8, -11, 17, 13, OUT); R(c, -7, -10, 15, 11, G1); R(c, -7, -10, 15, 2, G3); R(c, -7, -3, 15, 4, G2); R(c, -2, -6, 9, 5, G3); // barriga clara
    // asa da frente em penas
    c.fillStyle = OUT; c.beginPath(); c.moveTo(-3, -9); c.lineTo(-13, -4 + fl * 6); c.lineTo(-11, 2 + fl * 3); c.lineTo(-1, 0); c.fill();
    c.fillStyle = G2; c.beginPath(); c.moveTo(-3, -8); c.lineTo(-12, -4 + fl * 6); c.lineTo(-10, 1 + fl * 3); c.lineTo(-1, -1); c.fill();
    R(c, -9, -3 + fl * 3, 7, 1, G3); R(c, -8, -1 + fl * 2, 6, 1, G3);
    // cabeça
    R(c, 3, -20, 11, 12, OUT); R(c, 4, -19, 9, 10, ball ? '#ffe96a' : Y); R(c, 4, -19, 9, 2, '#ffe97a');
    R(c, 8, -14, 4, 4, OUT); R(c, 8, -14, 3, 3, O); // bochecha
    R(c, 6, -16, 3, 3, '#fff'); R(c, 7, -16, 2, 2, '#111'); R(c, 7, -16, 1, 1, '#fff'); // olho
    R(c, 12, -15, 4, 4, OUT); R(c, 12, -14, 3, 3, '#cfc9bd'); R(c, 13, -13, 2, 1, '#8d8678'); // bico
    // crista
    for (let i = 0; i < 4; i++) { const hh = [5, 8, 9, 6][i], sy = -20 - hh + (i === 3 ? 1 : 0), xx = 3 + i * 2 - (i > 1 ? 0 : 1); R(c, xx, sy - 1, 3, hh + 1, OUT); R(c, xx + 1, sy, 1, hh, Y); R(c, xx + 1, sy, 1, 2, '#fff3a0'); }
    // patinhas
    R(c, -2, 2, 2, 3, '#a89c88'); R(c, 3, 2, 2, 3, '#a89c88');
    c.restore();
  };
  D.smiley = (c, x, y, r, rot = 0, o = {}) => {
    c.save(); c.translate(Math.round(x), Math.round(y)); c.rotate(rot);
    circ(c, 0, 0, r + 1.5, OUT); circ(c, 0, 0, r, o.col || '#ffe14a'); circ(c, -r * 0.3, -r * 0.35, r * 0.4, '#fff3a0');
    R(c, -r * 0.4, -r * 0.3, Math.max(2, r * 0.2), Math.max(3, r * 0.35), '#2a2000'); R(c, r * 0.2, -r * 0.3, Math.max(2, r * 0.2), Math.max(3, r * 0.35), '#2a2000');
    c.strokeStyle = '#2a2000'; c.lineWidth = Math.max(1, r * 0.12); c.beginPath(); c.arc(0, r * 0.05, r * 0.55, 0.25, 2.9); c.stroke();
    c.restore();
  };
  D.burger = (c, x, y, s = 1, rot = 0) => {
    c.save(); c.translate(Math.round(x), Math.round(y)); c.rotate(rot); c.scale(s, s);
    R(c, -9, -8, 19, 17, OUT); R(c, -8, -7, 17, 6, '#d98c3a'); R(c, -8, -7, 17, 2, '#efb060'); R(c, -6, -5, 1, 1, '#fff3c0'); R(c, 0, -4, 1, 1, '#fff3c0'); R(c, 4, -5, 1, 1, '#fff3c0');
    R(c, -8, -1, 17, 2, '#4cc04c'); R(c, -8, 1, 17, 3, '#6a2d14'); R(c, -8, 4, 17, 1, '#f5c542'); R(c, -8, 5, 17, 3, '#d98c3a');
    c.restore();
  };
  D.chair = (c, x, y, s = 1, rot = 0, o = {}) => {
    c.save(); c.translate(Math.round(x), Math.round(y)); c.rotate(rot); c.scale(s, s);
    const col = o.col || '#c43b2b';
    R(c, -13, -8, 27, 8, OUT); R(c, -12, -7, 25, 6, col); R(c, -12, -7, 25, 2, sh(col, 0.3));
    R(c, -13, -34, 8, 28, OUT); R(c, -12, -33, 6, 26, col); R(c, -12, -33, 2, 26, sh(col, 0.3));
    L(c, -10, 0, -12, 18, 3, OUT); L(c, -10, 0, -12, 18, 1, '#aaa'); L(c, 10, 0, 12, 18, 3, OUT); L(c, 10, 0, 12, 18, 1, '#aaa');
    c.restore();
  };
  D.rat = (c, x, y, face, t, s = 1) => {
    c.save(); c.translate(Math.round(x), Math.round(y)); c.scale(face * s, s); const run = Math.sin(t * 0.8);
    L(c, -14, -5, -22, -8 + run * 3, 2, '#e7a3b6');
    R(c, -12, -12, 22, 10, OUT); R(c, -11, -11, 20, 8, '#8a8b96'); R(c, -11, -5, 20, 3, '#6b6c76');
    R(c, 6, -15, 10, 9, OUT); R(c, 7, -14, 9, 7, '#9a9ba6'); R(c, 15, -11, 4, 3, '#e0457b'); R(c, 8, -19, 4, 5, '#e7a3b6'); R(c, 12, -17, 1, 1, '#111'); R(c, 10, -13, 1, 1, '#111');
    R(c, -8 + run * 3, -3, 4, 3, '#e7a3b6'); R(c, 4 - run * 3, -3, 4, 3, '#e7a3b6');
    c.restore();
  };
  D.car = (c, x, y, face, t) => {
    c.save(); c.translate(Math.round(x), Math.round(y)); c.scale(face, 1);
    R(c, -50, -14, 100, 10, OUT); R(c, -49, -13, 98, 8, '#d62828'); R(c, -49, -13, 98, 2, '#ff6b5a');
    c.fillStyle = OUT; c.beginPath(); c.moveTo(-34, -14); c.lineTo(-18, -30); c.lineTo(12, -30); c.lineTo(34, -14); c.fill();
    c.fillStyle = '#d62828'; c.beginPath(); c.moveTo(-31, -14); c.lineTo(-17, -28); c.lineTo(11, -28); c.lineTo(31, -14); c.fill();
    c.fillStyle = '#8fd3ff'; c.beginPath(); c.moveTo(-26, -15); c.lineTo(-15, -26); c.lineTo(-1, -26); c.lineTo(-1, -15); c.fill(); c.beginPath(); c.moveTo(3, -15); c.lineTo(3, -26); c.lineTo(10, -26); c.lineTo(24, -15); c.fill();
    R(c, 44, -12, 6, 3, '#fff6a8'); R(c, -50, -12, 4, 3, '#ff3b3b'); R(c, -10, -6, 20, 2, '#111');
    for (const wx of [-30, 30]) { circ(c, wx, -3, 9, OUT); circ(c, wx, -3, 7, '#222'); circ(c, wx, -3, 3, '#bbb'); c.fillStyle = '#888'; c.save(); c.translate(wx, -3); c.rotate(t * 0.6); c.fillRect(-1, -6, 2, 12); c.restore(); }
    c.restore();
  };
  D.heart = (c, x, y, s = 1, col = '#ff4d8d') => { c.save(); c.translate(Math.round(x), Math.round(y)); c.scale(s, s); R(c, -4, -4, 4, 4, col); R(c, 1, -4, 4, 4, col); R(c, -4, -1, 9, 4, col); R(c, -2, 3, 5, 2, col); R(c, 0, 5, 1, 1, col); R(c, -3, -3, 1, 1, '#fff'); c.restore(); };
  D.gun = (c, x, y, face, big) => { c.save(); c.translate(Math.round(x), Math.round(y)); c.scale(face, 1); if (big) { R(c, 0, -2, 22, 4, OUT); R(c, 1, -1, 20, 2, '#555a66'); R(c, -6, 0, 8, 4, '#6a4a2a'); } else { R(c, 0, -2, 9, 4, OUT); R(c, 1, -1, 7, 2, '#6e7480'); R(c, 0, 1, 3, 4, '#333'); } c.restore(); };
  D.sword = (c, x, y, rot, s = 1) => { c.save(); c.translate(Math.round(x), Math.round(y)); c.rotate(rot); c.scale(s, s); c.fillStyle = OUT; c.beginPath(); c.moveTo(-3, 0); c.lineTo(0, -26); c.lineTo(3, 0); c.fill(); c.fillStyle = '#9be8ff'; c.beginPath(); c.moveTo(-2, 0); c.lineTo(0, -24); c.lineTo(2, 0); c.fill(); R(c, -6, 0, 12, 3, '#5aa8d8'); R(c, -1, 3, 3, 6, '#2a4a7a'); c.restore(); };
  D.arrow = (c, x, y, face) => { c.save(); c.translate(Math.round(x), Math.round(y)); c.scale(face, 1); R(c, -14, -1, 24, 2, '#e8d9a8'); c.fillStyle = '#9be8ff'; c.beginPath(); c.moveTo(10, -3); c.lineTo(16, 0); c.lineTo(10, 3); c.fill(); R(c, -15, -3, 3, 6, '#7ad'); c.restore(); };
  D.skull = (c, x, y, s = 1) => { c.save(); c.translate(x, y); c.scale(s, s); R(c, -6, -7, 12, 13, OUT); R(c, -5, -6, 10, 9, '#ece6d2'); R(c, -4, 3, 8, 3, '#b9b29b'); R(c, -3, -3, 3, 3, '#111'); R(c, 1, -3, 3, 3, '#111'); c.restore(); };
  D.head = (c, id, x, y, rot = 0) => { // cabeça solta (para fatalities)
    c.save(); c.translate(Math.round(x), Math.round(y)); c.rotate(rot);
    const d = RC.DATA.characters[id], Lk = S.look({ id, baseId: id, clock: 0, anim: 'idle', form: null });
    S.figure(c, { clock: 0 }, Lk, { hx: 0, hy: 100, sx: 0, sy: 100, dx: 0, dy: 0, hf: [0, 100], hb: [0, 100], ff: [0, 100], fb: [0, 100] }, { bust: true, headOnly: true });
    c.restore();
  };
  D.drop = (c, x, y, col) => { R(c, x, y, 2, 5, col); R(c, x, y - 1, 2, 1, sh(col, 0.4)); };
  D.bolt = (c, x0, y0, x1, y1, col, th = 3) => { let px = x0, py = y0; const n = 8; for (let i = 1; i <= n; i++) { const t = i / n, nx = x0 + (x1 - x0) * t + (i < n ? RC.rnd(-9, 9) : 0), ny = y0 + (y1 - y0) * t; L(c, px, py, nx, ny, th + 2, col); L(c, px, py, nx, ny, th, '#fff'); px = nx; py = ny; } };
  D.beam = (c, x, y, w, h, c1, c2, t) => { // feixe horizontal (x..x+w): brilho em camadas, borda ondulada, faíscas
    c.save(); const wob = (i, k) => Math.sin((i + t * 14) * 0.09) * 0.12 + Math.sin((i - t * 9) * 0.23) * 0.08 + k;
    c.fillStyle = c1; c.globalAlpha = 0.14; c.fillRect(x, y - h * 1.05, w, h * 2.1); c.globalAlpha = 0.26; c.fillRect(x, y - h * 0.78, w, h * 1.56); c.globalAlpha = 1;
    for (let i = 0; i < w; i += 4) { const hh = h * (0.92 + wob(i, 0)); c.fillStyle = sh(c1, -0.25); c.fillRect(x + i, y - hh / 2 - 1, 4, hh + 2); c.fillStyle = c1; c.fillRect(x + i, y - hh / 2 + 1, 4, hh - 2); }
    for (let i = 0; i < w; i += 4) { const hh = h * 0.58 * (0.92 + wob(i + 40, 0)); c.fillStyle = c2; c.fillRect(x + i, y - hh / 2, 4, hh); }
    for (let i = 0; i < w; i += 4) { const hh = h * 0.26 * (0.9 + wob(i + 90, 0)); c.fillStyle = '#fff'; c.fillRect(x + i, y - hh / 2, 4, Math.max(2, hh)); }
    c.fillStyle = '#fff'; for (let i = 0; i < 20; i++) { const sx = x + ((i * 47 + t * (22 + (i % 4) * 5)) % w), sy = y - h * 0.5 + ((i * 13 + t) % Math.max(4, h)); c.globalAlpha = 0.85; c.fillRect(sx, sy, 10 + (i % 3) * 8, 1); }
    c.globalAlpha = 0.5; c.fillStyle = c1; for (let i = 0; i < 10; i++) { const sx = x + ((i * 71 + t * 9) % w), sy = y + ((i % 2) ? -1 : 1) * (h * 0.6 + ((i * 7 + t * 2) % 10)); c.fillRect(sx, sy, 2, 2); }
    c.restore();
  };
  D.orb = (c, x, y, r, c1, c2, t) => { // esfera de energia: halo, núcleo, brilho e faíscas orbitando
    const p = 1 + Math.sin(t * 0.45) * 0.1; c.save();
    for (let i = 4; i >= 1; i--) { c.globalAlpha = 0.09 * (5 - i); circ(c, x, y, r * (1 + i * 0.3) * p, c1); } c.globalAlpha = 1;
    circ(c, x, y, r * p, sh(c1, -0.3)); circ(c, x, y, r * 0.86 * p, c1); circ(c, x, y, r * 0.58 * p, c2); circ(c, x, y, r * 0.3 * p, '#fff');
    c.globalAlpha = 0.75; circ(c, x - r * 0.32, y - r * 0.36, Math.max(1, r * 0.17), '#fff'); c.globalAlpha = 1;
    for (let i = 0; i < 6; i++) { const a = t * 0.24 + i * 1.047, rr = r * (1.2 + 0.1 * Math.sin(t * 0.3 + i)); R(c, x + Math.cos(a) * rr - 1, y + Math.sin(a) * rr * 0.8 - 1, 3, 3, i % 2 ? '#fff' : c2); }
    c.restore();
  };
})();
