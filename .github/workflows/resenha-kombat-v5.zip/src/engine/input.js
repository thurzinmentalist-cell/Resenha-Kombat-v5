// Entrada: teclado (remapeável), gamepad, toque e mouse
(function () {
  const RC = window.RC;
  const ACTS = ['l', 'r', 'u', 'd', 'lp', 'hp', 'lk', 'hk', 'grab', 'special', 'ultimate', 'transform', 'fusion', 'aux', 'swap'];
  const LABEL = { l: 'ESQUERDA', r: 'DIREITA', u: 'CIMA', d: 'BAIXO', lp: 'SOCO FRACO', hp: 'SOCO FORTE', lk: 'CHUTE FRACO', hk: 'CHUTE FORTE', grab: 'AGARRAO', special: 'ESPECIAL', ultimate: 'ULTIMATE', transform: 'TRANSFORMAR', fusion: 'FUSAO', aux: 'AUXILIAR', swap: 'TROCAR LUTADOR' };
  const DEF = [
    { l: 'KeyA', r: 'KeyD', u: 'KeyW', d: 'KeyS', lp: 'KeyF', hp: 'KeyG', lk: 'KeyR', hk: 'KeyT', grab: 'KeyV', special: 'KeyC', ultimate: 'KeyX', transform: 'KeyZ', fusion: 'KeyB', aux: 'KeyQ', swap: 'KeyE' },
    { l: 'ArrowLeft', r: 'ArrowRight', u: 'ArrowUp', d: 'ArrowDown', lp: 'KeyJ', hp: 'KeyK', lk: 'KeyU', hk: 'KeyI', grab: 'KeyN', special: 'KeyM', ultimate: 'Comma', transform: 'Period', fusion: 'Slash', aux: 'KeyH', swap: 'KeyO' }
  ];
  let map = JSON.parse(JSON.stringify(DEF));
  try { const s = localStorage.getItem('rc_map'); if (s) { const m = JSON.parse(s); if (m && m[0] && m[1]) map = m; } } catch (e) { }
  for (let i = 0; i < 2; i++) for (const a of ACTS) if (!map[i][a]) map[i][a] = DEF[i][a];
  const keys = new Set(), edges = new Set();
  const mk = () => { const o = { held: {}, prev: {}, pressed: {}, hist: [] }; ACTS.forEach(a => { o.held[a] = o.prev[a] = o.pressed[a] = false; }); return o; };
  const I = RC.Input = { ACTS, LABEL, DEF, map, p: [mk(), mk()], nav: {}, ptr: { x: 0, y: 0, clicked: false, down: false, moved: false }, touch: {}, capture: null, anyKey: false };
  I.saveMap = () => { try { localStorage.setItem('rc_map', JSON.stringify(I.map)); } catch (e) { } };
  I.resetMap = () => { I.map[0] = Object.assign({}, DEF[0]); I.map[1] = Object.assign({}, DEF[1]); I.saveMap(); };
  const BLOCK = new Set(['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Space', 'Tab', 'Slash', 'Comma', 'Period']);
  addEventListener('keydown', e => {
    if (BLOCK.has(e.code)) e.preventDefault();
    if (I.capture) { e.preventDefault(); const f = I.capture; I.capture = null; f(e.code); return; }
    if (e.repeat) return; keys.add(e.code); edges.add(e.code); I.anyKey = true; RC.Audio && RC.Audio.resume();
  });
  addEventListener('keyup', e => keys.delete(e.code));
  addEventListener('blur', () => keys.clear());
  const cv = () => document.getElementById('c');
  function setPtr(e) { const r = cv().getBoundingClientRect(); I.ptr.x = (e.clientX - r.left) / r.width * RC.W; I.ptr.y = (e.clientY - r.top) / r.height * RC.H; }
  addEventListener('load', () => {
    const c = cv();
    c.addEventListener('pointerdown', e => { setPtr(e); I.ptr.down = true; I.ptr.clicked = true; I.ptr.moved = true; RC.Audio && RC.Audio.resume(); });
    c.addEventListener('pointermove', e => { setPtr(e); I.ptr.moved = true; });
    addEventListener('pointerup', () => { I.ptr.down = false; });
    c.addEventListener('contextmenu', e => e.preventDefault());
  });
  I.update = function () {
    const pads = navigator.getGamepads ? navigator.getGamepads() : [];
    for (let i = 0; i < 2; i++) {
      const p = I.p[i], m = I.map[i], h = {};
      for (const a of ACTS) h[a] = keys.has(m[a]);
      const gp = pads[i];
      if (gp) {
        const b = n => gp.buttons[n] && gp.buttons[n].pressed;
        h.l = h.l || b(14) || gp.axes[0] < -0.4; h.r = h.r || b(15) || gp.axes[0] > 0.4;
        h.u = h.u || b(12) || gp.axes[1] < -0.55; h.d = h.d || b(13) || gp.axes[1] > 0.45;
        h.lp = h.lp || b(0); h.hp = h.hp || b(1); h.lk = h.lk || b(2); h.hk = h.hk || b(3);
        h.grab = h.grab || b(4); h.special = h.special || b(5); h.aux = h.aux || b(6); h.ultimate = h.ultimate || b(7);
        h.transform = h.transform || b(8); h.fusion = h.fusion || b(9); h.swap = h.swap || b(10) || b(11);
      }
      if (i === 0) for (const a of ACTS) if (I.touch[a]) h[a] = true;
      for (const a of ACTS) {
        p.prev[a] = p.held[a]; p.held[a] = h[a]; p.pressed[a] = h[a] && !p.prev[a];
        if (p.pressed[a] && a !== 'transform' && a !== 'fusion' && a !== 'swap') { p.hist.push({ k: a, f: RC.frame }); if (p.hist.length > 24) p.hist.shift(); }
      }
    }
    const e = k => edges.has(k), pr = a => I.p[0].pressed[a] || I.p[1].pressed[a];
    I.nav = {
      up: pr('u') || e('ArrowUp') || e('KeyW'), down: pr('d') || e('ArrowDown') || e('KeyS'),
      left: pr('l') || e('ArrowLeft') || e('KeyA'), right: pr('r') || e('ArrowRight') || e('KeyD'),
      ok: pr('lp') || pr('hp') || e('Enter') || e('Space'), back: pr('lk') || pr('hk') || e('Escape') || e('Backspace'),
      pause: e('Escape') || e('KeyP') || I.p[0].pressed.fusion && false
    };
  };
  I.endFrame = function () { edges.clear(); I.ptr.clicked = false; I.ptr.moved = false; I.anyKey = false; };
  // verifica se a sequência (tokens F,B,U,D ou botão) foi digitada nos últimos `win` quadros
  I.seq = function (pi, seq, face, win) {
    const h = I.p[pi].hist, F = face > 0 ? 'r' : 'l', B = face > 0 ? 'l' : 'r';
    const tok = k => (k === F ? 'F' : k === B ? 'B' : k === 'u' ? 'U' : k === 'd' ? 'D' : k);
    let si = seq.length - 1;
    for (let i = h.length - 1; i >= 0 && si >= 0; i--) {
      if (RC.frame - h[i].f > win) break;
      if (tok(h[i].k) === seq[si]) si--;
    }
    return si < 0;
  };
  I.clearHist = () => { I.p[0].hist.length = 0; I.p[1].hist.length = 0; };
})();
