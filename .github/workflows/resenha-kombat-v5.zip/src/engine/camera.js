// Câmera: tremor, zoom dinâmico e foco para cutscenes
(function () {
  const RC = window.RC;
  const C = RC.Cam = { x: 240, y: 135, z: 1, tx: 240, ty: 135, tz: 1, sp: 0, st: 0, ox: 0, oy: 0, lock: false };
  C.reset = () => { C.x = C.tx = 240; C.y = C.ty = 135; C.z = C.tz = 1; C.sp = C.st = 0; C.lock = false; };
  C.shake = (p, t = 12) => { if (p >= C.sp || C.st <= 0) { C.sp = p; C.st = t; } };
  C.focus = (x, y, z) => { C.tx = x; C.ty = y; C.tz = z; };
  C.update = () => {
    C.x += (C.tx - C.x) * 0.12; C.y += (C.ty - C.y) * 0.12; C.z += (C.tz - C.z) * 0.12;
    const hw = 240 / C.z, hh = 135 / C.z; C.x = RC.clamp(C.x, hw, RC.W - hw); C.y = RC.clamp(C.y, hh, RC.H - hh);
    if (C.st > 0) { C.st--; const k = C.sp * Math.min(1, C.st / 8); C.ox = RC.rnd(-k, k); C.oy = RC.rnd(-k, k); } else { C.ox = C.oy = 0; C.sp = 0; }
  };
  C.begin = ctx => { ctx.save(); ctx.translate(240 + C.ox, 135 + C.oy); ctx.scale(C.z, C.z); ctx.translate(-Math.round(C.x), -Math.round(C.y)); };
  C.end = ctx => ctx.restore();
})();
