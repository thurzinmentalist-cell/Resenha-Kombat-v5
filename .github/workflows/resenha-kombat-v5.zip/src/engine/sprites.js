// Sprites placeholder em pixel art desenhados por código.
// Para usar spritesheets: preencha "sheet" em data/characters/<id>.json (ver README). Se sheet != null, RC.Sprites.sheetDraw é usado.
(function () {
  const RC = window.RC, S = RC.Sprites = { sheets: {} };
  const OUT = '#0c0a10', sh = RC.shade;
  const R = (c, x, y, w, h, col) => { c.fillStyle = col; c.fillRect(Math.round(x), Math.round(y), w, h); };
  function L(c, x0, y0, x1, y1, th, col) {
    const d = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0), 1); c.fillStyle = col;
    for (let i = 0; i <= d; i++) c.fillRect(Math.round(x0 + (x1 - x0) * i / d - th / 2), Math.round(y0 + (y1 - y0) * i / d - th / 2), th, th);
  }
  const seg = (c, x0, y0, x1, y1, th, col) => { L(c, x0, y0, x1, y1, th + 2, OUT); L(c, x0, y0, x1, y1, th, col); };
  function ik(x0, y0, x1, y1, l1, l2, bend) {
    let dx = x1 - x0, dy = y1 - y0, d = Math.hypot(dx, dy); const mx = l1 + l2 - 0.01;
    if (d > mx) { const k = mx / d; dx *= k; dy *= k; d = mx; x1 = x0 + dx; y1 = y0 + dy; }
    if (d < 1) d = 1;
    const a = (l1 * l1 - l2 * l2 + d * d) / (2 * d), h = Math.sqrt(Math.max(0, l1 * l1 - a * a));
    return { x: x0 + dx * a / d + (-dy / d) * h * bend, y: y0 + dy * a / d + (dx / d) * h * bend, hx: x1, hy: y1 };
  }
  S.ik = ik; S.R = R; S.L = L;

  // ---------- aparência ----------
  const FV = {
    artugui: { body: 'arthur', hair: 'arthur', ex: ['wings', 'crest'], wing: ['#f3d54a', '#bdbdbd'], aura: '#f3d54a' },
    kagui: { body: 'kaique', hair: 'kaique', ex: ['wings', 'crest'], wing: ['#ffe14a', '#ffffff'], aura: '#ffe14a' },
    xantur: { body: 'alexandre', hair: 'arthur', ex: ['sash'], jacket: 1, aura: '#2fd06b' },
    artoddy: { body: 'toddy', hair: 'arthur', ex: ['sash'], aura: '#2fd06b' },
    guiddy: { body: 'toddy', hair: 'toddy', ex: ['wings', 'crest'], wing: ['#8a3ff0', '#f3d54a'], aura: '#8a3ff0' },
    kaxandre: { body: 'alexandre', hair: 'kaique', ex: [], aura: '#ffe14a' },
    vithur: { body: 'vitin', hair: 'arthur', ex: ['sash'], jacket: 1, aura: '#2fd06b' },
    vitoddy: { body: 'toddy', hair: 'vitin', ex: ['jersey'], aura: '#8a3ff0' },
    kaddy: { body: 'toddy', hair: 'kaique', ex: [], aura: '#ffe14a' }
  };
  S.look = function (f) {
    const id = f.baseId || f.id, d = RC.DATA.characters[id];
    const Lk = { id, pal: Object.assign({}, d.pal), flags: d.flags.slice(), scale: d.size.scale, wide: d.size.wide, extras: [], eyesWhite: false, aura: null, form: f.form || null, child: false, gold: d.pal.trim };
    if (!f.fusionId && RC.Skins) { const sk = RC.Skins.cur(id, f.skinIdx); if (sk) { Object.assign(Lk.pal, sk.pal); Lk.flags = Lk.flags.filter(x => !(sk.del || []).includes(x)).concat(sk.add || []); Lk.extras = Lk.extras.concat(sk.ex || []); Lk.skin = sk.id; } }
    const fv = f.fusionId && FV[f.fusionId];
    if (fv) {
      const b = RC.DATA.characters[fv.body], h = RC.DATA.characters[fv.hair];
      Lk.id = fv.body; Lk.pal = Object.assign({}, b.pal); Lk.flags = b.flags.slice(); Lk.scale = b.size.scale * 1.1; Lk.wide = b.size.wide;
      Lk.hairFlags = h.flags; Lk.pal.hair = h.pal.hair; Lk.extras = fv.ex.slice(); Lk.wing = fv.wing; Lk.aura = fv.aura;
      if (fv.jacket) { Lk.flags.push('jacket'); Lk.pal.jacket = '#151515'; }
      if (fv.ex.includes('jersey')) Lk.pal.top = '#f1d32e';
    }
    switch (Lk.form) {
      case 'guilherme': Lk.extras.push('wings', 'crest'); Lk.wing = ['#ffe066', '#cfcfcf']; Lk.aura = '#ffe066'; break;
      case 'arthur': Lk.extras.push('sash'); Lk.aura = '#2fd06b'; Lk.scale *= 1.08; break;
      case 'toddy': Lk.aura = '#8a3ff0'; break;
      case 'vitin': Lk.scale *= 0.66; Lk.child = true; break;
      case 'matheus': Lk.pal.hair = '#e8c547'; Lk.pal.top = '#ff7fa8'; Lk.flags = Lk.flags.filter(x => x !== 'suit'); Lk.flags.push('heart'); Lk.aura = '#ff7fa8'; break;
      case 'luan': Lk.flags = ['rat', 'suit', 'muscle']; Lk.pal = Object.assign(Lk.pal, { skin: '#8f909e', top: '#26263a', bottom: '#26263a', tie: '#e0457b', hair: '#6d6e7a' }); Lk.scale = 1.28; Lk.wide = 1.35; break;
      case 'alexandre': Lk.flags = ['spiky', 'muscle', 'shirtless']; Lk.pal = Object.assign(Lk.pal, { skin: '#b4b8c6', hair: '#0e0e16', top: null, bottom: '#14141c' }); Lk.eyesWhite = true; Lk.scale = 1.38; Lk.wide = 1.3; Lk.aura = '#e8e8ff'; Lk.rough = true; break;
      case 'rafael': Lk.eyesWhite = true; Lk.aura = '#4aa8ff'; break;
      case 'joel': Lk.flags = ['ape', 'shirtless', 'muscle']; Lk.pal = Object.assign(Lk.pal, { skin: '#6b4220', hair: '#3b2210', bottom: '#161616' }); Lk.scale = 1.55; Lk.wide = 1.5; Lk.aura = '#c98a3a'; break;
      case 'kaique': Lk.ball = true; Lk.aura = '#ffe14a'; break;
    }
    Lk.hs = hairStyleOf(Lk.hairFlags || Lk.flags);
    return Lk;
  };
  function hairStyleOf(fl) {
    for (const k of ['cap', 'police', 'bandana', 'surfer', 'curly', 'crespo', 'volume']) if (fl.includes(k)) return k;
    return 'short';
  }

  // ---------- pose ----------
  S.pose = function (f) {
    const a = f.anim, t = f.clock, e = f.ext || 0, s = Math.sin(t * 0.1) * 1.2;
    const P = { hx: 0, hy: -31, sx: 1, sy: -53, dx: 1, dy: -61, hf: [13, -47], hb: [7, -44], ff: [10, 0], fb: [-9, 0] };
    const crouch = () => { P.hy = -17; P.sy = -38; P.sx = 3; P.dy = -46; P.dx = 4; P.ff = [13, 0]; P.fb = [-9, 0]; P.hf = [16, -34]; P.hb = [9, -31]; };
    switch (a) {
      case 'idle': P.sy += s * 0.5; P.dy += s * 0.5; P.hf[1] += s * 0.5; P.hb[1] += s * 0.5; break;
      case 'walk': { const w = Math.sin(t * 0.3 * (f.walkDir || 1)), c = Math.cos(t * 0.3); P.ff = [10 + w * 12, -Math.max(0, -c) * 5]; P.fb = [-10 - w * 12, -Math.max(0, c) * 5]; P.hy -= Math.abs(w); P.hf = [12 + w * 3, -46]; P.hb = [6 - w * 3, -44]; break; }
      case 'run': { const w = Math.sin(t * 0.5), c = Math.cos(t * 0.5); P.sx = 7; P.dx = 9; P.hx = 2; P.ff = [14 + w * 14, -Math.max(0, -c) * 9]; P.fb = [-10 - w * 14, -Math.max(0, c) * 9]; P.hf = [8 - w * 8, -42]; P.hb = [4 + w * 8, -42]; break; }
      case 'crouch': crouch(); break;
      case 'jump': P.ff = [9, -12]; P.fb = [-7, -6]; P.hf = [14, -50]; P.hb = [6, -46]; break;
      case 'fly': P.sx = 8; P.dx = 10; P.ff = [-10, -6]; P.fb = [-16, -10]; P.hf = [32, -50]; P.hb = [28, -46]; break;
      case 'block': P.hf = [14, -55]; P.hb = [11, -49]; P.sx = -1; P.dx = -1; break;
      case 'cblock': crouch(); P.hf = [15, -43]; P.hb = [11, -38]; break;
      case 'hit': P.sx = -4; P.dx = -5; P.hf = [2, -42]; P.hb = [-4, -40]; break;
      case 'down': P.hx = -16; P.hy = -7; P.sx = 6; P.sy = -9; P.dx = 18; P.dy = -9; P.ff = [-34, -3]; P.fb = [-30, -8]; P.hf = [22, -4]; P.hb = [-2, -3]; break;
      case 'broken': P.hx = -14; P.hy = -8; P.sx = 7; P.sy = -4; P.dx = 14; P.dy = -16; P.ff = [-10, -24]; P.fb = [-36, -3]; P.hf = [-8, -16]; P.hb = [26, -22]; break;
      case 'lp': P.sx += e * 3; P.hf = [14 + e * 24, -50]; break;
      case 'hp': P.hx += e * 3; P.sx += e * 7; P.dx += e * 7; P.hf = [14 + e * 28, -51]; P.ff = [16, 0]; P.fb = [-10, 0]; break;
      case 'clp': crouch(); P.hf = [16 + e * 22, -35]; break;
      case 'chp': crouch(); P.hy -= e * 9; P.sy -= e * 12; P.dy -= e * 12; P.hf = [14 + e * 10, -38 - e * 42]; break;
      case 'lk': P.sx = -3 * e; P.ff = [12 + e * 26, -22 - e * 8]; break;
      case 'hk': P.sx = -5 * e; P.dx = -5 * e; P.ff = [12 + e * 32, -40 - e * 8]; break;
      case 'clk': crouch(); P.ff = [16 + e * 28, -6]; break;
      case 'chk': P.hy = -11; P.sy = -30; P.sx = -2; P.dx = 0; P.dy = -38; P.ff = [14 + e * 36, -3]; P.fb = [-14, 0]; P.hf = [10, -26]; P.hb = [-4, -24]; break;
      case 'alp': P.ff = [9, -12]; P.fb = [-7, -6]; P.hf = [14 + e * 22, -44]; break;
      case 'alk': P.fb = [-7, -8]; P.ff = [10 + e * 26, -14]; P.hf = [14, -50]; break;
      case 'grab': P.sx = 3; P.dx = 4; P.hf = [24, -48]; P.hb = [22, -42]; break;
      case 'cast': P.hf = [22, -52 + Math.sin(t * 0.8)]; P.hb = [20, -48]; P.ff = [12, 0]; P.fb = [-12, 0]; break;
      case 'raise': P.hf = [8, -84]; P.hb = [2, -82]; break;
      case 'point': P.sx = 3; P.hf = [30, -54]; P.hb = [6, -42]; break;
      case 'shoot': P.sx = 2; P.hf = [27, -52]; P.hb = [23, -49]; P.ff = [12, 0]; P.fb = [-10, 0]; break;
      case 'dance': { const w = Math.sin(t * 0.4); P.hx = w * 3; P.sx = -w * 2; P.hf = [14 + w * 8, -70 + Math.abs(w) * 12]; P.hb = [-4 - w * 8, -64 + Math.abs(w) * 12]; P.ff = [10 + w * 4, -Math.max(0, w) * 6]; P.fb = [-10 + w * 4, -Math.max(0, -w) * 6]; break; }
      case 'dizzy': { const w = Math.sin(t * 0.2); P.sx = w * 4; P.dx = w * 6; P.dy = -59; P.hf = [4, -34]; P.hb = [-2, -33]; break; }
      case 'win': P.hf = [8, -82]; P.hb = [10, -36]; break;
      case 'kneel': P.hx = -4; P.hy = -16; P.sx = 3; P.sy = -38; P.dx = 5; P.dy = -46; P.ff = [12, 0]; P.fb = [-20, -2]; P.hf = [8, -22]; P.hb = [-2, -20]; break;
      case 'pound': P.sx = 2 + e * 6; P.hy = -31 + e * 4; P.dx = 3 + e * 7; P.hf = [10 + e * 20, -84 + e * 62]; P.hb = [6 + e * 18, -82 + e * 60]; break;
      case 'taunt': P.hf = [12, -60]; P.hb = [-6, -34]; break;
    }
    return P;
  };

  // calopsita de desenho (original): (x,y) = base do corpo; s = escala; front = olhando p/ frente (+x)
  function calop(c, x, y, s, front) {
    c.save(); c.translate(x, y); c.scale(s, s);
    const G1 = '#b9bec9', G2 = '#8a91a1', Y = '#ffd84a', O = '#ff8a2a';
    R(c, -10, -4, 7, 2, OUT); R(c, -9, -4, 6, 1, G2); R(c, -9, -3, 5, 1, G1); // cauda
    R(c, -6, -8, 12, 8, OUT); R(c, -5, -7, 10, 6, G1); R(c, -5, -3, 8, 2, sh(G1, 0.25)); R(c, -5, -6, 4, 4, G2); R(c, -4, -5, 2, 1, sh(G2, 0.2)); // corpo + asa
    R(c, 1, -12, 7, 7, OUT); R(c, 2, -11, 5, 5, Y); R(c, 2, -9, 2, 2, O); R(c, 4, -10, 1, 1, '#111'); R(c, 6, -8, 2, 1, '#d8c9a8'); // cabeça
    R(c, 1, -16, 2, 5, OUT); R(c, 2, -15, 1, 4, Y); R(c, 3, -17, 2, 6, OUT); R(c, 4, -16, 1, 5, Y); R(c, 5, -15, 2, 4, OUT); R(c, 5, -14, 1, 3, Y); // crista
    R(c, -2, 0, 1, 2, '#a89c88'); R(c, 2, 0, 1, 2, '#a89c88');
    c.restore();
  }
  function cape(c, Lk, P, f) {
    const pal = Lk.pal, A = pal.cape || '#1d7f86', Dk = pal.capeD || sh(A, -0.3), T = pal.capeT || '#ffd84a', sw = Math.sin((f.clock || 0) * 0.1) * 1.5 + ((f.vx || 0) * -0.6);
    const top = P.sy + 1, bot = -3; let ex = 0, ey = 0;
    for (let y = top; y < bot; y += 2) {
      const t = (y - top) / (bot - top), cx = P.sx + (P.hx - P.sx) * t - 5 - t * 9 + t * t * sw, hw = 8 + t * 13;
      R(c, cx - hw / 2 - 1, y, hw + 2, 2, OUT); R(c, cx - hw / 2, y, hw, 2, t > 0.55 ? Dk : A); R(c, cx - hw / 2, y, 2, 2, sh(A, 0.18));
      if (Math.abs(t - 0.4) < 0.06) { ex = cx; ey = y; }
    }
    const t1 = 1, cx1 = P.sx + (P.hx - P.sx) * t1 - 5 - 9 + sw, hw1 = 19;
    for (let i = 0; i < 7; i++) { const w = 3, xx = cx1 - hw1 / 2 + i * 3; R(c, xx, bot - 3, w, 3, OUT); R(c, xx, bot - 3, w - (i % 2 ? 1 : 0), 2, T); R(c, xx, bot - 1 + (i % 2), w - 1, 2, i % 2 ? T : sh(T, -0.2)); }
    R(c, P.sx - 3, P.sy - 1, 8, 3, OUT); R(c, P.sx - 2, P.sy, 6, 2, T); // gola dourada
    calop(c, ex - 1, ey + 12, 1.6, 0);
  }

  // ---------- cabeça / cabelo ----------
  function head(c, x, y, Lk, o) {
    const pal = Lk.pal, skin = pal.skin, st = Lk.hs, hc = pal.hair || '#222';
    c.save();
    if (Lk.child || o.big) { c.translate(x, y); c.scale(1.35, 1.35); c.translate(-x, -y); }
    const ape = Lk.flags.includes('ape'), rat = Lk.flags.includes('rat');
    R(c, x - 6, y - 7, 12, 13, OUT); R(c, x - 5, y - 6, 10, 11, skin); R(c, x - 5, y + 3, 10, 2, sh(skin, -0.14)); R(c, x + 3, y - 5, 2, 8, sh(skin, -0.12)); R(c, x - 5, y - 5, 2, 2, sh(skin, 0.16)); R(c, x - 5, y - 1, 2, 3, sh(skin, -0.2)); R(c, x - 4, y + 4, 8, 1, sh(skin, -0.28));
    if (ape) {
      R(c, x - 7, y - 5, 3, 6, OUT); R(c, x - 6, y - 4, 2, 4, '#c79a68'); R(c, x + 1, y - 1, 6, 6, OUT); R(c, x + 1, y, 5, 5, '#c79a68'); R(c, x - 5, y - 8, 11, 4, '#3b2210'); R(c, x - 3, y - 3, 7, 2, '#3b2210');
      R(c, x + 1, y - 2, 2, 2, '#fff'); R(c, x + 4, y - 2, 2, 2, '#fff'); R(c, x + 2, y - 1, 1, 1, '#111'); R(c, x + 5, y - 1, 1, 1, '#111'); R(c, x + 2, y + 3, 4, 1, '#3a1a10'); R(c, x + 5, y + 1, 1, 1, '#2a120a');
      c.restore(); return;
    }
    if (rat) {
      R(c, x - 5, y - 11, 6, 6, OUT); R(c, x - 4, y - 10, 4, 4, '#e7a3b6'); R(c, x + 1, y - 11, 6, 6, OUT); R(c, x + 2, y - 10, 4, 4, '#e7a3b6');
      R(c, x + 4, y - 1, 8, 6, OUT); R(c, x + 4, y, 7, 4, skin); R(c, x + 10, y, 2, 2, '#e0457b');
      L(c, x + 9, y + 3, x + 15, y + 1, 1, '#ddd'); L(c, x + 9, y + 4, x + 15, y + 5, 1, '#ddd');
      R(c, x - 1, y - 4, 5, 4, '#ff6b35'); R(c, x + 4, y - 4, 5, 4, '#2ec4ff'); R(c, x - 1, y - 4, 10, 1, '#111'); R(c, x, y - 3, 2, 1, '#fff'); R(c, x + 5, y - 3, 2, 1, '#fff');
      R(c, x + 1, y + 4, 4, 1, '#fff'); c.restore(); return;
    }
    // olhos e rosto
    const ew = Lk.eyesWhite;
    if (ew) { R(c, x - 1, y - 3, 3, 3, '#ffffff'); R(c, x + 3, y - 3, 3, 3, '#ffffff'); c.globalAlpha = 0.35; R(c, x - 3, y - 4, 10, 5, '#ffffff'); c.globalAlpha = 1; }
    else { R(c, x - 1, y - 3, 3, 3, '#f2f2ee'); R(c, x + 3, y - 3, 3, 3, '#f2f2ee'); R(c, x + 1, y - 3, 1, 3, '#161616'); R(c, x + 5, y - 3, 1, 3, '#161616'); R(c, x - 2, y - 5, 4, 1, sh(hc, -0.3)); R(c, x + 3, y - 5, 4, 1, sh(hc, -0.3)); }
    R(c, x + 5, y, 1, 2, sh(skin, -0.2)); R(c, x + 2, y + 3, 3, 1, '#7a2a2a');
    if (o.mouth) R(c, x + 2, y + 3, 3, 3, '#3a0a0a');
    if (o.hurt) { R(c, x + 1, y - 3, 1, 1, '#fff'); }
    // cabelo
    const l1 = sh(hc, 0.22), d1 = sh(hc, -0.3);
    switch (st) {
      case 'short': R(c, x - 6, y - 9, 12, 5, hc); R(c, x - 6, y - 5, 2, 5, hc); R(c, x - 4, y - 9, 6, 1, l1); break;
      case 'volume': R(c, x - 6, y - 12, 12, 1, hc); R(c, x - 7, y - 11, 14, 7, hc); R(c, x - 7, y - 5, 3, 6, hc); R(c, x - 5, y - 11, 7, 1, l1); R(c, x - 7, y - 5, 3, 1, d1); break;
      case 'curly': R(c, x - 7, y - 9, 14, 5, hc); for (let i = 0; i < 5; i++) R(c, x - 7 + i * 3, y - 11 + (i % 2), 4, 4, hc); R(c, x - 7, y - 5, 3, 6, hc); R(c, x - 5, y - 10, 3, 1, l1); break;
      case 'crespo': R(c, x - 8, y - 11, 15, 8, hc); R(c, x - 6, y - 13, 4, 3, hc); R(c, x, y - 13, 5, 3, hc); R(c, x - 8, y - 4, 3, 5, hc); R(c, x - 4, y - 12, 3, 1, l1); R(c, x + 3, y - 4, 4, 1, hc); break;
      case 'surfer': R(c, x - 6, y - 9, 12, 4, hc); R(c, x - 9, y - 8, 5, 13, hc); R(c, x + 1, y - 7, 6, 2, hc); R(c, x - 5, y - 9, 6, 1, l1); R(c, x - 9, y + 3, 5, 2, d1); break;
      case 'cap': { const cp = pal.cap || '#0d0d10', ct = pal.capTrim || '#d4a82b'; R(c, x - 7, y - 6, 3, 8, hc); R(c, x - 7, y - 11, 15, 6, cp); R(c, x + 3, y - 6, 10, 2, cp); R(c, x - 7, y - 6, 15, 1, ct); R(c, x + 2, y - 10, 3, 2, ct); }  R(c, x - 5, y - 10, 4, 1, '#2a2a32'); break;
      case 'police': R(c, x - 7, y - 11, 15, 6, '#1d2b4d'); R(c, x + 2, y - 6, 10, 2, '#06080f'); R(c, x - 7, y - 7, 15, 1, '#c9a227'); R(c, x, y - 10, 3, 3, '#c9a227'); R(c, x - 5, y - 10, 4, 1, '#34497f'); break;
      case 'bandana': R(c, x - 8, y - 12, 15, 6, hc); R(c, x - 6, y - 14, 4, 3, hc); R(c, x, y - 14, 5, 3, hc); R(c, x - 6, y - 7, 13, 3, '#121214'); R(c, x - 10, y - 6, 4, 4, '#121214'); R(c, x - 12, y - 3, 3, 4, '#121214'); R(c, x - 8, y - 4, 3, 7, hc); break;
    }
    const ex = Lk.extras;
    if (ex.includes('headband')) { R(c, x - 6, y - 7, 12, 2, OUT); R(c, x - 6, y - 6, 12, 1, pal.band || '#e6c14a'); R(c, x - 11, y - 6, 5, 1, OUT); R(c, x - 13, y - 4, 4, 1, pal.band || '#e6c14a'); R(c, x - 10, y - 6, 4, 1, pal.band || '#e6c14a'); }
    if (ex.includes('hood')) { const hd = pal.top || '#2a1d52', hl = sh(hd, 0.2); R(c, x - 9, y - 13, 18, 7, OUT); R(c, x - 8, y - 12, 16, 6, hd); R(c, x - 6, y - 12, 8, 1, hl); R(c, x - 9, y - 6, 5, 11, OUT); R(c, x - 8, y - 6, 4, 10, hd); R(c, x - 12, y - 3, 4, 7, OUT); R(c, x - 11, y - 2, 3, 5, sh(hd, -0.2)); R(c, x - 1, y - 4, 8, 3, OUT); R(c, x, y - 3, 6, 1, pal.neon || '#39ff88'); c.globalAlpha = 0.35; R(c, x - 2, y - 5, 10, 5, pal.neon || '#39ff88'); c.globalAlpha = 1; }
    if (ex.includes('brimhat')) { const hh = pal.hat || '#fff', hb = pal.hatBand || '#1f4fa8'; R(c, x - 7, y - 16, 14, 9, OUT); R(c, x - 6, y - 15, 12, 7, hh); R(c, x - 6, y - 15, 12, 1, sh(hh, -0.04)); R(c, x + 2, y - 15, 4, 6, sh(hh, -0.12)); R(c, x - 6, y - 10, 12, 2, hb); R(c, x - 12, y - 8, 24, 4, OUT); R(c, x - 11, y - 8, 22, 2, hh); R(c, x - 11, y - 6, 22, 1, sh(hh, -0.18)); }
    if (ex.includes('calop')) calop(c, x - 1, y - 9, 1, 1);
    if (Lk.flags.includes('spiky')) { for (let i = 0; i < 6; i++) R(c, x - 7 + i * 3, y - 13 - [4, 9, 13, 11, 8, 4][i], 3, 6 + [4, 9, 13, 11, 8, 4][i], Lk.pal.hair); R(c, x - 7, y - 9, 14, 4, Lk.pal.hair); }
    c.restore();
  }


  // ---------- membros / tronco com sombreado (estilo MUGEN) ----------
  function limb(c, x0, y0, x1, y1, t0, t1, col, bulge) {
    const dx = x1 - x0, dy = y1 - y0, d = Math.max(Math.abs(dx), Math.abs(dy), 1), len = Math.hypot(dx, dy) || 1; bulge = bulge || 0;
    let nx = -dy / len, ny = dx / len; if (nx + ny < 0) { nx = -nx; ny = -ny; }
    const T = u => t0 + (t1 - t0) * u + bulge * Math.sin(u * Math.PI);
    c.fillStyle = OUT; for (let i = 0; i <= d; i++) { const u = i / d, s = Math.round(T(u)) + 2; c.fillRect(Math.round(x0 + dx * u - s / 2), Math.round(y0 + dy * u - s / 2), s, s); }
    c.fillStyle = col; for (let i = 0; i <= d; i++) { const u = i / d, s = Math.round(T(u)); c.fillRect(Math.round(x0 + dx * u - s / 2), Math.round(y0 + dy * u - s / 2), s, s); }
    c.fillStyle = sh(col, -0.3); for (let i = 0; i <= d; i++) { const u = i / d, h = T(u) / 2 - 1.5; c.fillRect(Math.round(x0 + dx * u + nx * h - 0.5), Math.round(y0 + dy * u + ny * h - 0.5), 2, 2); }
    c.fillStyle = sh(col, 0.22); for (let i = 0; i <= d; i++) { const u = i / d, h = T(u) / 2 - 1; c.fillRect(Math.round(x0 + dx * u - nx * h), Math.round(y0 + dy * u - ny * h), 1, 1); }
  }
  function torso(c, hip, sd, tw, col, o) {
    const n = Math.max(2, Math.round(Math.hypot(sd[0] - hip[0], sd[1] - hip[1]))); o = o || {};
    const W_ = u => tw * (0.8 + 0.34 * Math.sin(Math.min(1, u * 1.1) * Math.PI / 2)), dk = sh(col, -0.25), lt = sh(col, 0.2);
    for (let i = 0; i <= n; i++) { const u = i / n, cx = hip[0] + (sd[0] - hip[0]) * u, y = hip[1] + (sd[1] - hip[1]) * u, w = Math.round(W_(u)); R(c, cx - w / 2 - 1, y, w + 2, 2, OUT); }
    for (let i = 0; i <= n; i++) { const u = i / n, cx = hip[0] + (sd[0] - hip[0]) * u, y = hip[1] + (sd[1] - hip[1]) * u, w = Math.round(W_(u)), x = Math.round(cx - w / 2); R(c, x, y, w, 1, col); R(c, x, y, 2, 1, lt); R(c, x + w - 3, y, 3, 1, dk); }
    R(c, sd[0] - tw / 2, sd[1], tw, 1, lt);
    if (o.pec) { const py = sd[1] + 7, w = Math.round(tw * 0.95); R(c, sd[0] - w / 2 + 1, py, w - 2, 1, dk); R(c, sd[0], sd[1] + 2, 1, 5, dk); }
    if (!o.skin) { R(c, hip[0] - tw / 2 + 2, hip[1] - 9, 1, 4, dk); R(c, hip[0] + 1, hip[1] - 14, 2, 1, dk); R(c, hip[0] + tw / 2 - 4, hip[1] - 12, 1, 3, lt); }
  }
  function fist(c, x, y, skin, dk) {
    R(c, x - 3, y - 3, 7, 7, OUT); R(c, x - 2, y - 2, 5, 5, sh(skin, dk)); R(c, x - 2, y - 2, 5, 1, sh(skin, dk + 0.25)); R(c, x + 1, y - 1, 1, 4, sh(skin, dk - 0.2)); R(c, x - 1, y, 1, 3, sh(skin, dk - 0.12)); R(c, x - 2, y + 2, 5, 1, sh(skin, dk - 0.25));
  }
  function shoe(c, x, y, col, dk) {
    const sc = sh(col, dk); R(c, x - 4, y - 6, 13, 6, OUT); R(c, x - 3, y - 5, 11, 4, sc); R(c, x - 3, y - 5, 11, 1, sh(sc, 0.3)); R(c, x + 4, y - 4, 4, 3, sh(sc, 0.12)); R(c, x - 3, y - 1, 12, 1, '#e8e4dc'); R(c, x - 3, y - 2, 4, 1, sh(sc, -0.3));
  }

  // ---------- figura completa ----------
  function figure(c, f, Lk, P, o = {}) {
    const pal = Lk.pal, skin = pal.skin, has = k => Lk.flags.includes(k);
    const longP = ['toddy', 'matheus', 'luan', 'rafael'].includes(Lk.id) || Lk.form === 'luan' || !!pal.long;
    const longS = !!pal.sleeve || has('jacket') || has('coat') || has('suit') || has('police') || has('dress');
    const wide = Lk.wide || 1, tw = Math.round(13 * Math.min(wide, 1.45) + (has('belly') ? 3 : 0));
    const topC = has('shirtless') ? skin : (pal.top || skin), sleeveC = pal.sleeve ? pal.sleeve : has('jacket') ? (pal.jacket || '#151515') : has('police') ? '#1d2b4d' : has('suit') ? (Lk.form === 'matheus' ? pal.top : (pal.top === '#f8f8f8' ? '#f8f8f8' : '#141414')) : has('coat') ? (pal.coat || '#101012') : has('dress') ? '#f7f7f7' : null;
    const bot = pal.bottom || '#161616', shoes = pal.shoes || '#222';
    const th = Math.round(6 * Math.min(wide, 1.35)), hip = [P.hx, P.hy], shd = [P.sx, P.sy + 3];
    if (!o.bust) {
      if (Lk.extras.includes('wings')) wings(c, Lk, P, f);
      if (Lk.extras.includes('cape')) cape(c, Lk, P, f);
      // braço de trás
      arm(c, shd, P.hb, th, Lk, topC, sleeveC, longS, true);
      // perna de trás
      leg(c, [hip[0] - 2, hip[1]], P.fb, th + 2, bot, skin, shoes, longP, Lk);
      if (has('coat')) coatBack(c, P, pal);
    }
    // tronco
    const tc = o.bust ? topC : topC;
    torso(c, hip, [P.sx, P.sy + 2], tw, tc, { pec: has('shirtless') || has('muscle'), skin: has('shirtless') });
    if (has('shirtless') || has('muscle')) { // peitoral / abdômen
      const sc2 = sh(skin, -0.18); R(c, P.sx + 1, P.sy + 5, 1, 12, sc2); for (let i = 0; i < 3; i++) R(c, P.sx - 1, P.sy + 10 + i * 4, 5, 1, sc2); R(c, P.sx - 3, P.sy + 3, 8, 1, sc2);
    }
    if (has('belly')) { R(c, P.sx + 2, P.hy - 12, 9, 12, OUT); R(c, P.sx + 3, P.hy - 11, 7, 10, topC); }
    if (has('tank')) { R(c, P.sx - 4, P.sy, 3, 5, skin); R(c, P.sx + 2, P.sy, 3, 5, skin); }
    if (has('jacket')) { const j = pal.jacket || '#151515'; L(c, hip[0] - 3, hip[1], P.sx - 3, P.sy, 4, j); L(c, hip[0] + 5, hip[1], P.sx + 5, P.sy, 3, j); R(c, P.sx - 4, P.sy - 2, 11, 3, j); }
    if (has('suit') && Lk.form !== 'luan') { const j = pal.top === '#f8f8f8' ? '#ffffff' : '#141414'; L(c, hip[0] - 3, hip[1], P.sx - 3, P.sy, 3, sh(j, -0.1)); L(c, hip[0] + 5, hip[1], P.sx + 5, P.sy, 3, sh(j, -0.1)); R(c, P.sx, P.sy + 1, 3, 12, pal.shirt || '#fafafa'); if (pal.tie) R(c, P.sx + 1, P.sy + 2, 2, 11, pal.tie); else if (pal.shirt) { R(c, P.sx, P.sy + 1, 3, 3, '#fafafa'); } }
    if (Lk.form === 'luan') { R(c, P.sx, P.sy + 1, 3, 12, '#fafafa'); R(c, P.sx + 1, P.sy + 2, 2, 11, pal.tie); }
    if (Lk.extras.includes('spider')) spiderSuit(c, hip, [P.sx, P.sy + 2], tw, pal);
    if (Lk.extras.includes('gi')) giTop(c, P, pal);
    if (Lk.extras.includes('neon')) { const nc = pal.neon || '#39ff88'; R(c, P.sx + 1, P.sy + 3, 1, 14, nc); R(c, P.sx - 3, P.sy + 4, 3, 1, nc); R(c, P.sx + 3, P.sy + 8, 3, 1, nc); L(c, hip[0] - 2, hip[1] - 2, P.hb[0], P.hb[1] - 6, 1, nc); }
    if (has('police')) { L(c, hip[0], hip[1], P.sx, P.sy, tw - 2, pal.vest || '#10151f'); R(c, P.sx + 2, P.sy + 5, 3, 3, '#c9a227'); R(c, P.sx - 4, P.hy - 1, tw + 6, 2, '#0a0a0a'); }
    if (has('dress')) { R(c, P.sx + 1, P.sy + 1, 1, 14, '#cfcfcf'); R(c, P.sx - 2, P.sy - 1, 7, 2, '#ffffff'); }
    if (has('jersey')) { R(c, P.sx - 4, P.sy - 2, 11, 2, pal.trim || '#1f9d3a'); R(c, P.sx + 1, P.sy + 4, 2, 5, '#1f9d3a'); }
    if (has('heart')) { const hx = P.sx + 2, hy = P.sy + 9; R(c, hx - 2, hy - 2, 2, 2, '#ff2d6f'); R(c, hx + 1, hy - 2, 2, 2, '#ff2d6f'); R(c, hx - 2, hy, 5, 2, '#ff2d6f'); R(c, hx - 1, hy + 2, 3, 1, '#ff2d6f'); }
    // short / calça (quadril)
    if (!o.bust) { R(c, hip[0] - 7, hip[1] - 4, 15, 8, OUT); R(c, hip[0] - 6, hip[1] - 3, 13, 6, bot); R(c, hip[0] - 6, hip[1] - 3, 13, 1, sh(bot, 0.25)); R(c, hip[0] + 3, hip[1] - 2, 4, 5, sh(bot, -0.25)); R(c, hip[0] - 1, hip[1], 1, 4, sh(bot, -0.3)); }
    if (!o.bust) leg(c, [hip[0] + 2, hip[1]], P.ff, th + 2, bot, skin, shoes, longP, Lk);
    if (has('coat')) coatFront(c, P, pal);
    if (Lk.extras.includes('belt')) { const bc = pal.belt || '#e6c14a'; R(c, hip[0] - 7, hip[1] - 6, 15, 4, OUT); R(c, hip[0] - 6, hip[1] - 5, 13, 2, bc); R(c, hip[0] + 1, hip[1] - 6, 4, 4, '#fff3b0'); }
    if (Lk.extras.includes('gi')) { const ob = pal.obi || '#1f3d8f'; R(c, hip[0] - 7, hip[1] - 6, 15, 4, OUT); R(c, hip[0] - 6, hip[1] - 5, 13, 2, ob); R(c, hip[0] - 6, hip[1] - 5, 13, 1, sh(ob, 0.25)); R(c, hip[0] - 4, hip[1] - 4, 3, 3, OUT); R(c, hip[0] - 3, hip[1] - 3, 2, 1, ob); L(c, hip[0] - 3, hip[1] - 2, hip[0] - 6, hip[1] + 6, 3, OUT); L(c, hip[0] - 3, hip[1] - 2, hip[0] - 6, hip[1] + 6, 1, ob); }
    if (Lk.extras.includes('sash')) { L(c, P.sx - 4, P.sy + 2, P.hx + 5, P.hy - 2, 5, OUT); L(c, P.sx - 4, P.sy + 2, P.hx + 5, P.hy - 2, 3, '#2fd06b'); L(c, P.sx - 3, P.sy + 3, P.hx + 4, P.hy - 1, 1, '#f3d54a'); }
    if (Lk.extras.includes('jersey') && !has('jersey')) { R(c, P.sx - 3, P.sy + 1, 8, 4, '#f1d32e'); }
    // pescoço e cabeça
    if (!o.noHead && !Lk.flags.includes('ape')) { R(c, P.dx - 3, P.dy + 3, 7, P.sy - P.dy - 1, OUT); R(c, P.dx - 2, P.dy + 3, 5, P.sy - P.dy - 2, sh(Lk.pal.skin, -0.1)); R(c, P.dx + 1, P.dy + 4, 2, P.sy - P.dy - 4, sh(Lk.pal.skin, -0.25)); }
    if (!o.noHead) head(c, P.dx + (o.hx || 0), P.dy, Lk, o); else { R(c, P.dx - 3, P.dy + 3, 7, 4, '#8d0014'); }
    if (Lk.extras.includes('crest')) { for (let i = 0; i < 4; i++) { R(c, P.dx - 4 + i * 2, P.dy - 15 - (i === 1 || i === 2 ? 3 : 0) + (i === 0 ? 3 : 0), 2, 7, OUT); R(c, P.dx - 4 + i * 2, P.dy - 14 - (i === 1 || i === 2 ? 3 : 0) + (i === 0 ? 3 : 0), 2, 5, Lk.wing ? Lk.wing[0] : '#ffe066'); } }
    if (!o.bust) arm(c, shd, P.hf, th, Lk, topC, sleeveC, longS, false);
    if (o.gun) { for (const h of [P.hf, P.hb]) { R(c, h[0], h[1] - 2, 8, 4, OUT); R(c, h[0] + 1, h[1] - 1, 6, 2, '#6e7480'); R(c, h[0], h[1] + 1, 3, 4, '#3a3a44'); } }
  }
  function arm(c, s, h, th, Lk, topC, sleeve, longS, back) {
    const a = ik(s[0] + (back ? -2 : 2), s[1], h[0], h[1], 12, 12, 1), skin = Lk.pal.skin, mus = Lk.flags.includes('muscle') || Lk.flags.includes('shirtless');
    const pal = Lk.pal, uc = pal.upper || sleeve || (Lk.flags.includes('tank') || mus ? skin : (pal.top || skin));
    const dk = back ? -0.22 : 0, fc = longS && sleeve ? sleeve : skin, bu = mus ? 2 : 1;
    limb(c, s[0] + (back ? -2 : 2), s[1], a.x, a.y, th + 1, th, sh(uc, dk), bu);
    limb(c, a.x, a.y, a.hx, a.hy, th, th - 2, sh(fc, dk), mus ? 1 : 0);
    if (longS && sleeve && Lk.flags.includes('suit')) R(c, a.hx - 3, a.hy - 5, 6, 2, '#f4f4f4');
    if (pal.web) { // linhas de teia na manga
      const wc = sh(pal.web, dk), x0 = s[0] + (back ? -2 : 2), y0 = s[1];
      for (const [p0, p1] of [[[x0, y0], [a.x, a.y]], [[a.x, a.y], [a.hx, a.hy]]]) for (let u = 0.25; u < 0.95; u += 0.33) R(c, p0[0] + (p1[0] - p0[0]) * u - 1, p0[1] + (p1[1] - p0[1]) * u - 1, 3, 1, wc);
    }
    if (pal.wrist) { const wx = a.x + (a.hx - a.x) * 0.72, wy = a.y + (a.hy - a.y) * 0.72; R(c, wx - 3, wy - 3, 7, 6, OUT); R(c, wx - 2, wy - 2, 5, 4, sh(pal.wrist, dk)); R(c, wx - 2, wy - 2, 5, 1, sh(pal.wrist, dk + 0.25)); }
    fist(c, a.hx, a.hy, pal.glove || skin, dk);
  }
  function leg(c, hip, f, th, bot, skin, shoes, longP, Lk) {
    const k = ik(hip[0], hip[1], f[0], f[1], 15, 15, -1), mus = Lk.flags.includes('muscle');
    const dk = hip[0] < 0 ? -0.2 : 0;
    limb(c, hip[0], hip[1], k.x, k.y, th + 1, th, bot, mus ? 2 : 1);
    limb(c, k.x, k.y, k.hx, k.hy - 3, th, th - 2, longP ? bot : skin, mus ? 1 : 0);
    if (Lk.pal.boot) { // bota de cano alto com tira
      const bt = sh(Lk.pal.boot, dk), by = k.y + (k.hy - 3 - k.y) * 0.55;
      limb(c, k.x + (k.hx - k.x) * 0.55, by, k.hx, k.hy - 3, th - 1, th - 1, bt, 0);
      R(c, k.hx - 4, by - 2, 9, 3, OUT); R(c, k.hx - 3, by - 1, 7, 1, Lk.pal.bootBand || sh(bt, 0.3));
    } else if (longP) R(c, k.hx - 3, k.hy - 8, 8, 2, sh(bot, -0.3));
    shoe(c, k.hx - 1, k.hy, shoes, dk);
  }
  // traje de teia: laterais azuis, linhas de teia e aranha no peito (só roupa; a cabeça não recebe máscara)
  function spiderSuit(c, hip, sd, tw, pal) {
    const n = Math.max(2, Math.round(Math.hypot(sd[0] - hip[0], sd[1] - hip[1]))), wc = pal.web || '#2a0608', sc = pal.side || '#1f3f9e';
    const W_ = u => tw * (0.8 + 0.34 * Math.sin(Math.min(1, u * 1.1) * Math.PI / 2));
    for (let i = 0; i <= n; i++) {
      const u = i / n, cx = hip[0] + (sd[0] - hip[0]) * u, y = Math.round(hip[1] + (sd[1] - hip[1]) * u), w = Math.round(W_(u)), x = Math.round(cx - w / 2);
      if (u < 0.62) { R(c, x, y, 3, 1, sc); R(c, x + w - 3, y, 3, 1, sh(sc, -0.25)); }
      if (i % 4 === 2) R(c, x + (u < 0.62 ? 3 : 1), y, w - (u < 0.62 ? 6 : 2), 1, wc); // anéis da teia
    }
    for (const fx of [-0.25, 0.08, 0.38]) L(c, hip[0] + tw * fx, hip[1] - 4, sd[0] + tw * fx * 1.1, sd[1], 1, wc); // raios da teia
    const ax = sd[0] + 1, ay = sd[1] + 7; // aranha no peito
    R(c, ax - 1, ay - 2, 3, 5, '#0c0a10'); R(c, ax, ay - 3, 1, 1, '#0c0a10');
    for (const d of [-1, 1]) { R(c, ax + d * 2, ay - 3, 1, 2, '#0c0a10'); R(c, ax + d * 3, ay - 4, 1, 1, '#0c0a10'); R(c, ax + d * 2, ay + 1, 1, 2, '#0c0a10'); R(c, ax + d * 3, ay + 3, 1, 1, '#0c0a10'); R(c, ax + (d > 0 ? 2 : -3), ay, 2, 1, '#0c0a10'); }
  }
  // kimono: gola em V com a camisa azul por baixo e emblema redondo no peito
  function giTop(c, P, pal) {
    const u = pal.under || '#1f3d8f', x = P.sx, y = P.sy + 2;
    R(c, x - 3, y, 8, 2, u); R(c, x - 2, y + 2, 6, 2, u); R(c, x - 1, y + 4, 4, 2, u); R(c, x, y + 6, 2, 1, u);
    L(c, x - 3, y, x + 1, y + 7, 1, sh(pal.top, -0.3)); L(c, x + 5, y, x + 1, y + 7, 1, sh(pal.top, -0.3));
    R(c, x + 3, y + 7, 5, 5, OUT); R(c, x + 4, y + 8, 3, 3, '#f4f1e6'); R(c, x + 5, y + 8, 1, 3, '#1b1b26'); R(c, x + 4, y + 9, 3, 1, '#1b1b26');
  }
  function coatBack(c, P, pal) {
    for (let y = P.sy + 4; y < -6; y += 2) { const t = (y - P.sy) / (-6 - P.sy), hw = 7 + t * 6, cx = P.sx + (P.hx - P.sx) * t - 4 - t * 3; R(c, cx - hw / 2, y, hw, 2, pal.coatD || '#0c0c0f'); }
  }
  function coatFront(c, P, pal) {
    const g = pal.trim || '#d4a82b';
    for (let y = P.sy; y < -5; y += 2) { const t = (y - P.sy) / (-5 - P.sy), cx = P.sx + (P.hx - P.sx) * t + 1; R(c, cx - 5, y, 1, 2, OUT); R(c, cx - 4, y, 9, 2, pal.coat || '#17171c'); R(c, cx + 5, y, 1, 2, OUT); R(c, cx + 1, y, 1, 2, g); }
    R(c, P.hx - 7, -7, 15, 2, g); R(c, P.sx - 4, P.sy, 10, 2, g); R(c, P.sx - 4, P.sy, 3, 6, pal.coatD || '#111'); R(c, P.sx + 3, P.sy, 3, 6, pal.coatD || '#111');
  }
  function wings(c, Lk, P, f) {
    const w = Lk.wing || ['#ffe066', '#ddd'], fl = Math.sin(f.clock * 0.25) * 4;
    for (const [dx, dy, col] of [[-6, -6, w[1]], [-3, 0, w[0]]]) {
      c.fillStyle = OUT; c.beginPath(); c.moveTo(P.sx - 2, P.sy + 4); c.lineTo(P.sx - 24 + dx, P.sy - 18 + dy + fl); c.lineTo(P.sx - 18 + dx, P.sy + 14 + dy); c.closePath(); c.fill();
      c.fillStyle = col; c.beginPath(); c.moveTo(P.sx - 2, P.sy + 4); c.lineTo(P.sx - 22 + dx, P.sy - 16 + dy + fl); c.lineTo(P.sx - 16 + dx, P.sy + 12 + dy); c.closePath(); c.fill();
    }
  }
  S.figure = figure;

  // ---------- esqueleto / bola / efeitos de visual ----------
  function skeleton(c, P, alpha) {
    c.globalAlpha = alpha; const B = '#ece6d2', D = '#b9b29b';
    const hip = [P.hx, P.hy], sd = [P.sx, P.sy + 3];
    for (const [h, f] of [[P.hb, P.fb], [P.hf, P.ff]]) {
      const a = ik(sd[0], sd[1], h[0], h[1], 12, 12, 1), k = ik(hip[0], hip[1], f[0], f[1], 15, 15, -1);
      L(c, sd[0], sd[1], a.x, a.y, 3, OUT); L(c, sd[0], sd[1], a.x, a.y, 1, B); L(c, a.x, a.y, a.hx, a.hy, 3, OUT); L(c, a.x, a.y, a.hx, a.hy, 1, B);
      L(c, hip[0], hip[1], k.x, k.y, 3, OUT); L(c, hip[0], hip[1], k.x, k.y, 1, B); L(c, k.x, k.y, k.hx, k.hy, 3, OUT); L(c, k.x, k.y, k.hx, k.hy, 1, B); R(c, k.hx - 1, k.hy - 2, 7, 2, B);
    }
    L(c, hip[0], hip[1], P.sx, P.sy, 4, OUT); L(c, hip[0], hip[1], P.sx, P.sy, 2, B);
    for (let i = 0; i < 4; i++) { const t = 0.3 + i * 0.17, x = hip[0] + (P.sx - hip[0]) * t, y = hip[1] + (P.sy - hip[1]) * t; R(c, x - 5, y, 11, 2, OUT); R(c, x - 4, y, 9, 1, B); }
    R(c, hip[0] - 5, hip[1] - 2, 11, 4, D);
    const x = P.dx, y = P.dy; R(c, x - 6, y - 7, 12, 13, OUT); R(c, x - 5, y - 6, 10, 9, B); R(c, x - 4, y + 3, 8, 3, D);
    R(c, x - 3, y - 3, 3, 3, '#111'); R(c, x + 1, y - 3, 3, 3, '#111'); R(c, x, y + 1, 1, 2, '#111'); for (let i = 0; i < 4; i++) R(c, x - 3 + i * 2, y + 4, 1, 2, '#111');
    c.globalAlpha = 1;
  }
  S.skeleton = skeleton;
  function ball(c, f, r, o = {}) {
    const rot = f.clock * 0.12 * (f.face || 1), sq = 1 + Math.sin(f.clock * 0.3) * 0.04;
    c.save(); c.translate(0, -r); c.scale(1, sq);
    c.fillStyle = OUT; c.beginPath(); c.arc(0, 0, r + 2, 0, 6.283); c.fill();
    c.fillStyle = '#ffe14a'; c.beginPath(); c.arc(0, 0, r, 0, 6.283); c.fill();
    c.fillStyle = '#ffef8a'; c.beginPath(); c.arc(-r * 0.3, -r * 0.35, r * 0.45, 0, 6.283); c.fill();
    c.save(); c.rotate(Math.sin(rot) * 0.15);
    R(c, -r * 0.45, -r * 0.3, 3, 6, '#2a2000'); R(c, r * 0.2, -r * 0.3, 3, 6, '#2a2000');
    c.strokeStyle = '#2a2000'; c.lineWidth = 2; c.beginPath(); c.arc(0, r * 0.05, r * 0.55, 0.2, 2.9); c.stroke();
    c.restore(); c.restore();
  }
  S.ball = ball;

  // ---------- Guardião (espírito roxo) ----------
  S.guardian = function (c, x, y, face, pose, t, o = {}) {
    c.save(); c.translate(Math.round(x), Math.round(y)); c.scale(face, 1); if (o.alpha != null) c.globalAlpha = o.alpha;
    const gp = o.gp || {}, P = gp.P || '#7a3fc0', Pd = gp.Pd || '#4b2480', Pl = gp.Pl || '#a066e0', G = gp.G || '#e0b020', HD = gp.H || '#8d52d4', e = o.e || 0;
    const br = Math.sin(t * 0.08) * 1;
    const hip = [0, -36], sh2 = [0, -64 + br];
    // cabelo selvagem (atrás)
    for (let i = 0; i < 7; i++) { L(c, -2, -76 + br, -14 - i * 3, -74 + i * 7 - Math.sin(t * 0.1 + i) * 2, 3, i % 2 ? '#14091f' : '#0a0512'); }
    // pernas
    L(c, -5, -36, -7, 0, 8, OUT); L(c, -5, -36, -7, 0, 6, '#1c1230'); L(c, 5, -36, 9, 0, 8, OUT); L(c, 5, -36, 9, 0, 6, '#1c1230'); R(c, -12, -3, 9, 3, '#0a0512'); R(c, 6, -3, 10, 3, '#0a0512');
    // tronco musculoso
    for (let yy = -66; yy < -34; yy += 2) { const t2 = (yy + 66) / 32, hw = 14 - t2 * 6; R(c, -hw - 1, yy + br, hw * 2 + 2, 2, OUT); R(c, -hw, yy + br, hw * 2, 2, P); }
    R(c, -12, -64 + br, 24, 2, Pl); R(c, -1, -60 + br, 2, 20, Pd); for (let i = 0; i < 3; i++) { R(c, -7, -53 + i * 5 + br, 6, 1, Pd); R(c, 2, -53 + i * 5 + br, 6, 1, Pd); }
    R(c, -11, -38, 22, 3, G); R(c, -2, -38, 4, 5, '#fff3b0');
    if (o.sash) { L(c, -12, -62, 10, -38, 5, OUT); L(c, -12, -62, 10, -38, 3, '#2fd06b'); L(c, -11, -61, 11, -37, 1, '#f3d54a'); }
    // cabeça
    R(c, -7, -80 + br, 14, 14, OUT); R(c, -6, -79 + br, 12, 12, HD); R(c, -6, -69 + br, 12, 2, Pd);
    R(c, 0, -76 + br, 4, 2, '#ffe14a'); R(c, 4, -76 + br, 3, 2, '#ffe14a'); R(c, -5, -81 + br, 12, 3, '#0a0512'); R(c, -6, -75 + br, 13, 2, G);
    R(c, 1, -70 + br, 5, 1, '#1a0a2a'); R(c, 2, -69 + br, 1, 1, '#fff'); R(c, 4, -69 + br, 1, 1, '#fff');
    // braços
    const arm = (h, bend, col) => { const a = ik(-12 * (bend < 0 ? -1 : 1) * -1, sh2[1] + 3, h[0], h[1], 15, 15, 1); L(c, 10, sh2[1] + 3, a.x, a.y, 10, OUT); L(c, 10, sh2[1] + 3, a.x, a.y, 8, col); L(c, a.x, a.y, a.hx, a.hy, 10, OUT); L(c, a.x, a.y, a.hx, a.hy, 8, col); R(c, a.hx - 4, a.hy - 4, 9, 8, OUT); R(c, a.hx - 3, a.hy - 3, 7, 6, Pl); R(c, a.x - 4, a.y - 2, 8, 3, G); };
    let h1 = [16, -34], h2 = [12, -40];
    if (pose === 'punch') { const k = Math.sin(t * 1.2); h1 = [28 + k * 8, -52 + k * 2]; h2 = [28 - k * 8, -44 - k * 2]; }
    else if (pose === 'pound') { h1 = [8 + e * 14, -96 + e * 94]; h2 = [2 + e * 14, -94 + e * 92]; }
    else if (pose === 'grab') { h1 = [26, -56]; h2 = [24, -48]; }
    else if (pose === 'cross') { h1 = [10, -58]; h2 = [4, -52]; }
    arm(h2, 1, Pd); arm(h1, 1, P);
    c.restore();
  };

  // ---------- desenho principal ----------
  // ---------- sprites prontos (spritesheet em assets/, ver assets/sheets.js) ----------
  function pickFrame(f, sh) {
    const F = sh.frames, a = f.anim, t = f.clock | 0, e = f.ext || 0, vy = f.vy || 0;
    const has = n => F[n] && F[n].length;
    const by = (n, k) => F[n][Math.max(0, Math.min(F[n].length - 1, k | 0))];
    const prog = n => by(n, Math.floor(Math.min(0.999, Math.max(0, e)) * F[n].length));
    const loop = (n, per) => by(n, Math.floor(t / per) % F[n].length);
    const air = f.grounded === false;
    const lie = () => { const fr = has('hit') ? by('hit', 1) : by('block', 2); return { fr, rot: -1.5, lie: 1 }; };
    const down = () => { if (has('down')) return { fr: air ? by('down', vy < -1 ? 0 : 1) : by('down', (f.t || 0) > 6 ? 3 : 2) }; return lie(); };
    switch (a) {
      case 'idle': return { fr: loop('idle', 14) };
      case 'walk': return { fr: by('walk', [0, 1, 2, 1][Math.floor(t / 7) % 4]) };
      case 'run': case 'fly': return { fr: loop('run', 6) };
      case 'jump': return { fr: by('jump', vy < -4 ? 1 : vy < -1 ? 2 : vy < 1.5 ? 3 : 4) };
      case 'crouch': case 'cblock': case 'clp': case 'clk': case 'kneel': return { fr: by('crouch', 2) };
      case 'block': return { fr: by('block', 1) };
      case 'hit': return has('hit') ? { fr: by('hit', 1) } : { fr: by('block', 2) };
      case 'down': case 'broken': return down();
      case 'win': return has('win') ? { fr: loop('win', 12) } : { fr: loop('idle', 14), dy: -Math.abs(Math.sin(t * 0.15)) * 3 };
      case 'dance': case 'taunt': return has('win') ? { fr: loop('win', 10) } : { fr: loop('idle', 8), dy: -Math.abs(Math.sin(t * 0.3)) * 3 };
      case 'lp': return { fr: prog('lp') };
      case 'hp': case 'chp': return { fr: prog('hp') };
      case 'lk': case 'alk': return { fr: prog('lk') };
      case 'hk': case 'chk': return { fr: prog('hk') };
      case 'alp': return { fr: prog('lp') };
      case 'grab': case 'cast': return { fr: by('lp', 2) };
      case 'shoot': case 'point': case 'pound': return { fr: by('hp', 1) };
      case 'raise': return has('win') ? { fr: by('win', 2) } : { fr: by('lp', 3) };
      case 'dizzy': return { fr: has('hit') ? by('hit', 1) : by('block', 2), rot: Math.sin(t * 0.2) * 0.12 };
      default: return { fr: loop('idle', 14) };
    }
  }
  function spriteDraw(c, f, Lk) {
    const SS = RC.SHEETS && RC.SHEETS[Lk.id];
    if (!SS || Lk.form || Lk.skin || f.fusionId || Lk.ball) return false;
    if (!SS.im) { SS.im = new Image(); SS.im.src = SS.img; }
    if (!SS.im.complete || !SS.im.naturalWidth) return false;
    const p = pickFrame(f, SS), fr = p.fr; if (!fr) return false;
    const w = fr[2], h = fr[3], ax = fr[4];
    c.save(); c.translate(0, p.dy || 0);
    if (p.lie) { c.translate(Math.round(h * 0.45), -ax); c.rotate(p.rot); }
    else if (p.rot) c.rotate(p.rot);
    c.drawImage(SS.im, fr[0], fr[1], w, h, -ax, -h, w, h);
    c.restore(); return true;
  }

  let tmp = null;
  function bodyDraw(c, f, Lk) {
    const P = S.pose(f);
    if (Lk.ball) { ball(c, f, 20 * (f.scale ? 1 : 1)); return; }
    if (spriteDraw(c, f, Lk)) return;
    const o = { gun: f.gun, mouth: f.state === 'hit' || f.anim === 'win', hurt: f.state === 'hit' };
    if (f.vis && f.vis.mode === 'headless') { o.noHead = true; }
    figure(c, f, Lk, P, o);
  }
  S.drawFighter = function (c, f) {
    const vm = f.vis && f.vis.mode; if (vm === 'hidden' || vm === 'gone') return;
    const Lk = S.look(f); f.scale = Lk.scale; f.wide = Lk.wide >= 1.3 ? 1.2 : 1;
    const sc = Lk.scale, v = f.vis || {};
    // aura
    const aura = f.auraCol || (f.form || f.fusionId ? Lk.aura : null);
    if (aura) {
      c.save(); c.translate(Math.round(f.x), Math.round(f.y)); c.globalAlpha = 0.28 + Math.sin(f.clock * 0.2) * 0.08; c.fillStyle = aura;
      const w = 22 * sc * Math.min(Lk.wide, 1.4), h = 70 * sc; c.beginPath(); c.ellipse(0, -h / 2, w, h / 2 + 4, 0, 0, 6.283); c.fill(); c.globalAlpha = 0.5;
      for (let i = 0; i < 6; i++) { const ax = ((i * 37 + f.clock * 2.2) % 50) - 25, ay = -((f.clock * (2 + i % 3) + i * 23) % (h + 10)); R(c, ax * sc * 0.8, ay, 2, 10, aura); }
      c.restore();
    }
    // Guardião atrás
    const hasG = (Lk.id === 'toddy' && !Lk.ball) || (f.fusionId && ['artoddy', 'guiddy', 'vitoddy', 'kaddy'].includes(f.fusionId));
    if (hasG && f.gdn !== false && vm !== 'ragdoll') {
      const g = f.guard || { pose: 'idle', off: -22, e: 0 };
      S.guardian(c, f.x + f.face * g.off * (f.fusionId ? 1 : 1), f.y, f.face, g.pose, f.clock, { alpha: g.off < 0 ? 0.55 : 0.92, e: g.e, sash: f.fusionId === 'artoddy', gp: Lk.pal.gp });
    }
    c.save(); c.translate(Math.round(f.x), Math.round(f.y));
    if (vm === 'ragdoll') { c.translate(0, -30); c.rotate(v.rot || 0); c.translate(0, 30); }
    if (vm === 'burger') { RC.Draw.burger(c, 0, -20 * (v.s || 2), 2.2 * (v.s || 1), f.clock * 0.02); c.restore(); return; }
    if (v.sink) c.translate(0, v.sink);
    c.scale(f.face * sc, sc);
    const needTint = f.flash > 0 || vm === 'ash' || vm === 'drain' || f.frozen;
    if (vm === 'skeleton') { skeleton(c, S.pose(f), 1); c.restore(); return; }
    if (needTint) {
      if (!tmp) { tmp = document.createElement('canvas'); tmp.width = 260; tmp.height = 240; }
      const t2 = tmp.getContext('2d'); t2.setTransform(1, 0, 0, 1, 0, 0); t2.clearRect(0, 0, 260, 240); t2.imageSmoothingEnabled = false;
      t2.translate(130, 200); bodyDraw(t2, f, Lk);
      if (vm === 'drain') { t2.globalCompositeOperation = 'source-atop'; t2.fillStyle = `rgba(200,200,205,${0.2 + v.p * 0.6})`; t2.fillRect(-130, -200, 260, 240); }
      else if (vm === 'ash') { t2.globalCompositeOperation = 'source-atop'; t2.fillStyle = `rgba(20,14,10,${Math.min(1, v.p)})`; t2.fillRect(-130, -200, 260, 240); }
      else if (f.frozen) { t2.globalCompositeOperation = 'source-atop'; t2.fillStyle = 'rgba(120,130,200,.45)'; t2.fillRect(-130, -200, 260, 240); }
      else { t2.globalCompositeOperation = 'source-atop'; t2.fillStyle = 'rgba(255,255,255,.65)'; t2.fillRect(-130, -200, 260, 240); }
      c.drawImage(tmp, -130, -200);
      if (vm === 'drain') skeleton(c, S.pose(f), RC.clamp(v.p * 1.2 - 0.2, 0, 1));
    } else bodyDraw(c, f, Lk);
    if (vm === 'riddled' && v.holes) for (const h of v.holes) { R(c, h[0] - 1, h[1] - 1, 3, 3, '#3a0008'); R(c, h[0], h[1], 1, 1, '#d8142f'); }
    if (f.anim === 'dizzy' || f.state === 'dizzy') for (let i = 0; i < 3; i++) { const a = f.clock * 0.15 + i * 2.1; R(c, Math.cos(a) * 9 + 1, -76 + Math.sin(a) * 3, 3, 3, '#ffe14a'); }
    c.restore();
  };

  // retrato (busto) para menus e cutscenes
  S.portrait = function (c, id, x, y, w, h, o = {}) {
    const SS = RC.SHEETS && RC.SHEETS[id];
    if (SS && SS.portrait && !o.form && !(RC.Skins && RC.Skins.cur(id, o.skin))) {
      if (!SS.pim) { SS.pim = new Image(); SS.pim.src = SS.portrait; }
      if (SS.pim.complete && SS.pim.naturalWidth) {
        const iw = SS.pim.naturalWidth, ih = SS.pim.naturalHeight, k = Math.max(w / iw, h / ih), sw = w / k, ssh = h / k;
        c.save(); c.beginPath(); c.rect(x, y, w, h); c.clip(); c.imageSmoothingEnabled = true; c.imageSmoothingQuality = 'high';
        if (o.flip) { c.translate(x + w, y); c.scale(-1, 1); c.drawImage(SS.pim, (iw - sw) / 2, 0, sw, ssh, 0, 0, w, h); }
        else c.drawImage(SS.pim, (iw - sw) / 2, 0, sw, ssh, x, y, w, h);
        c.restore(); return;
      }
    }
    c.save(); c.beginPath(); c.rect(x, y, w, h); c.clip();
    const d = RC.DATA.characters[id] || RC.DATA.characters.arthur, col = d.color;
    const g = c.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, sh(col, -0.55)); g.addColorStop(1, sh(col, -0.15)); c.fillStyle = g; c.fillRect(x, y, w, h);
    c.globalAlpha = 0.2; for (let i = 0; i < 8; i++) { c.fillStyle = col; c.fillRect(x + ((i * 53) % w), y, 6, h); } c.globalAlpha = 1;
    const k = o.k || Math.max(1, h / 30), fake = { id, baseId: id, clock: o.t || 0, anim: 'idle', ext: 0, form: o.form || null, state: 'idle', face: 1, skinIdx: o.skin };
    const Lk = S.look(fake); const P = S.pose(fake), fl = o.flip ? -1 : 1;
    c.translate(x + w / 2 - P.dx * k * fl, y + h * 0.4 - P.dy * k + (o.dy || 0)); c.scale(fl * k, k);
    if (id === 'toddy') S.guardian(c, -24, 38, 1, 'idle', o.t || 0, { alpha: 0.5, gp: Lk.pal.gp });
    figure(c, fake, Lk, P, { bust: true });
    c.restore();
  };
})();
