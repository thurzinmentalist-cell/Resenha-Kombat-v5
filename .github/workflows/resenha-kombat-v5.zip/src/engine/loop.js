// Utilidades globais + loop de passo fixo (60 fps)
(function () {
  const RC = window.RC = window.RC || {};
  RC.W = 480; RC.H = 270; RC.GY = 232; RC.frame = 0;
  RC.clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  RC.rnd = (a, b) => a + Math.random() * (b - a);
  RC.ri = (a, b) => Math.floor(a + Math.random() * (b - a + 1));
  RC.pick = a => a[Math.floor(Math.random() * a.length)];
  RC.lerp = (a, b, t) => a + (b - a) * t;
  RC.overlap = (a, b) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
  const shc = new Map();
  RC.shade = (hex, a) => {
    if (!hex || hex[0] !== '#') return hex;
    const key = hex + a, hit = shc.get(key); if (hit) return hit;
    const out = RC.shade0(hex, a); if (shc.size > 4000) shc.clear(); shc.set(key, out); return out;
  };
  RC.shade0 = (hex, a) => {
    const n = parseInt(hex.slice(1), 16); let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    if (a < 0) { r *= 1 + a; g *= 1 + a; b *= 1 + a; } else { r += (255 - r) * a; g += (255 - g) * a; b += (255 - b) * a; }
    return '#' + [r, g, b].map(v => Math.round(RC.clamp(v, 0, 255)).toString(16).padStart(2, '0')).join('');
  };
  RC.Loop = {
    start(update, render) {
      let last = performance.now(), acc = 0; const step = 1000 / 60;
      function frame(now) {
        acc += Math.min(100, now - last); last = now; let n = 0;
        while (acc >= step && n < 4) { update(); acc -= step; n++; }
        if (n === 4) acc = 0;
        render(); requestAnimationFrame(frame);
      }
      requestAnimationFrame(frame);
    }
  };
})();
