// Controles de toque: analógico virtual (ou D-Pad), botões coloridos e editor de layout (arrastar, tamanho, opacidade).
// O analógico escreve em I.touch.l/r/u/d, o MESMO caminho das setas do teclado, então RESENHATALITY e golpes funcionam igual.
(function () {
  const RC = window.RC, I = RC.Input, KEY = 'rc_touch';
  const C = I.tcfg = { size: 1, opa: 0.9, stick: true, pos: {} };
  try { const s = JSON.parse(localStorage.getItem(KEY)); if (s && typeof s === 'object') { Object.assign(C, s); if (!C.pos) C.pos = {}; } } catch (e) { }
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(C)); } catch (e) { } };
  I.tsave = save; I.tEdit = false;
  const DEFS = [
    ['lp', 'SF', '#ff7a7a'], ['hp', 'SH', '#ff3b3b'], ['lk', 'CF', '#7ad0ff'], ['hk', 'CH', '#3a8aff'],
    ['grab', 'AGR', '#ffa23a'], ['special', 'ESP', '#ffe14a'], ['ultimate', 'ULT', '#d36bff'], ['transform', 'TRF', '#4adf7a'],
    ['fusion', 'FUS', '#ffffff'], ['aux', 'AUX', '#a8b2c8'], ['swap', 'TROCA', '#2fe0c8']
  ];
  // ícones desenhados (SVG inline): branco com detalhes na cor do botão
  const FIST = '<path class="w" d="M5 12V9.5a1.6 1.6 0 0 1 3.2 0V9a1.6 1.6 0 0 1 3.2 0v.4a1.6 1.6 0 0 1 3.2 0V10a1.6 1.6 0 0 1 3.2 0v5.2a5 5 0 0 1-5 5h-1.6a5 5 0 0 1-5-5z"/><path class="l" d="M8.2 11.6v2.4M11.4 11v3M14.6 11.6v2.4" />';
  const BOOT = '<path class="w" d="M7 3h6.4v9.4l5 2.2a2.2 2.2 0 0 1 1.3 2V20H5.5V3z"/><path class="a" d="M5.5 17h14.2v3H5.5z"/><path class="l" d="M7.5 6h4.4M7.5 9h4.4"/>';
  const BURST = '<polygon class="a" points="17.0,0.0 18.5,4.4 23.1,3.5 20.0,7.0 23.1,10.5 18.5,9.6 17.0,14.0 15.5,9.6 10.9,10.5 14.0,7.0 10.9,3.5 15.5,4.4"/>';
  const ICON = {
    lp: '<svg viewBox="0 0 24 24">' + FIST + '</svg>',
    hp: '<svg viewBox="0 0 24 24"><g transform="translate(-1.5 3) scale(.82)">' + FIST + '</g>' + BURST + '</svg>',
    lk: '<svg viewBox="0 0 24 24">' + BOOT + '</svg>',
    hk: '<svg viewBox="0 0 24 24"><g transform="translate(-1.5 3) scale(.82)">' + BOOT + '</g>' + BURST + '</svg>',
    grab: '<svg viewBox="0 0 24 24"><path class="w" d="M6.5 21v-5.5L4.6 12l1.5-1 1.9 2.3V5.5a1.3 1.3 0 0 1 2.6 0V11h.6V4.6a1.3 1.3 0 0 1 2.6 0V11h.6V5.6a1.3 1.3 0 0 1 2.6 0V12h.6V8.4a1.3 1.3 0 0 1 2.6 0v7A5.6 5.6 0 0 1 13.6 21z"/><path class="l" d="M8.6 17h8"/></svg>',
    special: '<svg viewBox="0 0 24 24"><path class="a" d="M1.5 12 9 7v10z"/><path class="l" d="M4 7.5 9 9.5M4 16.5 9 14.5" /><circle class="w" cx="15" cy="12" r="6.5"/><circle class="a" cx="15" cy="12" r="3.8"/><circle fill="#fff" cx="14" cy="11" r="1.4"/></svg>',
    ultimate: '<svg viewBox="0 0 24 24"><polygon class="w" points="12.0,1.5 13.9,7.4 19.4,4.6 16.6,10.1 22.5,12.0 16.6,13.9 19.4,19.4 13.9,16.6 12.0,22.5 10.1,16.6 4.6,19.4 7.4,13.9 1.5,12.0 7.4,10.1 4.6,4.6 10.1,7.4"/><circle class="a" cx="12" cy="12" r="4.6"/><circle fill="#fff" cx="12" cy="12" r="2"/></svg>',
    transform: '<svg viewBox="0 0 24 24"><path class="w" d="M13.5 1.5 4.5 13.2h5.6l-1.4 9.3 10.3-13h-6z"/><path class="a" d="M12.4 6.2 8.8 11.4h4l-.6 4.4 3.4-4.6h-3.4z"/></svg>',
    fusion: '<svg viewBox="0 0 24 24"><circle class="s" cx="8.5" cy="12" r="6"/><circle class="s" cx="15.5" cy="12" r="6"/><path class="a" d="M12 7.2a6 6 0 0 1 0 9.6 6 6 0 0 1 0-9.6z"/></svg>',
    aux: '<svg viewBox="0 0 24 24"><circle class="w" cx="12" cy="7.5" r="3.8"/><path class="w" d="M4.5 21c0-4.6 3.2-7.4 7.5-7.4s7.5 2.8 7.5 7.4z"/><path class="l" d="M10 17.5h4M12 15.5v4"/></svg>',
    swap: '<svg viewBox="0 0 24 24"><path class="s" d="M4 8h13.5"/><path class="w" d="M16 3.6 21 8l-5 4.4z"/><path class="s" d="M20 16H6.5"/><path class="w" d="M8 11.6 3 16l5 4.4z"/></svg>',
    pause: '<svg viewBox="0 0 24 24"><rect class="w" x="6" y="4.5" width="4.2" height="15" rx="1"/><rect class="w" x="13.8" y="4.5" width="4.2" height="15" rx="1"/></svg>'
  };
  const css = document.createElement('style');
  css.textContent = `
#touch .tb{position:absolute;pointer-events:auto;border-radius:50%;color:#fff;font:800 12px/1 system-ui,monospace;letter-spacing:.5px;display:flex;align-items:center;justify-content:center;touch-action:none;text-align:center;-webkit-tap-highlight-color:transparent;
 background:radial-gradient(circle at 35% 28%,rgba(255,255,255,.38),rgba(255,255,255,.04) 55%),rgba(14,14,30,.55);border:2px solid var(--c);box-shadow:0 0 10px -1px var(--c),inset 0 0 10px -2px var(--c);text-shadow:0 1px 2px #000;transition:transform .05s}
#touch .tb.on{transform:scale(.9);background:radial-gradient(circle at 50% 50%,var(--c),rgba(14,14,30,.4) 85%);box-shadow:0 0 18px 2px var(--c)}
#touch .tb.sq{border-radius:14px}
#touch .grp{position:absolute;pointer-events:auto;touch-action:none}
#touch .stk .base{position:absolute;inset:6%;border-radius:50%;background:radial-gradient(circle,rgba(255,255,255,.06) 0,rgba(255,255,255,.12) 62%,rgba(255,255,255,.28) 66%,rgba(20,20,40,.5) 100%);border:2px solid rgba(255,255,255,.5);box-shadow:0 0 14px rgba(120,160,255,.35) inset}
#touch .stk .tick{position:absolute;left:50%;top:50%;width:6px;height:6px;margin:-3px;border-radius:50%;background:rgba(255,255,255,.55)}
#touch .stk .knob{position:absolute;left:50%;top:50%;width:46%;height:46%;margin:-23% 0 0 -23%;border-radius:50%;background:radial-gradient(circle at 35% 30%,#fff,#9fb4ff 45%,#4a5cc8);border:2px solid #fff;box-shadow:0 3px 10px #000a;transition:none}
#touch .tb svg{width:64%;height:64%;pointer-events:none;overflow:visible;filter:drop-shadow(0 1px 1.5px #000)}
#touch .tb svg .w{fill:#fff;stroke:#0b0b18;stroke-width:1.1;stroke-linejoin:round}
#touch .tb svg .a{fill:var(--c);stroke:#0b0b18;stroke-width:.9;stroke-linejoin:round;stroke-linecap:round}
#touch .tb svg .l{fill:none;stroke:var(--c);stroke-width:1.5;stroke-linecap:round}
#touch .tb svg .s{fill:none;stroke:#fff;stroke-width:2.2;stroke-linecap:round}
#touch.edit .tb,#touch.edit .grp{outline:2px dashed #ffe14a;outline-offset:3px;cursor:move}
`;
  document.head.appendChild(css);
  addEventListener('load', () => {
    const root = document.getElementById('touch'); if (!root) return;
    const coarse = matchMedia('(pointer:coarse)').matches || 'ontouchstart' in window; I.touchCapable = coarse;
    const els = {}; // id -> {el, size()}
    const mkBtn = (id, label, col, act, cls) => {
      const b = document.createElement('div'); b.className = 'tb ' + (cls || ''); if (ICON[act]) b.innerHTML = ICON[act]; else b.textContent = label; b.setAttribute('aria-label', label); b.style.setProperty('--c', col); root.appendChild(b);
      const on = e => { if (I.tEdit) return; e.preventDefault(); I.touch[act] = true; b.classList.add('on'); RC.Audio && RC.Audio.resume(); };
      const off = e => { if (I.tEdit) return; e.preventDefault(); I.touch[act] = false; b.classList.remove('on'); };
      b.addEventListener('pointerdown', on); b.addEventListener('pointerup', off); b.addEventListener('pointercancel', off); b.addEventListener('pointerleave', off);
      return b;
    };
    DEFS.forEach(d => { els[d[0]] = { el: mkBtn(d[0], d[1], d[2], d[0]), k: 1 }; });
    els.pause = { el: mkBtn('pause', 'II', '#ffffff', 'pause', 'sq'), k: 0.8 };
    els.pause.el.addEventListener('pointerdown', () => { if (I.tEdit) return; dispatchEvent(new KeyboardEvent('keydown', { code: 'Escape' })); dispatchEvent(new KeyboardEvent('keyup', { code: 'Escape' })); });
    // analógico
    const stk = document.createElement('div'); stk.className = 'grp stk'; root.appendChild(stk);
    const base = document.createElement('div'); base.className = 'base'; stk.appendChild(base);
    for (let i = 0; i < 8; i++) { const t = document.createElement('div'); t.className = 'tick'; const a = i * Math.PI / 4; t.style.left = (50 + Math.cos(a) * 42) + '%'; t.style.top = (50 + Math.sin(a) * 42) + '%'; stk.appendChild(t); }
    const knob = document.createElement('div'); knob.className = 'knob'; stk.appendChild(knob);
    els.stick = { el: stk, k: 3.1 };
    let pid = null, scx = 0, scy = 0, sR = 1;
    const T = I.touch;
    function sUpd(e) {
      let dx = (e.clientX - scx) / sR, dy = (e.clientY - scy) / sR; const m = Math.hypot(dx, dy); if (m > 1) { dx /= m; dy /= m; }
      knob.style.transform = `translate(${dx * sR * 0.75}px,${dy * sR * 0.75}px)`;
      T.l = dx < (T.l ? -0.26 : -0.38); T.r = dx > (T.r ? 0.26 : 0.38); T.u = dy < (T.u ? -0.34 : -0.5); T.d = dy > (T.d ? 0.26 : 0.36);
    }
    function sEnd(e) { if (e && e.pointerId !== pid) return; pid = null; knob.style.transform = ''; T.l = T.r = T.u = T.d = false; }
    stk.addEventListener('pointerdown', e => { if (I.tEdit) return; e.preventDefault(); pid = e.pointerId; try { stk.setPointerCapture(pid); } catch (x) { } const r = stk.getBoundingClientRect(); scx = r.left + r.width / 2; scy = r.top + r.height / 2; sR = r.width * 0.36; sUpd(e); RC.Audio && RC.Audio.resume(); });
    stk.addEventListener('pointermove', e => { if (e.pointerId === pid) sUpd(e); });
    stk.addEventListener('pointerup', sEnd); stk.addEventListener('pointercancel', sEnd);
    // D-Pad alternativo
    const dpd = document.createElement('div'); dpd.className = 'grp dpd'; root.appendChild(dpd); els.dpad = { el: dpd, k: 3.1 };
    const dp = [['◄', 'l', 0, 1], ['►', 'r', 2, 1], ['▲', 'u', 1, 0], ['▼', 'd', 1, 2]].map(a => {
      const b = document.createElement('div'); b.className = 'tb'; b.textContent = a[0]; b.style.setProperty('--c', '#9fb4ff'); b.style.width = b.style.height = '33.3%'; b.style.left = (a[2] * 33.3) + '%'; b.style.top = (a[3] * 33.3) + '%'; dpd.appendChild(b);
      const on = e => { if (I.tEdit) return; e.preventDefault(); T[a[1]] = true; b.classList.add('on'); RC.Audio && RC.Audio.resume(); }, off = e => { if (I.tEdit) return; e.preventDefault(); T[a[1]] = false; b.classList.remove('on'); };
      b.addEventListener('pointerdown', on); b.addEventListener('pointerup', off); b.addEventListener('pointercancel', off); b.addEventListener('pointerleave', off); return b;
    });
    // arrastar (modo edição)
    for (const id in els) {
      const o = els[id], el = o.el; let drag = null;
      el.addEventListener('pointerdown', e => { if (!I.tEdit) return; e.preventDefault(); const r = el.getBoundingClientRect(); drag = { id: e.pointerId, dx: e.clientX - (r.left + r.width / 2), dy: e.clientY - (r.top + r.height / 2) }; try { el.setPointerCapture(e.pointerId); } catch (x) { } });
      el.addEventListener('pointermove', e => { if (!drag || e.pointerId !== drag.id) return; const w = innerWidth, h = innerHeight; const cx = RC.clamp(e.clientX - drag.dx, 0, w), cy = RC.clamp(e.clientY - drag.dy, 0, h); C.pos[id] = { fx: cx / w, fy: cy / h }; I.touchLayout(); });
      const up = e => { if (drag && e.pointerId === drag.id) { drag = null; save(); } }; el.addEventListener('pointerup', up); el.addEventListener('pointercancel', up);
    }
    // layout
    I.touchLayout = function () {
      const w = innerWidth, h = innerHeight, s = Math.round(RC.clamp(Math.min(w, h) * 0.125, 38, 66) * C.size), g = Math.round(s * 0.1);
      const put = (id, dx, dy, sz) => { const o = els[id], p = C.pos[id], cx = p ? p.fx * w : dx, cy = p ? p.fy * h : dy; o.el.style.left = Math.round(cx - sz / 2) + 'px'; o.el.style.top = Math.round(cy - sz / 2) + 'px'; o.el.style.width = o.el.style.height = sz + 'px'; };
      const sk = Math.round(s * 3.1);
      put('stick', sk / 2 + 14, h - sk / 2 - 12, sk); put('dpad', sk / 2 + 14, h - sk / 2 - 12, sk);
      stk.style.display = C.stick ? 'block' : 'none'; dpd.style.display = C.stick ? 'none' : 'block';
      const x0 = w - 14 - s / 2, y0 = h - 12 - s / 2, st = s + g, grid = [['lp', 3, 0], ['hp', 2, 0], ['lk', 1, 0], ['hk', 0, 0], ['grab', 3, 1], ['special', 2, 1], ['ultimate', 1, 1], ['transform', 0, 1], ['fusion', 3, 2], ['aux', 2, 2], ['swap', 1, 2]];
      // linha de baixo: SF SH CF CH (da direita p/ a esquerda); polegar alcança o centro
      grid.forEach(a => put(a[0], x0 - a[1] * st, y0 - a[2] * st, s));
      put('pause', w - s * 0.5 - 10, s * 0.5 + 8, Math.round(s * 0.8));
      for (const id in els) { const el = els[id].el; if (el.classList.contains('tb')) el.style.fontSize = Math.round(parseInt(el.style.width) * (id === 'swap' ? 0.21 : 0.3)) + 'px'; }
      dp.forEach(b => b.style.fontSize = Math.round(sk * 0.12) + 'px');
      root.style.opacity = C.opa;
    };
    I.showTouch = (on, force) => { const show = on && (coarse || force); root.style.display = show ? 'block' : 'none'; if (show) I.touchLayout(); if (!on) { for (const k in T) T[k] = false; knob.style.transform = ''; } };
    I.touchEdit = on => { I.tEdit = !!on; root.classList.toggle('edit', !!on); for (const k in T) T[k] = false; };
    I.touchReset = () => { C.pos = {}; C.size = 1; C.opa = 0.9; C.stick = true; save(); I.touchLayout(); };
    addEventListener('resize', () => root.style.display !== 'none' && I.touchLayout());
  });
})();
