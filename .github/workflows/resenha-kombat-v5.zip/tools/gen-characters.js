// Gera data/characters/<id>.json (stats, golpes, hurtboxes, paleta e metadados de spritesheet).
// Edite os JSONs gerados à vontade; rode node tools/build-data.js depois para atualizar o bundle.
const fs = require('fs');
const path = require('path');
const out = path.join(__dirname, '..', 'data', 'characters');
fs.mkdirSync(out, { recursive: true });

const BASE = {
  lp:  { startup: 4, active: 3, recovery: 8,  dmg: 30, box: { x: 10, y: -52, w: 30, h: 12 }, hitstun: 14, blockstun: 9,  kx: 1.5, type: 'mid' },
  hp:  { startup: 8, active: 4, recovery: 16, dmg: 65, box: { x: 10, y: -54, w: 40, h: 16 }, hitstun: 20, blockstun: 12, kx: 3.5, type: 'mid' },
  lk:  { startup: 5, active: 3, recovery: 10, dmg: 35, box: { x: 8,  y: -32, w: 38, h: 12 }, hitstun: 15, blockstun: 10, kx: 1.8, type: 'mid' },
  hk:  { startup: 9, active: 4, recovery: 18, dmg: 70, box: { x: 8,  y: -48, w: 48, h: 16 }, hitstun: 22, blockstun: 13, kx: 4.5, type: 'mid' },
  clp: { startup: 5, active: 3, recovery: 9,  dmg: 28, box: { x: 10, y: -34, w: 28, h: 10 }, hitstun: 13, blockstun: 9,  kx: 1.2, type: 'mid' },
  chp: { startup: 8, active: 4, recovery: 22, dmg: 60, box: { x: 6,  y: -74, w: 28, h: 46 }, hitstun: 30, blockstun: 12, kx: 1.5, ky: -8, type: 'mid' },
  clk: { startup: 5, active: 3, recovery: 10, dmg: 30, box: { x: 8,  y: -10, w: 40, h: 10 }, hitstun: 13, blockstun: 9,  kx: 1.2, type: 'low' },
  chk: { startup: 9, active: 4, recovery: 24, dmg: 55, box: { x: 8,  y: -12, w: 58, h: 12 }, hitstun: 30, blockstun: 13, kx: 3, ky: -4.5, type: 'low' },
  alp: { startup: 3, active: 9, recovery: 6,  dmg: 40, box: { x: 8,  y: -44, w: 32, h: 30 }, hitstun: 16, blockstun: 10, kx: 2, type: 'overhead' },
  alk: { startup: 3, active: 9, recovery: 6,  dmg: 45, box: { x: 6,  y: -30, w: 42, h: 22 }, hitstun: 16, blockstun: 10, kx: 2.5, type: 'overhead' },
  grab:{ startup: 4, active: 2, recovery: 26, dmg: 90, box: { x: 0,  y: -52, w: 34, h: 52 }, hitstun: 30, blockstun: 0,  kx: 5, ky: -6, type: 'throw' }
};

const CH = {
  guilherme: { name: 'GUILHERME', col: '#e53935', bio: 'Mestre do teleporte', hp: 1000, walk: 1.75, dmg: 1.0, fr: 0.95, scale: 1,
    pal: { skin: '#f3d7bd', hair: '#161616', top: '#d32f2f', bottom: '#1a1a1a', shoes: '#2a2a2a', trim: '#7f1d1d' }, flags: ['tank', 'short'] },
  arthur:    { name: 'ARTHUR', col: '#7b1fa2', bio: 'Invocador gótico', hp: 1000, walk: 1.65, dmg: 1.0, fr: 1, scale: 1,
    pal: { skin: '#f0d2b8', hair: '#111111', top: '#ffffff', bottom: '#171717', shoes: '#222222', trim: '#0e0e0e', jacket: '#151515' }, flags: ['jacket', 'volume'] },
  alexandre: { name: 'ALEXANDRE', col: '#ef6c00', bio: 'Pesadão da cadeirada', hp: 1150, walk: 1.25, dmg: 1.3, fr: 1.15, scale: 1.2, wide: 1.5,
    pal: { skin: '#efcfb4', hair: '#2a1c14', top: '#f4f4f4', bottom: '#c62828', shoes: '#222222', trim: '#cfcfcf' }, flags: ['tshirt', 'volume', 'belly'] },
  kaique:    { name: 'KAIQUE', col: '#fdd835', bio: 'Sorriso mortal', hp: 1000, walk: 1.7, dmg: 1.0, fr: 1, scale: 1,
    pal: { skin: '#f1d6bf', hair: '#6b3f22', top: '#f7f7f7', bottom: '#171717', shoes: '#eeeeee', trim: '#d8d8d8' }, flags: ['dress', 'volume'] },
  toddy:     { name: 'TODDY', col: '#8e24aa', bio: 'O Todão e seu Guardião', hp: 1050, walk: 1.5, dmg: 1.05, fr: 1.05, scale: 1.05,
    pal: { skin: '#8a5a3b', hair: '#1a1008', top: '#141414', bottom: '#141414', shoes: '#111111', trim: '#d4a82b' }, flags: ['coat', 'cap', 'curly'] },
  matheus:   { name: 'MATHEUS', col: '#ec407a', bio: 'Terno e amor', hp: 1000, walk: 1.7, dmg: 1.0, fr: 1, scale: 1,
    pal: { skin: '#f1d5bc', hair: '#2b1b12', top: '#141414', bottom: '#141414', shirt: '#fafafa', shoes: '#0b0b0b', trim: '#fafafa' }, flags: ['suit', 'volume'] },
  luan:      { name: 'LUAN', col: '#1e88e5', bio: 'Lei e ordem', hp: 1000, walk: 1.7, dmg: 1.0, fr: 1, scale: 1,
    pal: { skin: '#5a3a28', hair: '#0c0c0c', top: '#1d2b4d', bottom: '#1d2b4d', vest: '#10151f', shoes: '#0b0b0b', trim: '#c9a227' }, flags: ['police', 'crespo'] },
  rafael:    { name: 'RAFAEL', col: '#cfd8dc', bio: 'Grife e harém', hp: 1000, walk: 1.65, dmg: 1.0, fr: 1, scale: 1,
    pal: { skin: '#fbe6d6', hair: '#2c1c12', top: '#f8f8f8', bottom: '#f8f8f8', tie: '#111111', shoes: '#0b0b0b', trim: '#d6d6d6' }, flags: ['suit', 'whitesuit', 'crespo'] },
  joel:      { name: 'JOEL', col: '#fbc02d', bio: 'Dança da derrota', hp: 1000, walk: 1.9, dmg: 0.95, fr: 0.95, scale: 1,
    pal: { skin: '#f3d6bd', hair: '#e2c35a', top: null, bottom: '#161616', band: '#151515', shoes: '#222222', trim: '#151515' }, flags: ['shirtless', 'crespo', 'bandana'] },
  vitin:     { name: 'VITIN', col: '#43a047', bio: 'Escopeta e 200', hp: 1000, walk: 1.8, dmg: 1.0, fr: 0.95, scale: 1,
    pal: { skin: '#f2d6be', hair: '#8a6a3a', top: '#f1d32e', bottom: '#171717', shoes: '#222222', trim: '#1f9d3a' }, flags: ['jersey', 'surfer'] }
};

for (const id of Object.keys(CH)) {
  const c = CH[id];
  const moves = {};
  for (const k of Object.keys(BASE)) {
    const m = JSON.parse(JSON.stringify(BASE[k]));
    m.dmg = Math.round(m.dmg * c.dmg);
    m.startup = Math.max(2, Math.round(m.startup * c.fr));
    m.recovery = Math.max(4, Math.round(m.recovery * c.fr));
    if (c.scale > 1) { m.box.w = Math.round(m.box.w * c.scale); m.box.h = Math.round(m.box.h * c.scale); }
    moves[k] = m;
  }
  const s = c.scale;
  const json = {
    id, name: c.name, color: c.col, bio: c.bio,
    stats: { hp: c.hp, walk: c.walk, back: +(c.walk * 0.72).toFixed(2), jump: 10.5, pow: 1 },
    size: { scale: s, wide: c.wide || 1 },
    pal: c.pal, flags: c.flags,
    hurtboxes: {
      stand:  { x: -13, y: -62, w: 26, h: 62 },
      crouch: { x: -14, y: -38, w: 28, h: 38 },
      air:    { x: -13, y: -60, w: 26, h: 52 },
      down:   { x: -30, y: -16, w: 60, h: 16 }
    },
    moves,
    // Para trocar o placeholder por sprites: coloque o PNG em assets/ e preencha "sheet".
    // Cada animação é uma linha do PNG: { row, frames, fps, loop }. O jogo escolhe pela chave do estado.
    sprite: {
      sheet: null, frameW: 96, frameH: 96, anchor: [48, 92],
      anims: {
        idle: { row: 0, frames: 4, fps: 6, loop: true }, walk: { row: 1, frames: 6, fps: 10, loop: true },
        jump: { row: 2, frames: 3, fps: 8, loop: false }, crouch: { row: 3, frames: 1, fps: 1, loop: true },
        block: { row: 4, frames: 1, fps: 1, loop: true }, hit: { row: 5, frames: 2, fps: 8, loop: false },
        down: { row: 6, frames: 1, fps: 1, loop: true }, win: { row: 7, frames: 4, fps: 6, loop: true },
        lp: { row: 8, frames: 3, fps: 12, loop: false }, hp: { row: 9, frames: 4, fps: 12, loop: false },
        lk: { row: 10, frames: 3, fps: 12, loop: false }, hk: { row: 11, frames: 4, fps: 12, loop: false },
        special: { row: 12, frames: 6, fps: 10, loop: false }, ultimate: { row: 13, frames: 6, fps: 10, loop: false }
      }
    }
  };
  fs.writeFileSync(path.join(out, id + '.json'), JSON.stringify(json, null, 2) + '\n');
}
console.log('data/characters/*.json gerados');
