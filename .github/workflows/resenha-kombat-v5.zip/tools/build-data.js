// Gera data/bundle.js a partir dos JSONs, para o jogo funcionar abrindo index.html direto (file://).
// Rode: node tools/build-data.js  (sempre que editar algum JSON em data/)
const fs = require('fs');
const path = require('path');
const dir = path.join(__dirname, '..', 'data');
const read = f => JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8'));
const characters = {};
const cdir = path.join(dir, 'characters');
if (fs.existsSync(cdir)) {
  for (const f of fs.readdirSync(cdir)) {
    if (f.endsWith('.json')) characters[f.replace('.json', '')] = JSON.parse(fs.readFileSync(path.join(cdir, f), 'utf8'));
  }
}
const out = {
  dialogues: read('dialogues.json'),
  fusions: read('fusions.json'),
  transformations: read('transformations.json'),
  info: read('info.json'),
  characters
};
fs.writeFileSync(path.join(dir, 'bundle.js'), 'window.RC=window.RC||{};window.RC.DATA=' + JSON.stringify(out) + ';\n');
console.log('data/bundle.js gerado');
