# RESENHA COMBAT

Jogo de luta 2D no navegador (HTML5 Canvas + JavaScript puro, sem build). **Abra `index.html` e jogue.** Funciona em `file://`, com teclado, gamepad, mouse e toque (celular).

## Modos
- **VERSUS**: 1v1, 2v2 ou 3v3 (troca automática ao cair, com animação de entrada). PvP local ou PvCPU (dificuldade 1-5: FÁCIL → INSANO).
- **TREINO**: sem timer, mostra hitboxes, boneco de treino.
- **OPÇÕES**: volumes, dificuldade, remapear controles.

Fluxo: Splash → Menu → Versus → Seleção → Cenário → Tela VS (diálogos) → Luta → Vitória → Revanche/Menu.

## Regras
Melhor de 3 rounds, 99 s. Barra de vida individual por lutador (barra de super e de RESENHATALITY compartilhadas pelo time).
- **Especial**: 1 barra. **Ultimate**: barra cheia (cutscene). **Transformação**: barra cheia, 3x força ou velocidade por tempo limitado, com poder novo. **Fusão** (times 2v2/3v3): 9 fusões possíveis em `data/fusions.json`.
- **RESENHATALITY**: ao vencer o round decisivo com a barra cheia aparece "FINISH HIM!"; digite o comando do seu lutador.

## Controles padrão
| Ação | Jogador 1 | Jogador 2 |
|---|---|---|
| Mover / pular / agachar | W A S D | Setas |
| Soco fraco / forte | F / G | J / K |
| Chute fraco / forte | R / T | U / I |
| Agarrão | V | N |
| Especial | C | M |
| Ultimate | X | , |
| Transformar | Z | . |
| Fusão | B | / |
| Auxiliar | Q | H |

Pausa: Esc / Enter. Tudo é remapeável em Opções > Controles (salvo em `localStorage`). Gamepad: A/B/X/Y golpes, LB agarrão, RB especial, RT ultimate, LT aux, Back transformar, Start fusão. No celular os botões de toque aparecem sozinhos.

### Comandos de RESENHATALITY
Guilherme ↓ → ↓ + soco forte · Arthur → → ↓ + soco forte · Alexandre ↓ ↓ ↑ + chute forte · Kaique ← → ↓ + chute forte · Toddy → ↓ → + soco forte · Matheus ← ← → + soco forte · Luan ↓ ↓ ↓ + soco fraco · Rafael ↑ ↓ → + chute forte · Joel → ← → + soco forte · Vitin ↓ ← → + chute forte (direções relativas ao lado para onde o lutador olha).

## Estrutura
Veja `ARCHITECTURE.md`. Resumo: `src/engine` (loop, input, áudio, partículas, sprites), `src/characters` (um arquivo por lutador + `fusion.js`), `src/stages`, `src/modes` (partida e IA), `src/ui` (HUD e telas), `data/` (JSONs).

## Como trocar os sprites provisórios
Todos os sprites são gerados por código. Para usar arte real:
1. Edite `data/characters/<id>.json`, bloco `sprite`: defina `sheet` (ex. `"assets/guilherme.png"`), tamanho do quadro e a tabela de `frames` por animação (`idle`, `walk`, `lp`, `hp`, ...), com `hitboxes` e `hurtboxes` por quadro.
2. Rode `node tools/build-data.js` (regenera `data/bundle.js`; **rode após editar qualquer JSON em `data/`**).
3. Com `sheet: null` o jogo continua usando o desenho procedural.

Retratos: `RC.Sprites.portrait`. Bonecos: `src/engine/sprites.js` (funções `limb`, `torso`, `fist`, `shoe`, `head`).

## Cenários e desempenho
`src/stages/stages.js`: cada cenário é uma lista de camadas. Camadas estáticas (`d(c)`) são pré-renderizadas uma única vez em canvas e só copiadas a cada quadro (com parallax `f`); o que se mexe (fogo, torcida, neon, chuva) é `a(c,t,px)`. Para usar arte pronta, troque uma camada por `drawImage` de um PNG.

## Diálogos
`data/dialogues.json`: 45 duplas; as 6 fornecidas estão completas e as demais têm `"draft": true` (rascunhos para você reescrever). Se faltar a dupla, usa-se a fala genérica do personagem. Rode `node tools/build-data.js` depois de editar.

## Áudio
Sons e música são sintetizados com WebAudio (`src/engine/audio.js`). Para trocar por arquivos: `RC.Audio.load('hit', 'assets/hit.wav')` (mesmo nome do som sintetizado) antes de iniciar o jogo.

## Balanceamento
Números de dano ficam nos arquivos de cada lutador e em `data/characters/*.json` (golpes normais). Dano por golpe é limitado a 450 em `src/modes/versus.js`.

## Limitações conhecidas
Arte e sons são provisórios; as falas rascunho precisam de revisão; o jogo foi testado em Chromium automatizado (sem erros de console em todos os poderes, fatalities e fusões), mas não em aparelhos reais.

## v3 — novidades

- **Tela inicial e botões** redesenhados (`RC.UI` em `src/ui/screens.js`).
- **Controles de toque** (`src/engine/touch.js`): analógico virtual (ou D-Pad) que escreve no mesmo caminho das setas, então a RESENHATALITY funciona igual. Editor de layout em Opções > Botões de toque (arrastar, tamanho, opacidade), salvo em `localStorage`.
- **Troca de lutador** no meio da luta (E / O, botão TROCA, clique do analógico no gamepad), com cooldown.
- **Modos** (`src/ui/screens2.js`): Arcade (6 lutas, continue), Torneio (chave de 8), Treino 1v1/2v2/3v3, Personagens (ficha, poderes, fatality, forma e fusões; dados em `data/info.json`) e Como jogar.
- **Arthur transformado**: Combo Relâmpago (teleporte + 14 socos + kamehameha), SAI FORA, FEMBOY! (baixo + especial) e ULTIMATE VAZIO DA RESENHA (bola vermelha + azul = roxa, com cutscene).
- Visual dos poderes melhorado (`D.beam`, `D.orb`, pós-imagens, ondas de choque).
- Após editar qualquer JSON em `data/`, rode `node tools/build-data.js`.

## v3.1 — Skins

- Nova aba **SKINS** em Personagens (escolha com cima/baixo, ENTER ou clique equipa; fica salva em `localStorage`).
- Definições em `src/engine/skins.js` (paleta, flags e extras); o desenho dos extras (manto, calopsita, chapéu, capuz, cinto, faixa, neon) está em `src/engine/sprites.js`.
- Skins: Arthur (Traje Homem-Aranha, Roupa do Goku), Guilherme (Manto Calopsita), Kaique (Lord Kaique), Toddy (Jojo, com Guardião recolorido).

## v3.2 — Visual dos poderes
- Nova calopsita (`D.bird`): crista de penas, bochecha laranja, asas em camadas e cauda longa. A Calopsita Gigante agora carrega energia com faíscas convergindo, dispara um raio diagonal em camadas (`D.beam`) com orbes na origem e no impacto.
- Góticas do Arthur (`D.goth`): desenho novo (vestido espartilhado, saia em camadas, cabelo longo, presilha de morcego, garras de energia), invocadas por um círculo mágico com morcegos e rastro ao correr (`P.runner` com `ghost`).

## v3.3 — Ícones nos botões de toque
Os botões de toque agora usam ícones SVG desenhados (punho, bota, mão, bola de energia, estrela, raio, anéis, pessoa, setas de troca e pause) em vez de letras. Os ícones ficam em `src/engine/touch.js` (`ICON`). Soco/chute fortes têm uma explosão no ícone.

## v3.4 — Skins do Arthur: Homem-Aranha e Goku
- **TRAJE HOMEM-ARANHA**: traje vermelho com teias pretas, aranha no peito, laterais e pernas azuis, luvas e botas vermelhas. É só a roupa: **sem máscara**, o rosto e o cabelo do Arthur continuam à mostra.
- **ROUPA DO GOKU**: kimono laranja, camisa azul por baixo (gola em V), faixa, munhequeiras e botas azuis. É só a roupa: cabelo, rosto e corpo do Arthur não mudam.
- A lista da aba SKINS agora rola (3 cartões por vez, com contador) quando o personagem tem mais de 3 opções.
- Desenho: extras `spider` e `gi` em `src/engine/sprites.js`; novas chaves de paleta `glove`, `web`, `side`, `upper`, `wrist`, `boot`, `bootBand`, `under`, `obi`.

## Deploy
Publicado no Netlify como site estático (`netlify.toml` publica a raiz, sem comando de build).
