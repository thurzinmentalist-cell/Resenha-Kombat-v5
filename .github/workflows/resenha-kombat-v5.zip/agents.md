# AGENTS.md — RESENHA COMBAT

Jogo de luta 2D em HTML5 Canvas + JavaScript puro, **sem build e sem dependências**. `index.html` carrega os scripts em ordem; tudo vive no namespace global `window.RC`. Deploy no Netlify como site estático (`netlify.toml` publica `.`).

## Diretórios
- `src/engine/` — loop, input, toque, áudio, partículas, câmera, colisão, `skins.js` (definições de skins), `sprites.js` (todo o desenho procedural dos lutadores).
- `src/characters/` — um arquivo por lutador + `fusion.js`, `powers.js`, `fighter.js` (classe base).
- `src/ui/` — HUD e telas (`screens2.js` contém a tela Personagens com a aba SKINS).
- `data/` — JSONs; `data/bundle.js` é gerado por `node tools/build-data.js` (rode após editar qualquer JSON).

## Skins
- Uma skin = `{ id, name, desc, pal, del, add, ex }` em `src/engine/skins.js`. `pal` sobrescreve a paleta, `del/add` mexem nas flags, `ex` liga extras desenhados em `sprites.js`.
- Chaves de paleta opcionais suportadas pelo desenho: `sleeve`, `long`, `upper` (manga curta), `glove` (cor do punho), `web`/`side` (traje de teia), `wrist` (munhequeira), `boot`/`bootBand` (bota de cano alto), `under`/`obi` (kimono).
- Skins de roupa inspirada em personagens (Homem-Aranha, Goku) devem mudar **só a roupa**: nada de máscara, cabelo, olhos ou traços físicos — pedido explícito do dono do projeto.
- A aba SKINS mostra 3 cartões por vez e rola com a seleção (`skOff`/`skVis` em `screens2.js`).

## Convenções
- Textos de UI em MAIÚSCULAS e sem acentos (a fonte bitmap em `src/engine/text.js` não tem acentos/minúsculas nem `^`).
- Resolução interna 480x270; desenhe com `R`/`L`/`limb` e contorno `OUT`.
