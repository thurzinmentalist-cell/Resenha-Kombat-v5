# RESENHA COMBAT: Arquitetura

Jogo de luta 2D em HTML5 Canvas, sem build e sem dependências. Abrir `index.html` basta.
Resolução interna 480x270, escalada com `image-rendering: pixelated`.

## Estrutura de pastas

```
resenha-combat/
├── index.html
├── README.md
├── ARCHITECTURE.md
├── data/
│   ├── dialogues.json        # { "arthur_vs_alexandre": [{speaker,text}], "draft": true nos rascunhos }
│   ├── fusions.json          # 9 fusões: nome, visual, poder novo
│   ├── transformations.json  # 1 por lutador
│   └── characters/           # um JSON por lutador: frames, hitboxes, hurtboxes, golpes
│       ├── guilherme.json ... vitin.json
├── assets/                   # (futuro) spritesheets .png e áudio
└── src/
    ├── main.js               # bootstrap e máquina de estados de telas
    ├── engine/
    │   ├── loop.js           # fixed timestep 60 fps
    │   ├── input.js          # teclado + gamepad, buffer de comandos
    │   ├── collision.js      # AABB hitbox vs hurtbox
    │   ├── camera.js         # zoom, tremor, enquadramento dos dois lutadores
    │   ├── audio.js          # WebAudio sintetizado, API play('nome') trocável por arquivo
    │   ├── sprites.js        # placeholder procedural + loader de spritesheet
    │   └── particles.js
    ├── characters/
    │   ├── fighter.js        # classe base: estados, física, vida, super
    │   ├── guilherme.js ...  # um arquivo por lutador (especial, ultimate, resenhatality, transformação)
    ├── stages/               # 7 cenários com parallax
    ├── ui/                   # hud, splash, menus, seleção, tela VS, cutscenes, diálogos
    └── modes/                # versus (1v1/2v2/3v3), treino, ai.js
```

## Decisões principais

- **Estados do lutador**: máquina de estados (idle, walk, jump, crouch, block, attack, hit, knockdown, special, ultimate, fatality, transform). Cada golpe é dado em frames (startup/active/recovery) e vem do JSON do personagem.
- **Troca de sprites**: `sprites.js` tenta carregar `assets/<id>.png` + `data/characters/<id>.json`; se não existir, desenha o placeholder pixel art por código. Nenhum código de jogo muda ao trocar.
- **Times (2v2/3v3)**: `Team` guarda a lista de lutadores, cada um com vida própria; entrada automática do próximo com animação.
- **Cutscenes**: sistema de timeline (zoom, escurecer, retrato, nome do golpe, impacto) reutilizado por ultimates e transformações.
- **Resenhatality**: ativada no último round se a barra de fatality estiver liberada; comando digitado; cada lutador define sua animação.
- **Diálogos**: chave `a_vs_b` em ordem alfabética (espelho resolvido automaticamente); fallback genérico por personagem.
- **Fusões**: só as 9 listadas, definidas em `data/fusions.json`; disponíveis em 2v2/3v3 com os dois vivos e super cheia.
- **Originalidade**: nenhum sprite, nome ou golpe copiado de outros jogos ou animes.

## Ordem de entrega

1. Arquitetura (este arquivo)
2. Engine + lutador placeholder
3. Menus, seleção, modos 1v1/2v2/3v3
4. Elenco, um por vez
5. Cenários, sons, polimento
6. README
